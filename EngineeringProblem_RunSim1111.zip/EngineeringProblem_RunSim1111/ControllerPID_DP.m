function [tau1] =ControllerPID_DP(VesselState,VesselDeltaState, VesselVelocity,VesselAcceleration,VesselToWaterVelocity,...
   WindForce,GainWindForce,GainPosition,GainHeading,dt,x,Flag)

VesselVelocity(3)=deg2rad(VesselVelocity(3));

    Velocity= VesselVelocity;

persistent state_int_forc
if isempty(state_int_forc)||Flag
    state_int_forc=[0;0;0];
end

persistent state_int_controller
if isempty(state_int_controller)||Flag
   state_int_controller=[0; 0 ;0];
  %   state_int_controller=initial_state_of_vessels(1:3);
end
%VesselDeltaState=(eta_ref1-eta');
VesselDeltaState =deadzoon(VesselDeltaState);
%==========================================================================
VesselState(3)= deg2rad(VesselState(3));
[PHI]=phi_limiter(VesselState(3));
VesselState(3)=PHI;
VesselDeltaState(3) = deg2rad(VesselDeltaState(3));
% [PHI]=phi_limiter(VesselDeltaState(3));
% VesselDeltaState(3)=PHI;


% 
% kP=1*[1000 0 0;0 1400 0;0 0 1600000];
% 
% kD=- 1*[18000 0 0;0 76000 0;0 0 12400000];
% 
% kD1=-1*[300 0 0;0 300 0;0 0 900];
% kI=0.1*[5 0 0;0 13 0;0 0 500];

% %  pid 
% 
% kP=1*[300 0 0;0 400 0;0 0 200000];
% 
% kD=- 1*[8000 0 0;0 6000 0;0 0 2400000];
% 
% kD1=-1*[30 0 0;0 30 0;0 0 90];
% kI=0.1*[5 0 0;0 13 0;0 0 500];
kP=1*[x(1) 0 0;0 x(2) 0;0 0 x(3)];

kD=[x(4) 0 0;0 x(5) 0;0 0 x(6)];

kD1=[x(7) 0 0;0 x(8) 0;0 0 x(9)];
kI= [x(10) 0 0;0 x(11) 0;0 0 x(12)];

phi=VesselState(3);
R           =   [cos(phi) -sin(phi) 0;sin(phi) cos(phi) 0;0 0 1];

VesselDeltaState_rotate  =  R'*VesselDeltaState;

C=1*eye(3);
dif=kI*VesselDeltaState_rotate;
h=0.01;
b=[0;0;0];
Y=runge_kutta11(b,dt,h,dif);


%
 % options = odeset('RelTol',1e-4,'AbsTol',1e-4);
 % [~,Y] = ode45(@(t,x) rigid(t,x,VesselDeltaState_rotate,kI),[0 dt],state_int_controller,options);
state_int_controller=Y(end,:);

% tau1=C(1,:)*Y(end,:)+kP(1,:)*VesselDeltaState_rotate+kD(1,:)*Velocity+kD1(1,:)*VesselAcceleration';
% tau2=C(2,:)*Y(end,:)+kP(2,:)*VesselDeltaState_rotate+kD(2,:)*Velocity+kD1(2,:)*VesselAcceleration';
% tau3=C(3,:)*Y(end,:)+kP(3,:)*VesselDeltaState_rotate+kD(3,:)*Velocity+kD1(2,:)*VesselAcceleration';
% tau11    =   [tau1;tau2;tau3];
tau11=C *Y(:,end)+kP *VesselDeltaState_rotate+kD *Velocity+kD1 *VesselAcceleration';

maxt     =   1*[75000;50000;800000];
% tau       = sign(tau11(:,1)).*(min(maxt,abs(tau11(:,1))));
tau12      = sign(tau11(:,1)).*(min(maxt,abs(tau11(:,1))));
for i=1:3
    if(sign(tau12(i,:))<0)
        tau12(i,:)= 0.5*tau12(i,:);
    end
end
% options =  odeset('RelTol',1e-6,'AbsTol',1e-6);
% [~,Y]   =  ode45(@(t,xt)LowPass_forceFuc(t,xt,tau12),[0 dt],state_int_forc,options);
tau120=[GainPosition;GainPosition;GainHeading].*tau12+GainWindForce.*WindForce;
state_int_forc   =runge_kutta1Filter(state_int_forc  ,dt,h,tau120)';

tau1      =  state_int_forc;
% tau1=tau'+ManualDemandForce;