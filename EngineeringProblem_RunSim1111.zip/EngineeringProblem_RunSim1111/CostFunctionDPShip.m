function [z zz SavePosition]=CostFunctionDPShip(initialStates,GoolPoints,TimeSimulation,variableDesision,Flag)

%global TimeSimulation;
dt                        =    0.1;
Dp                        =    1;                  % For DP mode....Dp=1,OW Dp=0;
 clear L  state_int_vessel;
 clear Data;
  clear cont;
 clear state_int_Obs;
 clear state_int_forc;
 clear state_int_controller;
%% initialized major
%=================scenario=================================================
x                         =    GoolPoints(1);             % x position
y                         =    GoolPoints(2);              % y position
psi                       =    GoolPoints(3);            % heading
x0                        =    initialStates(1);              % x initial(x0)
y0                        =    initialStates(2);              % y initial (yi)
psi0                      =    initialStates(3);            % heading initial (Hi)
%==========================================================================
[psi,psi0]                =   Tuning_Of_Heading(psi,psi0);
InitialStatesShip                        =   [x0;y0;psi0];
eta                       =   InitialStatesShip; 
Ship_eta                =InitialStatesShip;
M_eta                   =InitialStatesShip;
U                         =   7;
 t                         =   0:dt:TimeSimulation ;

%% initial state:
Estimate_nu_Rel           =   [0; 0];
nu                        =   [0; 0; 0];
initial_state_of_vessels  =   [eta; [Estimate_nu_Rel; 0]; [Estimate_nu_Rel; 0]; [Estimate_nu_Rel ;0]; [Estimate_nu_Rel ; 0] ];   %%????????
tau1                      =   [0;0;0]; 
dv(:,1)                   =   zeros(3,1);
dv(:,2)                   =   zeros(3,1);
    
Hi                        =   InitialStatesShip(3);
 eta_Ship                  =   InitialStatesShip;
nu_Ship                   =   [Estimate_nu_Rel ;0];
eta_ref                   =  InitialStatesShip;
eta_ref1           =  InitialStatesShip;
%% wave and baias
Hx                        =   2;  %
Hy                        =   1;
Hpsi                      =   1;
[w,F ]                    =   funcwave(TimeSimulation,Hx,Hy,Hpsi);
%% sea force 2 (6-10 knot fpr wind, 0.6-1 m for high wave)
Vwind                     =    20;
Vwave                     =    2;
g_wind                    =    0;
g_wave                    =    25;
CurrentWaterIsEnable      =    1;
GainWindForce             =    1;
GainPosition              =    1;
GainHeading               =    1;
 
%% main Loop Of Algorithm

for i  =  1:TimeSimulation/dt
    %% Noise Of Sensor
    [eta_noise_Ob,nu_noise_Ob] = Sensors_measurement(eta_Ship,nu_Ship);
    %% wave2 + Noise Of Sensor
    eta_noise_Ob          = eta_noise_Ob+w(i,:)';
    %% Wind
    nu_abs                = nu_noise_Ob+0*[Vwave*cos(g_wave);Vwave*sin(g_wave);0];
    Psiwind               = Hi;
    %tau_wind =fcn_wind(nu_abs,Psiwind,Vwind,g_wind);
    tau_wind              = [0;0;0];
    %% Observer
    %tic
%     eta_noise_Ob(3) = eta_noise_Ob(3);
    [Estimate_nu_Rel,eta_obs,nu_absout,dv] = Nonlinear_Observer...
        (nu_noise_Ob(1:2),eta_noise_Ob,nu_abs,tau1,tau_wind,dt,initial_state_of_vessels,Flag);
    %toc
    
    %% Guidance
    [eta_ref]  =  Guidance_Forces(x,y,psi,InitialStatesShip,U,dt,eta_Ship,Flag);
   
    %% controller
    VesselState           =  eta_obs;
    VesselDeltaState      =  eta_ref-eta_obs';
    VesselVelocity        =  nu_absout;
    VesselAcceleration    =  dv';
     WindForce             =  -tau_wind;
    VesselToWaterVelocity =  Estimate_nu_Rel;
    [tau1]                =  ControllerPID_DP(VesselState,VesselDeltaState, VesselVelocity,VesselAcceleration,VesselToWaterVelocity,WindForce,GainWindForce,GainPosition,GainHeading,dt,variableDesision,Flag);
    
    %% ship
    [nu_Ship,eta_Ship,dv_Ship] = Simulator_Of_Vessels(tau1,tau_wind,dt,initial_state_of_vessels,Flag);
    
    Hi                    = eta_Ship(3);
   
     %% results
    M_eta(:,i)            = eta_obs';
    M_nu(:,i)             = [Estimate_nu_Rel  nu_absout(3) ]';
    Ship_eta(:,i)         = eta_noise_Ob';
    Ship_nu(:,i)          = nu_noise_Ob'; 
    Estimate_nu_Rel_1(:,i)= Estimate_nu_Rel;
    tau(:,i)              = tau1;
    eta_ref1(:,i)         = eta_ref;
    tau_wind1(:,i)        = tau_wind;
    nu_absIn(:,i)         = nu_abs;
    nu_abs1(:,i)          = nu_absout;
    dv1(:,i)              = dv;
    z(:,i)                = VesselDeltaState;
    zz(:,i)               =eta_ref  ;
    SavePosition.Observer(:,i)=eta_obs';
    SavePosition.Refrences(:,i)=eta_ref1(:,i) ;
  Flag=false;
    %SavePosition.Refrences(:,1)=InitialStatesShip;
end

% figure(1111)
% plot(t(1:i),Ship_eta(1,:),'r',t(1:i),M_eta(1,:),'b',t(1:i),(eta_ref1(1,:)),'k')
% ylabel('surg')
% xlabel('Times')
% legend('Noisy Surge','Observed Surg','Reference')
% figure(2222)
% plot(t(1:i),Ship_eta(2,:),'r',t(1:i),M_eta(2,:),'b',t(1:i),(eta_ref1(2,:)),'k')
% ylabel('sway')
% xlabel('Times')
% legend('Noisy Sway','Observed Sway','Reference')
% 
% 
% figure(3333)
% plot(t(1:i),Ship_eta(3,:),'r',t(1:i),M_eta(3,:),'b',t(1:i),(eta_ref1(3,:)),'k')
% ylabel('yaw')
% xlabel('Times')
% legend('Noisy Yaw','Observed Yaw','Reference')
