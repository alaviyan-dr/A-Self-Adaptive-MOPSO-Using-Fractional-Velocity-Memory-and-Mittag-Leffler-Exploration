function [DesiredPosition   ]   = Guidance_Forces(Rxsp,Rysp,psi,LL,U,dt,eta_Ship,Flag)
dt=0.1;
persistent   L Data
% if Flag == 1
%     L = zeros(3);
%     Data = zeros(3);
%     Flag=0;
% end


if isempty(Data)|| Flag
    Data=zeros(3);
end
if isempty(L)||Flag
    L=zeros(3);
end
Hi=deg2rad(eta_Ship(3));

Rx=Rxsp-LL(1);
Ry=Rysp-LL(2);
yaw=deg2rad(psi)-deg2rad(LL(3));

Rmat=[cos(Hi) -sin(Hi)
    sin(Hi)   cos(Hi)];

tetha=atan2(Ry,Rx)-Hi;
vx=U*cos(tetha);
vy=U*sin(tetha);
Uin=Rmat*[vx;vy];

Reference=diag([Rx Ry yaw]);
if abs(Rx)>70
    gainx=150;
else
    gainx=70;
end

if abs(Ry)>70
    gainy=80;
else
    gainy=10;
end

gainz=2*pi;

if(Rx~=0)
    Rxx=Rx;
else
    Rxx=0.1*gainx;
end


if(Ry~=0)
    Ryy=Ry;
else
    Ryy=0.1*gainy;
end

if(yaw~=0)
    yaww=yaw;
else
    yaww=0.77*gainz;
end

LimNu= abs([((Rxx)/gainx)*Uin(1);((Ryy)/(gainy))*Uin(2);((yaww)/(gainz))*0.045]);
LimAcc=abs([Uin(1);Uin(2);0.027]);

w=diag([0.13 0.13 0.1]);
z=diag([1 1 1]);




Ld=(Reference-L)*w;
L=L+Ld*dt;
Lp=diag(L*w^3);


etadd=Data(1:3,1);
etad=Data(1:3,2);
eta=Data(1:3,3);
a0=diag((2*z+1)*w);
a1=diag((2*z+1)*w^2);
a2=diag(w^3);
etap=Lp-a0.*etadd-a1.*etad-a2.*eta;
etadd=etadd+etap*dt;
for i=1:3
    if abs(etadd(i))>LimAcc(i)
        etadd(i)=sign(etadd(i))*LimAcc(i);
    end
end

etad=etad+etadd*dt;
for i=1:3
    if abs(etad(i))>LimNu(i)
        etad(i)=sign(etad(i))*LimNu(i);
    end
end
eta=eta+etad*dt;
Data=[etadd etad eta];

eta(3) = rad2deg(eta(3));

DesiredPosition=eta+LL;
Flag=false;
end


