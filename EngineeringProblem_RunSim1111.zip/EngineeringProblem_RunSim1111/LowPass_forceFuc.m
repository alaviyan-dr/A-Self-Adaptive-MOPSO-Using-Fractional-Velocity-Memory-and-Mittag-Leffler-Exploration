% function dx = LowPass_forceFuc(t,xt,tau)
function dx = LowPass_forceFuc(xt,tau)
T1=tau(1);
T2=tau(2);
T3=tau(3);
dx      =    zeros(3,1);

dx(1)   =   0.8*( -xt(1)+T1);
dx(2)   =    0.8*(-xt(2)+T2);

dx(3)   =    0.8*( -xt(3)+T3);
end