function [Estimate_nu_Rel,Estimate_eta,Estimate_nu_Abs,Estimate_nudot_Rel] = Nonlinear_Observer...
    (nu_Rel,eta,nu_Abs,tau,tau_wind ,dt,Initial_state_Of_Observer,Flag)
%==============================Inputs======================================
% eta      = [x,y,psi]        : Position(meter) measurement in local coordinate &
                               % heading (degree) measurement from Gyro in NED coordinate
% nu_Rel   = [ur,vr]          : Relative Speed (meter per second) from Speedlog in Body coordinat
% nu_Abs   = [u_abs,v_abs ,r] : Absolute Speed (meter per second) from Speedlog in Body coordinat &
                               % Heading  Speed from Gyro in NED coordinate
% tau      = [XP,YP,NP]       : Feedback Forces and moment from Thrust Allocation
% tau_wind = [Xw,Yw,Nw]       : Forces and moment from wind
% IsDataValid                 : Boolean [Yes or No] - if dead reckoning is needed ====>IsDataValid =Yes else ===> IsDataValid =No
% dt                          : Step time
% Initial_state_Of_Observer   : [xhat yhat psihat b1hat b2hat b3hat uhat vhat rhat khi1 khi2 khi3 khi4 khi5 khi6]        
%==========================================================================
%=============================Outputs======================================
% Estimate_nu_Rel    = [ur,vr]               : Relative  Speed estimate  in Body coordinat
% Estimate_eta       = [x_es,y_es,psi_es]    : Position  estimate in local coordinate & 
                                               % Heading  Speed estimate in NED coordinate

% Estimate_nu_Abs    = [u_abs,v_abs ,r]      : Absolute  Speed estimate  in Body coordinat                                             
% Estimate_nudot_Rel = [ur_dot,vr_dot,r_dot] : acceleration estimate in Body coordinat
%==========================================================================
persistent state_int_Obs;
if isempty(state_int_Obs)||Flag
   state_int_Obs   =   Initial_state_Of_Observer';
   state_int_Obs(3)=0.01745 *(state_int_Obs(3));
   state_int_Obs(9)=0.01745*state_int_Obs(9);
   
end

persistent cont;
if isempty(cont)||Flag
   cont   =  0;
end
cont=cont+1;
eta(3)=0.01745*eta(3);
nu_Abs(3)=0.01745*(nu_Abs(3));
if (mod(cont,1000)  == 0)
   state_int_Obs(7:9) = [nu_Rel(1) nu_Rel(2) nu_Abs(3)];
end

XP               =   tau(1);
YP               =   tau(2);
NP               =   tau(3);


%% parameters of Ship model
m                = 100000;    % mass of rigid body
xg               = -1.4;      % center of gravity
mx               = 7e+03;  
my               = 210e+03;
Jz               = 12.822e+06; 
Izg              = 30e+06;    % moments of inertia
M                = [m+mx  0      0;...
                     0   m+my   m*xg;...
                     0   m*xg  (Izg+m*xg^2+Jz)];  % Inertia Matrice

 %% parameters of nonlinear ship model
rho              = 1025;               % density of water
L                = 30;                 % Length of between two Draft
Di               = 0.53;               % Inner Draft
Do               = 0.98;               % Outer Draft
d                = (Di+Do)/2;          % Mean Draft

vm               = nu_Rel(2);
u                = nu_Rel(1);
r                = nu_Abs(3);
U                = sqrt(u^2+vm^2);
 
%=======================HULL Force and Moment==============================

vmp               = vm/U;
rp                = (r*L)/U;

if vm   ==  0
    vmp  = 0;
end

if r    == 0
    rp   =  0;
end

R0p                = 0.088;
Xvv                = -0.02;
Xrr                = -0.174;
Xvr                = 0.09;

%%Sway%%
Yv                 = -0.37;
YR                 = -0.021;
Yvvv               = -1.9;  
Yvvr               = 0.45;
Yvrr               = -1.7;
Yrrr               = 1.5;

%%Yaw%%
Nv                 = -0.13;
NR                 = -0.066;
Nvvv               = -0.041;
Nvvr               = -1.14;
Nvrr               = 0.126;
Nrrr               = -0.76;

XHp                = -R0p*sign(u)+(Xvv*vmp^2)+(Xvr*vmp*rp)+(Xrr*rp^2);
YHp                = (Yv*vmp)+(YR*rp)+(Yvvv*vmp^3)+(Yvvr*vmp*abs(vmp)*rp)+(Yvrr*vmp*rp*abs(rp))+(Yrrr*rp^3);
NHp                = (Nv*vmp)+(NR*rp)+(Nvvv*vmp^3)+(Nvvr*vmp*abs(vmp)*rp)+(Nvrr*vmp*rp*abs(rp))+(Nrrr*rp^3);

XH                 = XHp*0.5*rho*L*d*U^2;
YH                 = YHp*0.5*rho*L*d*U^2;
NH                 = NHp*0.5*rho*L^2*d*U^2;

%=================== Sum of Force and Moment===============================
X                  = XH+XP+tau_wind(1);
Y                  = YH+YP+tau_wind(2);
N                  = NH+NP+tau_wind(3);

X1                 = X+((m+my)*nu_Abs(2)*nu_Abs(3))+(xg*m*nu_Abs(3)^2);
Y1                 = Y-(m+mx)*nu_Abs(3)*nu_Abs(1);
N1                 = N-(m*xg*nu_Abs(1)*nu_Abs(3));

F                  = [X1;Y1;N1];
A                  = (M)\F;
udot               = A(1,1);
vdot               = A(2,1);
rdot               = A(3,1);

%% ===================== Parameters of Observer and filter ================
%  ======================Determination of the Observer Gains===============
lambda             = 0.1;    % relative damping ratio of the wave spectrum
wo                 = 0.897;  % wave spectrum peak frequency
wc                 = 1.1;    % cutoff frequency

K1                 = [-2*(1-lambda)*(wc/wo)*eye(3)    % A function of the wave spectra peak frequencies...
                        2*wo*(1-lambda)*eye(3)];      % in surge, sway and yaw.
K2                 = diag([wc wc wc]);

K4                 = diag([0.1 0.1 0.01]);

K3                 = 0.1*K4;

A21                = -diag([wo;wo;wo]);

A22                = -2.*diag([wo;wo;wo]).*diag([lambda;lambda;lambda]);

Aw                 = [zeros(3) eye(3)
                        A21     A22];
    
Cw                 = [zeros(3) eye(3)];

INVT               = 0.001*eye(3);         % T: bias time constants

phi                = eta(3);

R                  = [cos(phi) -sin(phi) 0;sin(phi) cos(phi) 0;0 0 1];

Etahat             = state_int_Obs(1:3)';
bhat               = state_int_Obs(4:6)';
vhat               = state_int_Obs(7:9)';
khihat             = state_int_Obs(10:15)';

%% formulation of observer
yhat               = Etahat+Cw*khihat;
etaTilda           = eta-yhat;                    %Estimation Error
etaTilda(3)        = phi_limiter(etaTilda(3));

khiDot             = Aw*khihat+K1*etaTilda;

EtaTildaDot        = R*vhat+K2*etaTilda;

BhatDot            = -INVT*bhat+K3*etaTilda;
ans                =(R'*K4*etaTilda+R'*bhat);
VhatDot1            = M\ans;
VhatDot            = VhatDot1+[udot;vdot;rdot];
E                  = EtaTildaDot;
B                  = BhatDot;
V                  = VhatDot;
Khi                = khiDot;

dx(1)              = E(1);
dx(2)              = E(2);
dx(3)              = E(3);
dx(4)              = B(1);
dx(5)              = B(2);
dx(6)              = B(3);
dx(7)              = V(1);
dx(8)              = V(2);
dx(9)              = V(3);
dx(10)             = Khi(1);
dx(11)             = Khi(2);
dx(12)             = Khi(3);
dx(13)             = Khi(4);
dx(14)             = Khi(5);
dx(15)             = Khi(6);

%h                  = 0.01;    %step size
h                  = 0.1;    %step size
%%%%%%%%%%%%%%%%%%%%%%%%
%%
% st=state_int_Obs+dx*dt;
% 
% options =  odeset('RelTol',1e-6,'AbsTol',1e-6);
% [~,Y1xx]   =  ode45(@(t,x)simulate_observer(t,x,dx),[0 dt],state_int_Obs',options);
% 
% vhatx   =    Y1xx(end,7:9);
% Etax     =    Y1xx(end,1:3 );
% bhatx    =    Y1xx(end,4:6);
% khihatx  =   Y1xx(end,10:15);

%%
Y1x                = runge_kutta1(state_int_Obs,dt,h,dx)';
% Error=Y1x-Y1xx(end,:);
% 
% Error2=st-Y1xx(end,:);
% 
% if (max(abs(Error2))>10^(-13))
%     max(abs(Error2))
% end
% 
% if (max(abs(Error))>10^(-13))
%     max(abs(Error))
% end
vhat               = Y1x(7:9);
Eta                = Y1x(1:3);
bhat               = Y1x(4:6);
khihat             = Y1x(10:15);
%Eta(3)             = deg2rad(Eta(3));
Eta(3)             = phi_limiter(Eta(3));
Eta(3)              =57.295779513082*(Eta(3));
Estimate_eta       = Eta;
Estimate_nu        = vhat;
Estimate_nu(3)        =57.295779513082* vhat(3);

state_int_Obs      = Y1x; 
Estimate_nudot_Rel = VhatDot;
u_current          = nu_Abs(1)-Estimate_nu(1);
v_current          = nu_Abs(2)-Estimate_nu(2);

outputSurgeSpeed   = Estimate_nu(1)+u_current;
outputSwaySpeed    = Estimate_nu(2)+v_current;
Estimate_nu_Abs    = [outputSurgeSpeed;outputSwaySpeed;Estimate_nu(3)];
Estimate_nu_Rel    = Estimate_nu(1:2);
Flag=false;
end