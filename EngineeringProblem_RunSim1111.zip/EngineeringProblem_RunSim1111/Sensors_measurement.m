function [eta,nu] = Sensors_measurement(eta,nu)
roll=0; pitch =0;
%==========Gyro======================

heading_Gyro = eta(3) + 0.1*randn;
roll =roll +0.01*randn;
pitch = pitch +0.01*randn;

%=========GPS=======================
lat_Gps = eta(1) + 0.8* randn;
lon_Gps = eta(2) + 0.8* randn;

%========MRU=======================
roll =roll +0.5*randn;
pitch = pitch +0.5*randn;
heading_MRU = rad2deg(eta(3)) + 2* randn;

%%
% eta(3) =deg2rad(0.5*heading_MRU+0.5*heading_Gyro);
eta(3) = heading_Gyro;
eta(1) = lat_Gps;
eta(2) = lon_Gps;
