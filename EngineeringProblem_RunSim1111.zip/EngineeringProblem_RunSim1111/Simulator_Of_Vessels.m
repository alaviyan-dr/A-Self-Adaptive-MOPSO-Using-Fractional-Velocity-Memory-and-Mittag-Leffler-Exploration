function [nu,eta,dv]=Simulator_Of_Vessels(tau,tau_wind,dt,initial_state_of_vessels,Flag)
initial_state_of_vessels(3)=deg2rad(initial_state_of_vessels(3));
persistent state_int_vessel
if isempty(state_int_vessel)||Flag
    state_int_vessel=[initial_state_of_vessels(4:6)  initial_state_of_vessels(1:3)];
end

XP              =   tau(1)+tau_wind(1);
YP              =   tau(2)+tau_wind(2);
NP              =   tau(3)+tau_wind(3);
u               =   state_int_vessel(1);
v               =   state_int_vessel(2);
r               =   state_int_vessel(3);
rho             =   1025;
L               =   30;
Di              =  0.53;               % Inner Draft
Do              =  0.98;               % Inner Draft
d               =  (Di+Do)/2;           % Mean Draft
m                = 100000;    % mass of rigid body
xg               = -1.4;      % center of gravity
mx               = 7e+03;  
my               = 210e+03;
Jz               = 12.822e+06; 
Izg              = 30e+06;    % moments of inertia
vm              =   v;
U               =   sqrt(u^2+vm^2);

%%%%%HULL Force and Moment%%%%%%%
vmp             =   vm/U;
rp              =   (r*L)/U;

if vm == 0
    vmp         = 0;
end

if r == 0
    rp          = 0;
end
%%Surge%%%
R0p             =   0.088;
Xvv             =   -0.02;
Xrr             =   -0.174;
Xvr             =   0.09;

%%Sway%%
Yv              =   -0.37;
YR              =   -0.021;
Yvvv            =   -1.9;
Yvvr            =   0.45;
Yvrr            =   -1.7;
Yrrr            =   1.5;

%%Yaw%%
Nv              =   -0.13;
NR              =   -0.066;
Nvvv            =   -0.041;
Nvvr            =   -1.4;
Nvrr            =   0.126;
Nrrr            =   -0.766;

%==========================================================================
XHp             =   -R0p*sign(u)+(Xvv*vmp^2)+(Xvr*vmp*rp)+(Xrr*rp^2);
YHp             =  (Yv*vmp)+(YR*rp)+(Yvvv*vmp^3)+(Yvvr*vmp*abs(vmp)*rp)+(Yvrr*vmp*rp*abs(rp))+(Yrrr*rp^3);
NHp             =  (Nv*vmp)+(NR*rp)+(Nvvv*vmp^3)+(Nvvr*vmp*abs(vmp)*rp)+(Nvrr*vmp*rp*abs(rp))+(Nrrr*rp^3);

XH              =   XHp*0.5*rho*L*d*U^2;
YH              =   YHp*0.5*rho*L*d*U^2;
NH              =   NHp*0.5*rho*L^2*d*U^2;

%%%%%%% Sum of Force and Moment
X               =  XH+XP;
Y               =  YH+YP;
N               =  NH+NP;



M1              =  [m+mx      0        0;...
                    0       m+my     m*xg;...
                    0       m*xg   (Izg+m*xg^2+Jz)];

X1              =  X+((m+my)*vm*r)+(xg*m*r^2);
Y1              =  Y-(m+mx)*r*u;
N1              =  N-(m*xg*u*r);

F               =  [X1;Y1;N1];
A               =  (M1)\F;

udot            =   A(1,1);
vdot            =   A(2,1);
rdot            =   A(3,1);

options         =  odeset('RelTol',1e-6,'AbsTol',1e-6);
[~,Y1x]         =  ode45(@(t,x)simulate_vessel(t,x,udot,vdot,rdot),[0 dt],state_int_vessel,options);
eta             =  Y1x(end,4:6)';
%eta(3)         = deg2rad(eta(3));
eta(3)          =  phi_limiter(eta(3));
eta(3)          =  rad2deg(eta(3));
nu              =  Y1x(end,1:3)';
nu(3)           =  rad2deg(1)*nu(3);
dv=[udot; vdot; rdot];
state_int_vessel=  Y1x(end,:);
Flag=false;