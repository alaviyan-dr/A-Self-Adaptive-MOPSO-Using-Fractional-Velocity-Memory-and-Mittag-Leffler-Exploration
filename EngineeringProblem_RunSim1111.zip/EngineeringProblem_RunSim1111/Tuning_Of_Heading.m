function  [psi,psi0]=Tuning_Of_Heading(psi,psi0)
psi=wrapTo360(psi);
psi0=wrapTo360(psi0);

if abs (psi-psi0) > 180
    psi=wrapTo180(psi);
    psi0=wrapTo180(psi0);
end