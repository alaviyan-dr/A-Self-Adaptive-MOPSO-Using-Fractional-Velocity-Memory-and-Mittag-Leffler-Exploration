function dx =deadzoon(eta_error)

if( abs(eta_error(1))<0.5)
   eta_error(1)=0;
end

if( abs(eta_error(2))<0.3)
   eta_error(2)=0;
end

if( abs(eta_error(3))<0.5*deg2rad(1))
   eta_error(3)=0;
end


dx=eta_error;
