function dx1= dxxx(t,x1,xx)
%% dx1   & xx are double[15], t and x is variable
dx1=zeros(15,1);
dx1=xx';
end