function [w,F ]   = funcwave(TimeSimulation,Hx,Hy,Hpsi)
dt=0.1;
t =dt:dt:TimeSimulation ;
impulse = t==0;
unitstep = t>=0;
ramp = t.*unitstep;
RR=ramp/TimeSimulation;
% figure()
% plot(RR)
%% wave1
z  = 0.10;                % damping ratio
alpha_low  = 0.95;        % fractional order for low-frequency waves
alpha_high = 0.85;        % fractional order for high-frequency waves
N  = 5;                   % order of Oustaloup approximation
wb = 0.01;                % lower frequency bound (rad/s)
wh = 10;                  % upper frequency bound (rad/s)

% --------- Define fractional variable
s = fotf('s');

%% =====================  SURGE  (x-axis) ========================
wnx = 0.897;              % natural frequency in surge
Kx  = 2*0.1*wnx*0.1;      % system gain
Gx_frac = Kx * s^alpha_low / (s^(2*alpha_low)  + 2*z*wnx*s^alpha_low  + wnx^2);
sysFracX = oustapp(Gx_frac, wb, wh, N, 'oust');

%% =====================  SWAY  (y-axis) =========================
wny = 0.750;
Ky  = 2*0.1*wny*0.1;
Gy_frac = Ky * s^alpha_low / (s^(2*alpha_low) + 2*z*wny*s^ alpha_low + wny^2);
sysFracY = oustapp(Gy_frac, wb, wh, N, 'oust');

%% =====================  YAW  (ψ-axis) ==========================
wnpsi = 0.650;
Kpsi  = 2*0.1*wnpsi*0.1;
Gpsi_frac = Kpsi * s^alpha_high / (s^(2*alpha_high) + 2*z*wnpsi*s^alpha_high + wnpsi^2);
sysFracPsi = oustapp(Gpsi_frac, wb, wh, N, 'oust');

%% =====================  Export for Simulink ====================
[numX, denX] = tfdata(sysFracX, 'v');
[numY, denY] = tfdata(sysFracY, 'v');
[numPsi, denPsi] = tfdata(sysFracPsi, 'v');

H1=tf(numX,denX);
h11=step(H1,t);
H2=tf(numY,denY);
h22=step(H2,t);
H3=tf(numPsi,denPsi);
h33=step(H3,t);
 no1=randn(size(h11)); no2=randn(size(h22)); no3=randn(size(h33));


wf2x=conv(Hx*h11,no1);
wf2y=conv(Hy*h22,no2);
wf2z=conv(Hpsi*h33,no3);

%w2=[wf2x wf2y deg2rad(wf2z)];
w2=[wf2x wf2y (wf2z)];

[b,~]=size(w2);
w = w2(1 : floor(b/2) + 1, :);
% figure(1111)
%  plot(w)
%  xlabel('Time Second')
%  ylabel('Amplitute of wave')
% 
%  legend('low-frequency component in Surge','low-frequency component in Sway','low-frequency component in Yaw')
%% wave 2
Gb_fra=1/(s^alpha_low+0.001);
sysFracBaias= oustapp(Gb_fra, wb, wh, N, 'oust');
[numb, denb] = tfdata(sysFracBaias, 'v');

Hb=tf(numb,denb);
h11b=step(Hb,t);


FF=conv(h11b,no1);
[a,~]=size(FF);
F1 = FF( floor(a/2)+1 : end , : );
B0=-[6000 5000 90000].*ones(size(F1));
 F=[F1 F1 F1]+B0.*RR';
% figure(22222)
% plot(F)
% legend('ship–bias–wave Forces')
%  xlabel('Time Second')
% ylabel('Forces')
end
% 
% function [w,F ]   = funcwave(TimeSimulation,Hx,Hy,Hpsi)
% global dt
% t =dt:dt:TimeSimulation ;
% impulse = t==0;
% unitstep = t>=0;
% ramp = t.*unitstep;
% RR=ramp/TimeSimulation;
% % figure()
% % plot(RR)
% %% wave1
% wn=0.897;
% z=0.1;
% s=tf('s');
% H1=(2*0.1*wn*0.1)*s/(s^2+2*z*wn*s+wn^2);
% h11=step(H1,t);
%  no=randn(size(h11));
% wf2x=conv(Hx*h11,no);
% wf2y=conv(Hy*h11,no);
% wf2z=conv(Hpsi*h11,no);
% 
% %w2=[wf2x wf2y deg2rad(wf2z)];
% w2=[wf2x wf2y (wf2z)];
% 
% [b,~]=size(w2);
% w=w2(1:b/2+1,:);
% % figure(1111)
% %  plot(w)
% %  legend('WF')
% %% wave 2
% b=1/(s+0.001);
% h22=step(b,t);
% FF=conv(h22,no);
% [a,~]=size(FF);
% F1=FF(a/2:end,:);
% B0=-[6000 5000 90000].*ones(size(F1));
%  F=[F1 F1 F1]+B0.*RR';
% % figure(22222)
% % plot(F)
% % legend('ship–bias–wave Forces')
% end