function [PHI]=phi_limiter(phi)
if phi>1e10
    phi=1e10;
elseif phi<-1e10
    phi=-1e10;
end
PHI=rem((phi+(pi*sign(phi))),2*pi)-(pi*sign(phi));