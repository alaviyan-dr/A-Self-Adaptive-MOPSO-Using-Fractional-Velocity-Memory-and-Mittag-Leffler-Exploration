function dx = simulate_vessel(t,x,udot,vdot,rdot)

   %% Add current 
% nu(:,1)=nu(:,1)+0.3*sin(i+3/2*pi);
% nu(:,2)=nu(:,2)+0.1*sin(i+1/2*pi);

dx      =    zeros(6,1);
dx(1)   =    udot;
dx(2)   =    vdot;
dx(3)   =    rdot;

% dx(4)   =    x(1)*cos(x(6))-x(2)*sin(x(6))+0*sin(0.02*t+3/2*pi);
% dx(5)   =    x(1)*sin(x(6))+x(2)*cos(x(6))+0*cos(0.02*t+3/2*pi);
dx(4)   =    x(1)*cos(x(6))-x(2)*sin(x(6));
dx(5)   =    x(1)*sin(x(6))+x(2)*cos(x(6));

dx(6)   =    x(3);
end