%% Main SA-MOPSO-FVML Optimization Program
% Author: Based on Dr Esmat Sadat Alaviyan Shahri's framework
% Date: 2024

clear all; close all; clc;

%% Problem Parameters (User Defined)
initialStates = [0; 1; 0];           % [x0; y0; psi0]
GoolPoints = [50; -12; 56];               % [x_target; y_target; psi_target]
TimeSimulation = 400;                  % Simulation time (seconds)
   
% Variable bounds
% VarMin = [300, 1000, 0.3e6, -20000, -90000, -2e7, -400, -480, -2000, -5,0, 0];
VarMin = [300, 1000, 0.3e6, -20000, -90000, -2e7, -400, -480, -2000, -5,0, 0];

VarMax = [1200, 6000, 2.1e6, -8000, -30000, -2.e6, -200, -200, -600, 10, 20, 500];

% Number of design variables
nVar = numel(VarMax);

% Number of Pareto points to find
nParetoPoints = 20;

%% Algorithm Parameters - SA-MOPSO-FVML
SAMOPSO_Params.MaxIt = 14;          % Maximum iterations
SAMOPSO_Params.nPop = 50;           % Population size
SAMOPSO_Params.alpha = 0.7;         % SA memory parameter
SAMOPSO_Params.a_param = 0.5;       % Sigmoid parameter a
SAMOPSO_Params.b_param = 10;        % Sigmoid parameter b
SAMOPSO_Params.c1 = 1.5;            % Cognitive coefficient
SAMOPSO_Params.c2 = 1.5;            % Social coefficient
SAMOPSO_Params.ml_alpha = 0.8;      % Mittag-Leffler alpha
SAMOPSO_Params.ml_beta = 1.0;       % Mittag-Leffler beta

%% Run SA-MOPSO-FVML
fprintf('Running SA-MOPSO-FVML Algorithm...\n');
tic;
[Pareto_SAMOPSO, ParetoPositions_SAMOPSO] = SAMOPSO_FVML_Optimization(...
    initialStates, GoolPoints, TimeSimulation, ...
    nVar, VarMin, VarMax, SAMOPSO_Params, nParetoPoints);
time_SAMOPSO = toc;
fprintf('SA-MOPSO-FVML completed in %.2f seconds\n', time_SAMOPSO);

%% Display Parameter Ranges
fprintf('====== PARAMETER RANGES ======\n');
param_names = {'Kp_surge', 'Kp_sway', 'Kp_yaw', ...
               'Kd_surge', 'Kd_sway', 'Kd_yaw', ...
               'Kd1_surge', 'Kd1_sway', 'Kd1_yaw', ...
               'Ki_surge', 'Ki_sway', 'Ki_yaw'};

fprintf('\nResults Summary\n');
% SA-MOPSO-FVML Best
[~, best_samopso_idx] = min(sqrt(sum(Pareto_SAMOPSO.Cost.^2, 2)));
fprintf('SA-MOPSO-FVML Best Solution (Index %d):\n', best_samopso_idx);
fprintf('  Costs: [%.4f, %.4f, %.4f]\n', Pareto_SAMOPSO.Cost(best_samopso_idx, :));
fprintf('  Parameters:\n');
for i = 1:nVar
    fprintf('    %10s = %10.4f\n', param_names{i}, Pareto_SAMOPSO.Position(best_samopso_idx, i));
end
Flag=false;
%% Plot Results
PlotResults_SAMOPSO(Pareto_SAMOPSO, ParetoPositions_SAMOPSO);

Flag=true;
VarExample = [ ...
    1140.5735,      6000,      1820118.4256,  ...
   -8000.0000, -32971.9637, -10052162.7446, ...
     -288.7435,  -233.6433,  -1311.8957, ...
        4,      9.8841,    282.7717 ];
%% Get reference trajectory
initialStatesS1 = [10;3; 5];           % [x0; y0; psi0]
GoolPointsS1 = [17; 6; 26];               % [x_target; y_target; psi_target]
[~, Refrences, SaveExampleS1] = CostFunctionDPShip(initialStatesS1, GoolPointsS1, ...
    TimeSimulation, VarExample,Flag);
 RmsS1=rms(SaveExampleS1.Observer')
 MaxS1=max(SaveExampleS1.Observer')
Flag=true;
initialStatesS2 = [0; 1;0];           % [x0; y0; psi0]
GoolPointsS2 = [50; -12; 56];               % [x_target; y_target; psi_target]
 [~, Refrences, SaveExampleS2] = CostFunctionDPShip(initialStatesS2, GoolPointsS2, ...
    TimeSimulation, VarExample,Flag);
  RmsS2=rms(SaveExampleS2.Observer')
   MaxS2=max(SaveExampleS2.Observer')
   time = linspace(0, size(SaveExampleS2.Observer,2)*0.1, size(SaveExampleS2.Observer,2));
   figure('Position', [100 100 900 400]);
subplot(3,1,1)
hold on; grid on;

plot(time, SaveExampleS1.Refrences(1,:), 'k--', 'LineWidth', 2);
plot(time, SaveExampleS1.Observer(1,:), 'b--', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Surge (m)');
title('Surge Response for Scenario 1');

%  SWAY RESPONSE - ALL PARETO
% =======================
subplot(3,1,2)
hold on
plot(time, SaveExampleS1.Refrences(2,:), 'k--', 'LineWidth', 2);
plot(time, SaveExampleS1.Observer(2,:), 'b--', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Sway (m)');
title('Sway Response for Scenario 1');
%% =======================
%  YAW RESPONSE - ALL PARETO
% =======================
subplot(3,1,3)
hold on
plot(time, SaveExampleS1.Refrences(3,:), 'k--', 'LineWidth', 2);
plot(time, SaveExampleS1.Observer(3,:), 'b--', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Yaw (rad)');
title('Yaw Response for Scenario 1');

figure('Position', [100 100 900 400]);
subplot(3,1,1)
hold on; grid on;

plot(time, SaveExampleS2.Refrences(1,:), 'k--', 'LineWidth', 2);
plot(time, SaveExampleS2.Observer(1,:), 'b--', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Surge (m)');
title('Surge Response for Scenario 2');

%  SWAY RESPONSE - ALL PARETO
% =======================
subplot(3,1,2)
hold on
plot(time, SaveExampleS2.Refrences(2,:), 'k--', 'LineWidth', 2);
plot(time, SaveExampleS2.Observer(2,:), 'b--', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Sway (m)');
title('Sway Response for Scenario 2');
%% =======================
%  YAW RESPONSE - ALL PARETO
% =======================
subplot(3,1,3)
hold on
plot(time, SaveExampleS2.Refrences(3,:), 'k--', 'LineWidth', 2);
plot(time, SaveExampleS2.Observer(3,:), 'b--', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Yaw (rad)');
title('Yaw Response for Scenario 2');


%% Save Results
save('SAMOPSO_FVML_Results.mat', 'Pareto_SAMOPSO', ...
    'ParetoPositions_SAMOPSO', ...
    'SAMOPSO_Params', 'time_SAMOPSO', ...
    'initialStates', 'GoolPoints', 'TimeSimulation', ...
    'VarMin', 'VarMax', 'Refrences', 'param_names');

fprintf('\n====== RESULTS SAVED ======\n');
fprintf('File: SAMOPSO_FVML_Results.mat\n');
fprintf('Contents: Pareto fronts, positions, parameters, and algorithm settings\n');

%% ========================================================================

%% ========================================================================
%  SA-MOPSO-FVML OPTIMIZATION FUNCTION
%  ========================================================================
function [ParetoFront, ParetoPositions] = SAMOPSO_FVML_Optimization(...
    initialStates, GoolPoints, TimeSimulation, ...
    nVar, VarMin, VarMax, Params, nParetoPoints)

    MaxIt = Params.MaxIt;
    nPop = Params.nPop;
    alpha = Params.alpha;
    a_param = Params.a_param;
    b_param = Params.b_param;
    c1 = Params.c1;
    c2 = Params.c2;
    ml_alpha = Params.ml_alpha;
    ml_beta = Params.ml_beta;
    
    % Initialize particles
    particle.Position = [];
    particle.Velocity_hist = [];
    particle.Cost = [];
    particle.Best.Position = [];
    particle.Best.Cost = [];
    particle.IsDominated = false;
    
    pop = repmat(particle, nPop, 1);
    
    % Initialize population
    for i = 1:nPop
        Flag=true;
        pop(i).Position = VarMin + (VarMax - VarMin) .* rand(1, nVar);
        pop(i).Velocity_hist = zeros(4, nVar);  % Store 4 historical velocities
      pop(1).Position=[800  3000  400000 -18000 -72000 -12400000 -300 -300 -900 2.5  7.7 250];
      pop(2).Position=0.9*[800  3000  400000 -18000 -72000 -12400000 -300 -300 -900 2.5  7.7 250];
      pop(3).Position=0.8*[800  3000  400000 -18000 -72000 -12400000 -300 -300 -900 2.5  7.7 250];
      pop(4).Position=[1140.5735,      6000,      1820118.4256,  ...
   -8000.0000, -32971.9637, -10052162.7446, ...
     -288.7435,  -233.6433,  -1311.8957, ...
        4,      9.8841,    282.7717 ];
        % Evaluate cost
        [z, ~, ~] = CostFunctionDPShip(initialStates, GoolPoints, ...
            TimeSimulation, pop(i).Position,Flag);
        pop(i).Cost = [mean(abs(z(1,:))), mean(abs(z(2,:))), mean(abs(z(3,:)))];
        
        % Update personal best
        pop(i).Best.Position = pop(i).Position;
        pop(i).Best.Cost = pop(i).Cost;
    end
    
    % Initialize repository for Pareto front
    rep = pop;
    
    % Main loop
    for it = 1:MaxIt
        Flag=true;
        % Calculate all costs
        all_costs = vertcat(pop.Cost);
        
        % Calculate energy measure
        E_t = (abs(max(all_costs(:))) - abs(min(all_costs(:)))) / (abs(max(all_costs(:))) + eps);
        
        for i = 1:nPop
            % Select leader from repository
            leader = SelectLeader(rep, nVar);
            
            % Calculate adaptive weights using sigmoid function
            sigmoid_term = a_param / (1 + exp(b_param * E_t));
            w1 = alpha - sigmoid_term;
            w2 = 0.5*alpha + sigmoid_term;
            w3 = alpha*(1-alpha)/6;
            w4 = alpha*(1-alpha)*(2-alpha)/24;
            
            % Generate Mittag-Leffler random numbers (approximation)
            r1 = gamrnd(ml_alpha, ml_beta, [1, nVar]);
            r2 = gamrnd(ml_alpha, ml_beta, [1, nVar]);
            
            % Velocity update with self-adaptive memory
            v_new = w1*pop(i).Velocity_hist(1,:) + w2*pop(i).Velocity_hist(2,:) + ...
                    w3*pop(i).Velocity_hist(3,:) + w4*pop(i).Velocity_hist(4,:) + ...
                    c1.*r1.*(pop(i).Best.Position - pop(i).Position) + ...
                    c2.*r2.*(leader.Position - pop(i).Position);
            
            % Velocity clamping
            vmax = 0.4*(VarMax - VarMin);
            v_new = max(min(v_new, vmax), -vmax);
            
            % Update velocity history
            pop(i).Velocity_hist(4,:) = pop(i).Velocity_hist(3,:);
            pop(i).Velocity_hist(3,:) = pop(i).Velocity_hist(2,:);
            pop(i).Velocity_hist(2,:) = pop(i).Velocity_hist(1,:);
            pop(i).Velocity_hist(1,:) = v_new;
            
            % Update position
            pop(i).Position = pop(i).Position + v_new;
            
            % Apply bounds
            pop(i).Position = max(pop(i).Position, VarMin);
            pop(i).Position = min(pop(i).Position, VarMax);
            
            % Evaluate cost
            [z, ~, ~] = CostFunctionDPShip(initialStates, GoolPoints, ...
                TimeSimulation, pop(i).Position,Flag);
            pop(i).Cost = [mean(abs(z(1,:))), mean(abs(z(2,:))), mean(abs(z(3,:)))];
            
            % Update personal best
            if Dominates(pop(i).Cost, pop(i).Best.Cost)
                pop(i).Best.Position = pop(i).Position;
                pop(i).Best.Cost = pop(i).Cost;
            end
        end
        
        % Update repository
        rep = [rep; pop];
        rep = DetermineDomination(rep);
        rep = rep([rep.IsDominated] == false);
        
        % Limit repository size
        if length(rep) > nParetoPoints
            rep = SelectBestNPareto(rep, nParetoPoints);
        end
        
        % CRITICAL: Clear workspace variables every few iterations to prevent state contamination
        if mod(it, 1) == 0
            evalin('base', 'clear L Data cont state_int_Obs state_int_forc state_int_controller state_int_vessel');
        end
        
        % Display progress
        fprintf('SA-MOPSO-FVML Iteration %d/%d - Pareto solutions: %d\n', ...
            it, MaxIt, length(rep));
    end
    
    % Extract Pareto front and positions
    ParetoFront.Cost = reshape([rep.Cost], 3, [])';
    ParetoFront.Position = reshape([rep.Position], nVar, [])';
    
    % Get detailed SavePosition for each Pareto point
    ParetoPositions = cell(length(rep), 1);
    for i = 1:length(rep)
        [~, ~, SavePos] = CostFunctionDPShip(initialStates, GoolPoints, ...
            TimeSimulation, rep(i).Position,Flag);
        ParetoPositions{i} = SavePos;
    end
end

%% ========================================================================
%  HELPER FUNCTIONS
%  ========================================================================

function dom = Dominates(x, y)
    % Check if x dominates y
    dom = all(x <= y) && any(x < y);
end

function pop = DetermineDomination(pop)
    nPop = length(pop);
    for i = 1:nPop
        pop(i).IsDominated = false;
        for j = 1:nPop
            if i ~= j && Dominates(pop(j).Cost, pop(i).Cost)
                pop(i).IsDominated = true;
                break;
            end
        end
    end
end

function leader = SelectLeader(rep, nVar)
    % Select leader using roulette wheel selection based on crowding distance
    
    if isempty(rep)
        % If repository is empty, create a random leader
        leader.Position = rand(1, nVar);
        leader.Cost = [inf, inf, inf];
        return;
    end
    
    if length(rep) == 1
        leader = rep(1);
        return;
    end
    
    costs = reshape([rep.Cost], 3, [])';
    
    % Calculate crowding distance
    nObj = size(costs, 2);
    nRep = size(costs, 1);
    crowd_dist = zeros(nRep, 1);
    
    for j = 1:nObj
        [sorted_costs, sort_idx] = sort(costs(:, j));
        crowd_dist(sort_idx(1)) = inf;
        crowd_dist(sort_idx(end)) = inf;
        
        for i = 2:nRep-1
            if isinf(crowd_dist(sort_idx(i)))
                continue;
            end
            crowd_dist(sort_idx(i)) = crowd_dist(sort_idx(i)) + ...
                (sorted_costs(i+1) - sorted_costs(i-1)) / ...
                (sorted_costs(end) - sorted_costs(1) + eps);
        end
    end
    
    % Selection probability based on crowding distance
    prob = crowd_dist / (sum(crowd_dist) + eps);
    idx = RouletteWheelSelection(prob);
    leader = rep(idx);
end

function idx = RouletteWheelSelection(prob)
    % Roulette wheel selection
    if all(prob == 0) || any(isnan(prob)) || any(isinf(prob))
        idx = randi(length(prob));
        return;
    end
    
    r = rand;
    cumsum_prob = cumsum(prob);
    idx = find(cumsum_prob >= r, 1, 'first');
    
    if isempty(idx)
        idx = length(prob);
    end
end

function selected = SelectBestNPareto(rep, n)
    costs = reshape([rep.Cost], 3, [])';
    
    % Calculate crowding distance
    nObj = size(costs, 2);
    nRep = length(rep);
    crowd_dist = zeros(nRep, 1);
    
    for j = 1:nObj
        [sorted_costs, sort_idx] = sort(costs(:, j));
        crowd_dist(sort_idx(1)) = inf;
        crowd_dist(sort_idx(end)) = inf;
        
        for i = 2:nRep-1
            if isinf(crowd_dist(sort_idx(i)))
                continue;
            end
            crowd_dist(sort_idx(i)) = crowd_dist(sort_idx(i)) + ...
                (sorted_costs(i+1) - sorted_costs(i-1)) / ...
                (sorted_costs(end) - sorted_costs(1) + eps);
        end
    end
    
    % Select n solutions with highest crowding distance
    [~, sort_idx] = sort(crowd_dist, 'descend');
    selected = rep(sort_idx(1:min(n, nRep)));
end

%% ========================================================================
%  PLOTTING FUNCTION
%  ========================================================================
function PlotResults_SAMOPSO(Pareto_SAMOPSO, ParetoPos_SAMOPSO)
    
    % 1. 3D Pareto Front
    figure('Position', [100 100 1200 400]);
    
    subplot(1,3,1)
    scatter3(Pareto_SAMOPSO.Cost(:,1), Pareto_SAMOPSO.Cost(:,2), Pareto_SAMOPSO.Cost(:,3), ...
        50, 'filled', 'MarkerFaceColor', 'g')
    xlabel('Cost 1 (Surge Error)')
    ylabel('Cost 2 (Sway Error)')
    zlabel('Cost 3 (Yaw Error)')
    title('SA-MOPSO-FVML Pareto Front')
    grid on
    view(45, 30)
    
    % 2. 2D Projections of Pareto Front
    subplot(1,3,2)
    plot(Pareto_SAMOPSO.Cost(:,1), Pareto_SAMOPSO.Cost(:,2), 'go', 'MarkerFaceColor', 'g')
    xlabel('Cost 1 (Surge Error)')
    ylabel('Cost 2 (Sway Error)')
    title('Pareto Front: Cost 1 vs Cost 2')
    grid on
    
    subplot(1,3,3)
    plot(Pareto_SAMOPSO.Cost(:,1), Pareto_SAMOPSO.Cost(:,3), 'go', 'MarkerFaceColor', 'g')
    xlabel('Cost 1 (Surge Error)')
    ylabel('Cost 3 (Yaw Error)')
    title('Pareto Front: Cost 1 vs Cost 3')
    grid on
    
    % % 3. Sample trajectories from Pareto solutions
    % figure('Position', [100 100 1200 800]);
    % 
    % % Select 3 representative solutions from SA-MOPSO-FVML
    % nSamples = min(3, length(ParetoPos_SAMOPSO));
    % indices = round(linspace(1, length(ParetoPos_SAMOPSO), nSamples));
    % 
    % for i = 1:nSamples
    %     subplot(2, nSamples, i)
    %     SavePos = ParetoPos_SAMOPSO{indices(i)};
    %     plot(SavePos.Observer(1,:), SavePos.Observer(2,:), 'b-', 'LineWidth', 1.5)
    %     hold on
    %     plot(SavePos.Refrences(1,:), SavePos.Refrences(2,:), 'r--', 'LineWidth', 1.5)
    %     xlabel('X Position (m)')
    %     ylabel('Y Position (m)')
    %     title(sprintf('SA-MOPSO-FVML Solution %d Path', i))
    %     legend('Observed', 'Reference')
    %     grid on
    %     axis equal
    % end
    %% =======================
%  ALL PARETO TRAJECTORIES (X-Y)
% =======================
figure('Position', [100 100 900 700]);
hold on; grid on; axis equal;

nPareto = length(ParetoPos_SAMOPSO);
colors = lines(nPareto);

for i = 1:nPareto
    SavePos = ParetoPos_SAMOPSO{i};
    plot(SavePos.Observer(1,:), SavePos.Observer(2,:), ...
        'Color', colors(i,:), 'LineWidth', 1.2);
end

% Plot reference only once
plot(SavePos.Refrences(1,:), SavePos.Refrences(2,:), ...
    'k--', 'LineWidth', 2);

xlabel('X Position (m)');
ylabel('Y Position (m)');
title('All Pareto Solutions: Vessel Trajectories');
legend(['Pareto Solutions', 'Reference']);

    % % Time histories
    % for i = 1:nSamples
    %     SavePos = ParetoPos_SAMOPSO{indices(i)};
    % 
    %     % Surge
    %     subplot(2, nSamples, nSamples + i)
    %     time = linspace(0, size(SavePos.Observer,2)*0.1, size(SavePos.Observer,2));
    %     plot(time, SavePos.Observer(1,:), 'b-', 'LineWidth', 1.5)
    %     hold on
    %     plot(time, SavePos.Refrences(1,:), 'r--', 'LineWidth', 1.5)
    %     xlabel('Time (s)')
    %     ylabel('Surge (m)')
    %     title(sprintf('Solution %d - Surge', i))
    %     legend('Observed', 'Reference')
    %     grid on
    % end
    % 
    % sgtitle('SA-MOPSO-FVML: Sample Trajectories from Pareto Solutions')
    % 
    % % 4. Yaw trajectories
    % figure('Position', [100 100 1200 400]);
    % for i = 1:nSamples
    %     SavePos = ParetoPos_SAMOPSO{indices(i)};
    %     time = linspace(0, size(SavePos.Observer,2)*0.1, size(SavePos.Observer,2));
    % 
    %     subplot(1, nSamples, i)
    %     plot(time, SavePos.Observer(3,:), 'b-', 'LineWidth', 1.5)
    %     hold on
    %     plot(time, SavePos.Refrences(3,:), 'r--', 'LineWidth', 1.5)
    %     xlabel('Time (s)')
    %     ylabel('Yaw (rad)')
    %     title(sprintf('Solution %d - Yaw', i))
    %     legend('Observed', 'Reference')
    %     grid on
    % end
    % sgtitle('SA-MOPSO-FVML: Yaw Trajectories')
    %% =======================
    %% =======================
%  SURGE RESPONSE - ALL PARETO
% =======================
figure('Position', [100 100 900 400]);
hold on; grid on;

for i = 1:nPareto
    SavePos = ParetoPos_SAMOPSO{i};
    time = linspace(0, size(SavePos.Observer,2)*0.1, size(SavePos.Observer,2));
    plot(time, SavePos.Observer(1,:), 'Color', colors(i,:), 'LineWidth', 1);
end

plot(time, SavePos.Refrences(1,:), 'k--', 'LineWidth', 2);

xlabel('Time (s)');
ylabel('Surge (m)');
title('Surge Response for All Pareto Solutions');

%  SWAY RESPONSE - ALL PARETO
% =======================
figure('Position', [100 100 900 400]);
hold on; grid on;

for i = 1:nPareto
    SavePos = ParetoPos_SAMOPSO{i};
    time = linspace(0, size(SavePos.Observer,2)*0.1, size(SavePos.Observer,2));
    plot(time, SavePos.Observer(2,:), 'Color', colors(i,:), 'LineWidth', 1);
end

plot(time, SavePos.Refrences(2,:), 'k--', 'LineWidth', 2);

xlabel('Time (s)');
ylabel('Sway (m)');
title('Sway Response for All Pareto Solutions');
%% =======================
%  YAW RESPONSE - ALL PARETO
% =======================
figure('Position', [100 100 900 400]);
hold on; grid on;

for i = 1:nPareto
    SavePos = ParetoPos_SAMOPSO{i};
    time = linspace(0, size(SavePos.Observer,2)*0.1, size(SavePos.Observer,2));
    plot(time, SavePos.Observer(3,:), 'Color', colors(i,:), 'LineWidth', 1);
end

plot(time, SavePos.Refrences(3,:), 'k--', 'LineWidth', 2);

xlabel('Time (s)');
ylabel('Yaw (rad)');
title('Yaw Response for All Pareto Solutions');

end