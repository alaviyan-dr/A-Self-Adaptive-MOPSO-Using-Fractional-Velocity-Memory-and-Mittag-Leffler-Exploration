function out = DAMOPSO_reconstructed_2024(CostFunction, nVar, VarMin, VarMax, nPop, MaxIt, nArchive)
%DAMOPSO_RECONSTRUCTED_2024
% Paper-faithful independent MATLAB reconstruction of:
%   X. Zhang, Y. Liu, Q. Song, Y. Zhang, J. Yang, X. Wang,
%   "Density-guided and adaptive update strategy for multi-objective
%   particle swarm optimization", Journal of Computational Design and
%   Engineering, 11(5), 222-258, 2024.
%   DOI: 10.1093/jcde/qwae081
%
% IMPORTANT:
% This is NOT author-supplied code. It follows the published equations and
% pseudocode wherever they are explicit. The paper leaves some implementation
% details ambiguous. The main reconstruction choices are:
%   (1) gbest roulette weights: inverse adaptive-grid occupancy is used.
%   (2) the printed adaptive-grid boundary formulas (Eq. 9-10) are internally
%       ambiguous; a symmetric 5%% objective-range expansion is used.
%   (3) "mean normalization" of the Cauchy vector is not defined explicitly;
%       division by mean(abs(.)) is used to avoid a near-zero signed mean.
%   (4) the printed HRD expression (Eq. 22) is underspecified for a general
%       M-objective archive; a scale-normalized local hyper-region measure is
%       used while preserving the paper's rule: protect boundary points and
%       remove the smallest-density-region member one at a time.
% These choices MUST be disclosed if this implementation is reported.
%
% INPUTS
%   CostFunction : function handle, f = CostFunction(x), returns 1-by-M vector
%   nVar         : number of decision variables
%   VarMin       : scalar or 1-by-nVar lower bound
%   VarMax       : scalar or 1-by-nVar upper bound
%   nPop         : population size
%   MaxIt        : maximum iterations
%   nArchive     : external archive capacity
%
% OUTPUT
%   out.ArchiveX : nondominated decision vectors
%   out.ArchiveF : corresponding objective vectors
%   out.FE       : number of objective-function evaluations
%   out.Runtime  : wall-clock runtime in seconds
%   out.Trace    : parameter/archive history
%
% Recommended focused comparison for the SA-MOPSO-FVML revision:
%   nPop = 100; MaxIt = 250; nArchive = 100
%
% All objectives are assumed to be minimized.

tStart = tic;

VarMin = expandBound(VarMin, nVar);
VarMax = expandBound(VarMax, nVar);
VarRange = VarMax - VarMin;

% Published DAMOPSO flight-parameter settings
w  = 0.5;
c1 = 2.0;
c2 = 2.0;
wMin = 0.2; wMax = 0.8;
cMin = 1.5; cMax = 2.5;

% Initialize population and velocity
X = VarMin + rand(nPop,nVar).*VarRange;
V = zeros(nPop,nVar);

F = evaluatePopulation(CostFunction, X);
FE = nPop;

% Personal best initialization
PbestX = X;
PbestF = F;
prevRank = dominanceRank(F);

% Initial archive
nd = nondominatedMask(F);
ArchiveX = X(nd,:);
ArchiveF = F(nd,:);
[ArchiveX, ArchiveF] = uniqueObjectiveRows(ArchiveX, ArchiveF);
[ArchiveX, ArchiveF] = pruneArchiveHRD(ArchiveX, ArchiveF, nArchive);

% Conversion-efficiency state
CE_prev = 0;
CE_curr = 0;

% Trace
trace.w = zeros(MaxIt,1);
trace.c1 = zeros(MaxIt,1);
trace.c2 = zeros(MaxIt,1);
trace.CE = zeros(MaxIt,1);
trace.archiveSize = zeros(MaxIt,1);
trace.mutationApplied = false(MaxIt,1);

for t = 1:MaxIt

    % Eq. (23): adaptive adjustment coefficient
    AC = 2/(1 + exp(0.2*(t-1)));

    % Eqs. (25)-(27), using conversion-efficiency change from preceding
    % archive update. Clip to the explicit bounds given in the paper.
    if CE_curr > CE_prev
        w  = w  * (1 + AC);
        c1 = c1 * (1 + AC);
        c2 = c2 * AC;
    elseif CE_curr < CE_prev
        w  = w  * AC;
        c1 = c1 * AC;
        c2 = c2 * (1 + AC);
    end

    w  = min(wMax, max(wMin, w));
    c1 = min(cMax, max(cMin, c1));
    c2 = min(cMax, max(cMin, c2));

    % Select a gbest for every particle from the archive.
    % Reconstruction choice: roulette probability inversely proportional
    % to adaptive-grid occupancy (sparse cells receive larger probability).
    Gbest = zeros(nPop,nVar);
    for i = 1:nPop
        k = selectLeaderRoulette(ArchiveF);
        Gbest(i,:) = ArchiveX(k,:);
    end

    % Standard PSO flight process, Eq. (8)
    r1 = rand(nPop,nVar);
    r2 = rand(nPop,nVar);
    V = w.*V + c1.*r1.*(PbestX - X) + c2.*r2.*(Gbest - X);
    Xtrial = X + V;
    Xtrial = min(VarMax, max(VarMin, Xtrial));

    % Evaluate once here because the density-guided mutation needs current
    % dominance information. If mutation changes one particle, only that
    % particle is re-evaluated below.
    Ftrial = evaluatePopulation(CostFunction, Xtrial);
    FE = FE + nPop;

    % Density-guided Cauchy mutation, Algorithm design 1 / Eq. (15).
    % Paper stops mutation when archive reaches capacity.
    mutationApplied = false;
    if size(ArchiveX,1) < nArchive
        [Xtrial, Ftrial, didMutate, extraFE] = ...
            densityGuidedCauchyMutation(Xtrial, Ftrial, CostFunction, ...
                                        VarMin, VarMax, ArchiveX, nArchive);
        FE = FE + extraFE;
        mutationApplied = didMutate;
    end

    % Pbest update according to rank improvement (Eqs. 16-19 description)
    currRank = dominanceRank(Ftrial);
    for i = 1:nPop
        if currRank(i) < prevRank(i)
            PbestX(i,:) = Xtrial(i,:);
            PbestF(i,:) = Ftrial(i,:);
        elseif currRank(i) == prevRank(i)
            % Conservative tie handling: accept only if current solution
            % Pareto-dominates stored pbest; otherwise retain prior pbest.
            if dominates(Ftrial(i,:), PbestF(i,:))
                PbestX(i,:) = Xtrial(i,:);
                PbestF(i,:) = Ftrial(i,:);
            end
        end
    end

    X = Xtrial;
    F = Ftrial;
    prevRank = currRank;

    % Current nondominated set h(t)
    nd = nondominatedMask(F);
    Hx = X(nd,:);
    Hf = F(nd,:);
    [Hx, Hf] = uniqueObjectiveRows(Hx, Hf);

    % Conversion-efficiency bookkeeping based on the paper's Eq. (24):
    % CE(t+1) = [PS(t) - DS(t) + ES(t)] / PS(t)
    oldArchiveX = ArchiveX;
    oldArchiveF = ArchiveF;
    PS = size(oldArchiveF,1);

    DS = countOldArchiveDominatedByNew(oldArchiveF, Hf);
    ES = countNewNondominatedAgainstOld(Hf, oldArchiveF);

    CE_next = (PS - DS + ES) / max(1,PS);

    % Archive update + HRD pruning
    [ArchiveX, ArchiveF] = updateArchiveHRD(oldArchiveX, oldArchiveF, ...
                                            Hx, Hf, nArchive);

    CE_prev = CE_curr;
    CE_curr = CE_next;

    trace.w(t) = w;
    trace.c1(t) = c1;
    trace.c2(t) = c2;
    trace.CE(t) = CE_curr;
    trace.archiveSize(t) = size(ArchiveX,1);
    trace.mutationApplied(t) = mutationApplied;
end

out.ArchiveX = ArchiveX;
out.ArchiveF = ArchiveF;
out.FE = FE;
out.Runtime = toc(tStart);
out.Trace = trace;

end


%% ========================= HELPERS =========================

function b = expandBound(b,nVar)
if isscalar(b)
    b = repmat(b,1,nVar);
else
    b = reshape(b,1,[]);
end
if numel(b) ~= nVar
    error('Bound size must be scalar or equal to nVar.');
end
end

function F = evaluatePopulation(CostFunction, X)
N = size(X,1);
f1 = CostFunction(X(1,:));
f1 = reshape(f1,1,[]);
M = numel(f1);
F = zeros(N,M);
F(1,:) = f1;
for i = 2:N
    fi = CostFunction(X(i,:));
    F(i,:) = reshape(fi,1,[]);
end
end

function tf = dominates(a,b)
tf = all(a <= b) && any(a < b);
end

function nd = nondominatedMask(F)
N = size(F,1);
nd = true(N,1);
for i = 1:N
    if ~nd(i), continue; end
    for j = 1:N
        if i~=j && dominates(F(j,:),F(i,:))
            nd(i) = false;
            break;
        end
    end
end
end

function rank = dominanceRank(F)
% Published description ranks particles according to the number of particles
% dominating them, then maps unique dominance counts to ascending ranks.
N = size(F,1);
count = zeros(N,1);
for i = 1:N
    for j = 1:N
        if i~=j && dominates(F(j,:),F(i,:))
            count(i) = count(i)+1;
        end
    end
end
u = unique(count,'sorted');
rank = zeros(N,1);
for k = 1:numel(u)
    rank(count==u(k)) = k;
end
end

function [X,F] = uniqueObjectiveRows(X,F)
if isempty(F), return; end
[~,ia] = unique(F,'rows','stable');
X = X(ia,:);
F = F(ia,:);
end

function k = selectLeaderRoulette(ArchiveF)
A = size(ArchiveF,1);
if A <= 1
    k = 1;
    return;
end
cellID = adaptiveGridCellID(ArchiveF);
occ = accumarray(cellID,1);
weights = 1 ./ occ(cellID);
weights = weights / sum(weights);
r = rand;
cs = cumsum(weights);
k = find(r <= cs,1,'first');
if isempty(k), k=A; end
end

function cellID = adaptiveGridCellID(F)
% Adaptive objective-space grid for roulette/density estimation.
% The paper's printed Eq. (9)-(10) is internally ambiguous; here we use
% a symmetric 5% expansion of each observed objective range and about sqrt(N)
% divisions per objective, consistent with its Eq. (11) scaling.
N = size(F,1);
M = size(F,2);
nGrid = max(2,ceil(sqrt(N)));

fmin = min(F,[],1);
fmax = max(F,[],1);
span = fmax-fmin;
span(span<=eps) = 1;
LB = fmin - 0.05*span;
UB = fmax + 0.05*span;
dL = (UB-LB)/nGrid;
dL(dL<=eps)=1;

subs = zeros(N,M);
for m=1:M
    s = floor((F(:,m)-LB(m))./dL(m))+1;
    s = min(nGrid,max(1,s));
    subs(:,m)=s;
end

% Stable scalar cell IDs without depending on sub2ind dimensionality.
mult = [1, cumprod(repmat(nGrid,1,max(0,M-1)))];
cellID = 1 + sum((subs-1).*mult,2);
cellID = round(cellID);
end

function [X,F,didMutate,extraFE] = densityGuidedCauchyMutation( ...
          X,F,CostFunction,VarMin,VarMax,ArchiveX,nArchive)

didMutate = false;
extraFE = 0;

if size(ArchiveX,1) >= nArchive || size(X,1)<2
    return;
end

% Algorithm design 1: for a large decision-space range, use dominated
% particles as mutation candidates; otherwise use all particles.
T = max(VarMax) - min(VarMin);
nd = nondominatedMask(F);
domIdx = find(~nd);

if T > 2 && ~isempty(domIdx)
    candIdx = domIdx;
else
    candIdx = (1:size(X,1))';
end

if numel(candIdx)<2
    return;
end

Fc = F(candIdx,:);
cellID = adaptiveGridCellID(Fc);
occ = accumarray(cellID,1);
density = occ(cellID);

dmax = max(density);
dmin = min(density);
if dmax == dmin
    return;
end

% x_mut: high-density particle; x_best: sparse-region guide.
mutCandidates = candIdx(density==dmax);
bestCandidates = candIdx(density==dmin);
imut = mutCandidates(randi(numel(mutCandidates)));
ibest = bestCandidates(randi(numel(bestCandidates)));

% Eq. (14): standard Cauchy vector
U = rand(1,size(X,2));
U = min(1-eps,max(eps,U));
Cauchy = tan(pi*(U-0.5));

% Paper states "mean normalization" but does not provide its formula.
% Reconstruction choice: normalize by mean absolute magnitude.
Xprime = Cauchy/(mean(abs(Cauchy))+eps);

Rmax = max(VarMax) - min(VarMin);

% Eq. (15)
xnew = X(imut,:) + (Rmax/2).*Xprime.*(X(ibest,:) - X(imut,:));
xnew = min(VarMax,max(VarMin,xnew));

X(imut,:) = xnew;
fnew = CostFunction(xnew);
F(imut,:) = reshape(fnew,1,[]);
extraFE = 1;
didMutate = true;
end

function DS = countOldArchiveDominatedByNew(oldF,newF)
DS = 0;
for i=1:size(oldF,1)
    hit=false;
    for j=1:size(newF,1)
        if dominates(newF(j,:),oldF(i,:))
            hit=true; break;
        end
    end
    DS = DS + hit;
end
end

function ES = countNewNondominatedAgainstOld(newF,oldF)
ES = 0;
for i=1:size(newF,1)
    dominated=false;
    for j=1:size(oldF,1)
        if dominates(oldF(j,:),newF(i,:))
            dominated=true; break;
        end
    end
    if ~dominated
        ES=ES+1;
    end
end
end

function [Ax,Af] = updateArchiveHRD(oldX,oldF,newX,newF,L)
Ax = [oldX; newX];
Af = [oldF; newF];
[Ax,Af] = uniqueObjectiveRows(Ax,Af);

nd = nondominatedMask(Af);
Ax = Ax(nd,:);
Af = Af(nd,:);

[Ax,Af] = pruneArchiveHRD(Ax,Af,L);
end

function [Ax,Af] = pruneArchiveHRD(Ax,Af,L)
% Paper's archive principle: when over capacity, repeatedly remove a
% non-boundary solution with the smallest hyper-region density (HRD).
while size(Ax,1) > L
    hrd = hyperRegionMeasure(Af);
    [~,idx] = min(hrd);
    Ax(idx,:)=[];
    Af(idx,:)=[];
end
end

function hrd = hyperRegionMeasure(F)
% Reconstructed multiobjective HRD measure consistent with the paper's
% stated principle: small local objective-space hyper-region => remove.
% Boundary points are protected.
N=size(F,1);
M=size(F,2);
if N<=2
    hrd=inf(N,1);
    return;
end

% Normalize objective scales before local hyper-region products.
fmin=min(F,[],1);
fmax=max(F,[],1);
span=fmax-fmin;
span(span<=eps)=1;
Fn=(F-fmin)./span;

% Determine boundary points in every objective.
boundary=false(N,1);
for m=1:M
    [~,i1]=min(Fn(:,m)); [~,i2]=max(Fn(:,m));
    boundary([i1 i2])=true;
end

% Use nearest-neighbor hyper-rectangle volume as a stable generalization
% of Eq. (22)'s local product idea.
hrd=inf(N,1);
for i=1:N
    if boundary(i), continue; end
    dif=abs(Fn-Fn(i,:));
    dif(i,:)=inf;
    dist=sum(dif,2);
    [~,ord]=sort(dist,'ascend');
    j1=ord(1);
    j2=ord(min(2,numel(ord)));
    widths=abs(Fn(j1,:)-Fn(j2,:));
    hrd(i)=prod(widths+eps);
end
end
