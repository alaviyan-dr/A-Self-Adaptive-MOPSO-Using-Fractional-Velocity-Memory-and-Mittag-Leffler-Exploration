HOW TO RUN — Focused DAMOPSO comparison
========================================

This bundle is built directly from your final SA-MOPSO-FVML benchmark code.
There are NO adapter placeholders.

Put these 3 files in the SAME MATLAB folder:
1. Run_Focused_DAMOPSO_Reviewer1_Comment3_COMPLETE.m
2. DAMOPSO_reconstructed_2024.m
3. CEC_MOFunctions.m

Then:
- Set MATLAB Current Folder to that folder.
- Open Run_Focused_DAMOPSO_Reviewer1_Comment3_COMPLETE.m.
- Click Run.

The script runs:
F2  ZDT2
F5  DTLZ2
F6  DTLZ3
F7  corrected standard DTLZ4
F10 Rastrigin-MO

Algorithms:
SA-MOPSO-FVML
Levy-MOPSO
DAMOPSO-2024

Settings:
30 matched-seed runs
Population = 100
Iterations = 250
Archive = 100

Output:
results/Focused_HeavyTail_DAMOPSO_Comparison.xlsx
results/Focused_HeavyTail_DAMOPSO_Comparison.mat

Excel sheets:
Summary
Paired_Wilcoxon
Friedman

Statistical design:
Paired Wilcoxon signed-rank because the same seed is reset before each of
the three algorithms within the same problem/run.

IMPORTANT:
This is a separate focused experiment. Its absolute HV values should NOT be
compared numerically with the main 11-algorithm benchmark because the common
HV reference box is rebuilt from only these three algorithms.

DAMOPSO note:
DAMOPSO_reconstructed_2024.m is an independent reconstruction from the
published equations/pseudocode, not author-supplied source code.
