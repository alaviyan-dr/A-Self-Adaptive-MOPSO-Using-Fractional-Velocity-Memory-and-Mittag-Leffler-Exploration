%% Run_Focused_HeavyTail_Comparison.m
% Focused published-heavy-tail comparison for Reviewer 1 - Comment 3
%
% Algorithms:
%   1) SA-MOPSO-FVML      (your existing implementation through adapter)
%   2) Levy-MOPSO         (your existing final-benchmark implementation through adapter)
%   3) DAMOPSO (2024)     (independent reconstruction from published paper)
%
% Problems:
%   F2  = ZDT2
%   F5  = DTLZ2
%   F6  = DTLZ3
%   F7  = DTLZ4 (corrected standard implementation)
%   F10 = custom Rastrigin-MO
%
% Design:
%   30 matched-seed runs
%   N = 100, T = 250, archive = 100
%   HV reference point pooled across ALL 3 algorithms x 30 runs
%   r_m = fmax_m + 0.10*(fmax_m-fmin_m)
%   2-D HV: exact
%   3-D HV: Monte Carlo, 200000 samples, fixed LOCAL seed = 12345
%   IGD: analytical reference fronts for F2/F5/F6/F7 only
%   SP: standard nearest-neighbour spacing
%   Paired Wilcoxon signed-rank: SA vs Levy, SA vs DAMOPSO
%   Friedman test: all 3 matched configurations
%
% IMPORTANT:
%   This focused experiment is separate from the main 11-algorithm benchmark.
%   Do NOT compare its absolute HV values with the main benchmark, because
%   the pooled HV reference box is reconstructed from these 3 algorithms only.
%
% BEFORE RUNNING:
%   Edit ONLY these two adapter files to call your already-validated code:
%       SA_MOPSO_FVML_adapter.m
%       Levy_MOPSO_adapter.m
%
% Required output contract of both adapters:
%       out.ArchiveF : final nondominated objective vectors
%       out.ArchiveX : final decision vectors (optional but recommended)
%       out.Runtime  : wall-clock seconds
%       out.FE       : function-evaluation count
%
% Outputs:
%   Focused_HeavyTail_Comparison_Results.mat
%   Focused_HeavyTail_Comparison.xlsx
%
% -------------------------------------------------------------------------

clear;
clc;

%% ---------------- Configuration ----------------
test_functions = [2 5 6 7 10];
algorithms = {'SA-MOPSO-FVML','Levy-MOPSO','DAMOPSO-2024'};

nRuns     = 30;
nPop      = 100;
MaxIt     = 250;
nArchive  = 100;

baseSeed  = 20260906;     % deterministic matched-run seed generator
nHVmc     = 200000;
hvLocalSeed = 12345;
nRefIGD   = 1000;

outMat  = 'Focused_HeavyTail_Comparison_Results.mat';
outXlsx = 'Focused_HeavyTail_Comparison.xlsx';

nF = numel(test_functions);
nA = numel(algorithms);

% Result containers
Raw = cell(nF,nA,nRuns);
SeedTableData = zeros(nF*nRuns,3); % func, run, seed
seedRow = 0;

fprintf('\n============================================================\n');
fprintf(' Focused heavy-tail comparison: SA vs Levy vs DAMOPSO\n');
fprintf('============================================================\n');
fprintf('Functions : %s\n', mat2str(test_functions));
fprintf('Runs      : %d matched runs\n', nRuns);
fprintf('N/T/A     : %d / %d / %d\n\n', nPop, MaxIt, nArchive);

%% ---------------- Optimization runs ----------------
for fi = 1:nF

    func_no = test_functions(fi);
    prob = getProblemDefinition(func_no);

    fprintf('\n------------------------------------------------------------\n');
    fprintf('F%d: %s | D=%d | M=%d\n',func_no,prob.name,prob.nVar,prob.nObj);
    fprintf('------------------------------------------------------------\n');

    CostFunction = @(x) CEC_MOFunctions(x,func_no);

    for run = 1:nRuns

        % Same seed is reset before each algorithm in the matched run.
        seed = baseSeed + 1000*func_no + run;

        seedRow = seedRow + 1;
        SeedTableData(seedRow,:) = [func_no,run,seed];

        fprintf('F%d | run %02d/%02d | seed %d\n',func_no,run,nRuns,seed);

        % ---------- SA-MOPSO-FVML ----------
        rng(seed,'twister');
        global FE_COUNT
        FE_COUNT = 0;

        outSA = SA_MOPSO_FVML_adapter(func_no,prob,nPop,MaxIt,nArchive);
        outSA = standardizeRunOutput(outSA, FE_COUNT, prob);
        Raw{fi,1,run} = outSA;

        % ---------- Levy-MOPSO ----------
        rng(seed,'twister');
        FE_COUNT = 0;

        outLevy = Levy_MOPSO_adapter(func_no,prob,nPop,MaxIt,nArchive);
        outLevy = standardizeRunOutput(outLevy, FE_COUNT, prob);
        Raw{fi,2,run} = outLevy;

        % ---------- DAMOPSO 2024 reconstruction ----------
        rng(seed,'twister');
        FE_COUNT = 0;

        outDAM = DAMOPSO_reconstructed_2024( ...
            CostFunction,prob.nVar,prob.VarMin,prob.VarMax, ...
            nPop,MaxIt,nArchive);

        % Global FE_COUNT is authoritative because it is incremented inside
        % CEC_MOFunctions for every objective evaluation.
        outDAM = standardizeRunOutput(outDAM, FE_COUNT, prob);
        Raw{fi,3,run} = outDAM;

        fprintf('   FE: SA=%d | Levy=%d | DAM=%d\n', ...
            Raw{fi,1,run}.FE,Raw{fi,2,run}.FE,Raw{fi,3,run}.FE);
    end
end

%% ---------------- Metrics with a common pooled HV reference ----------------
Metrics.HV      = nan(nF,nA,nRuns);
Metrics.IGD     = nan(nF,nA,nRuns);
Metrics.SP      = nan(nF,nA,nRuns);
Metrics.Runtime = nan(nF,nA,nRuns);
Metrics.FE      = nan(nF,nA,nRuns);
Metrics.Asize   = nan(nF,nA,nRuns);

HVReference = nan(nF,3);
HVLower     = nan(nF,3);

for fi = 1:nF

    func_no = test_functions(fi);
    prob = getProblemDefinition(func_no);

    % Pool ALL final archive objective vectors across all 3 algorithms/runs.
    pooled = [];
    for ai = 1:nA
        for run = 1:nRuns
            pooled = [pooled; Raw{fi,ai,run}.ArchiveF]; %#ok<AGROW>
        end
    end
    pooled = pooled(all(isfinite(pooled),2),:);

    fmin = min(pooled,[],1);
    fmax = max(pooled,[],1);
    span = fmax-fmin;
    span(span<=eps)=max(1,abs(fmax(span<=eps)));

    ref = fmax + 0.10*span;

    HVReference(fi,1:prob.nObj) = ref;
    HVLower(fi,1:prob.nObj)     = fmin;

    % Fixed local MC realization for ALL sets on this problem.
    if prob.nObj == 3
        rs = RandStream('mt19937ar','Seed',hvLocalSeed);
        U = rand(rs,nHVmc,3);
        mcSamples = fmin + U.*(ref-fmin);
        boxVolume = prod(ref-fmin);
    else
        mcSamples = [];
        boxVolume = [];
    end

    % Analytical reference front where available.
    Pref = analyticalReferenceFront(func_no,nRefIGD);

    fprintf('\nComputing metrics for F%d (%s)...\n',func_no,prob.name);

    for ai = 1:nA
        for run = 1:nRuns

            F = cleanObjectiveSet(Raw{fi,ai,run}.ArchiveF);

            if prob.nObj == 2
                Metrics.HV(fi,ai,run) = hv2DExact(F,ref);
            elseif prob.nObj == 3
                Metrics.HV(fi,ai,run) = hv3DMonteCarloFixed(F,mcSamples,boxVolume);
            else
                error('Only 2-D and 3-D HV are implemented in this focused script.');
            end

            if ~isempty(Pref)
                Metrics.IGD(fi,ai,run) = computeIGD(F,Pref);
            end

            Metrics.SP(fi,ai,run)      = computeSpacing(F);
            Metrics.Runtime(fi,ai,run) = Raw{fi,ai,run}.Runtime;
            Metrics.FE(fi,ai,run)      = Raw{fi,ai,run}.FE;
            Metrics.Asize(fi,ai,run)   = size(F,1);
        end
    end
end

%% ---------------- Run-level table ----------------
Function = [];
FunctionName = {};
Algorithm = {};
Run = [];
Seed = [];
HV = [];
IGD = [];
SP = [];
Runtime_s = [];
FE = [];
ArchiveSize = [];

for fi=1:nF
    func_no=test_functions(fi);
    prob=getProblemDefinition(func_no);
    for ai=1:nA
        for r=1:nRuns
            Function(end+1,1)=func_no; %#ok<SAGROW>
            FunctionName{end+1,1}=prob.name; %#ok<SAGROW>
            Algorithm{end+1,1}=algorithms{ai}; %#ok<SAGROW>
            Run(end+1,1)=r; %#ok<SAGROW>
            Seed(end+1,1)=baseSeed+1000*func_no+r; %#ok<SAGROW>
            HV(end+1,1)=Metrics.HV(fi,ai,r); %#ok<SAGROW>
            IGD(end+1,1)=Metrics.IGD(fi,ai,r); %#ok<SAGROW>
            SP(end+1,1)=Metrics.SP(fi,ai,r); %#ok<SAGROW>
            Runtime_s(end+1,1)=Metrics.Runtime(fi,ai,r); %#ok<SAGROW>
            FE(end+1,1)=Metrics.FE(fi,ai,r); %#ok<SAGROW>
            ArchiveSize(end+1,1)=Metrics.Asize(fi,ai,r); %#ok<SAGROW>
        end
    end
end

RunMetrics = table(Function,FunctionName,Algorithm,Run,Seed,HV,IGD,SP,Runtime_s,FE,ArchiveSize);

%% ---------------- Summary table ----------------
S_Function = [];
S_Name = {};
S_Algorithm = {};
Median_HV = [];
Median_IGD = [];
Median_SP = [];
Mean_Runtime_s = [];
SD_Runtime_s = [];
Mean_FE = [];
Mean_ArchiveSize = [];

for fi=1:nF
    func_no=test_functions(fi);
    prob=getProblemDefinition(func_no);
    for ai=1:nA
        S_Function(end+1,1)=func_no; %#ok<SAGROW>
        S_Name{end+1,1}=prob.name; %#ok<SAGROW>
        S_Algorithm{end+1,1}=algorithms{ai}; %#ok<SAGROW>
        Median_HV(end+1,1)=median(squeeze(Metrics.HV(fi,ai,:)),'omitnan'); %#ok<SAGROW>
        Median_IGD(end+1,1)=median(squeeze(Metrics.IGD(fi,ai,:)),'omitnan'); %#ok<SAGROW>
        Median_SP(end+1,1)=median(squeeze(Metrics.SP(fi,ai,:)),'omitnan'); %#ok<SAGROW>
        Mean_Runtime_s(end+1,1)=mean(squeeze(Metrics.Runtime(fi,ai,:)),'omitnan'); %#ok<SAGROW>
        SD_Runtime_s(end+1,1)=std(squeeze(Metrics.Runtime(fi,ai,:)),'omitnan'); %#ok<SAGROW>
        Mean_FE(end+1,1)=mean(squeeze(Metrics.FE(fi,ai,:)),'omitnan'); %#ok<SAGROW>
        Mean_ArchiveSize(end+1,1)=mean(squeeze(Metrics.Asize(fi,ai,:)),'omitnan'); %#ok<SAGROW>
    end
end

Summary = table(S_Function,S_Name,S_Algorithm,Median_HV,Median_IGD,Median_SP, ...
                Mean_Runtime_s,SD_Runtime_s,Mean_FE,Mean_ArchiveSize);

%% ---------------- Paired Wilcoxon signed-rank ----------------
% SA is column 1. Compare against Levy (2) and DAMOPSO (3).
W_Function = [];
W_Name = {};
W_Metric = {};
W_Comparison = {};
W_p = [];
W_Symbol = {};
W_SA_Median = [];
W_Competitor_Median = [];

for fi=1:nF
    func_no=test_functions(fi);
    prob=getProblemDefinition(func_no);

    metricNames = {'HV','IGD','SP'};
    metricArrays = {Metrics.HV,Metrics.IGD,Metrics.SP};
    higherBetter = [true,false,false];

    for mi=1:3
        A = metricArrays{mi};
        x = squeeze(A(fi,1,:));

        if all(isnan(x))
            continue;
        end

        for ai=2:3
            y = squeeze(A(fi,ai,:));
            ok = isfinite(x) & isfinite(y);

            if nnz(ok)<2
                p = NaN;
            elseif all(abs(x(ok)-y(ok)) <= eps(max(1,max(abs([x(ok);y(ok)])))))
                p = 1;
            else
                p = signrank(x(ok),y(ok),'tail','both');
            end

            medx=median(x(ok),'omitnan');
            medy=median(y(ok),'omitnan');
            sym = significanceSymbol(p,medx,medy,higherBetter(mi));

            W_Function(end+1,1)=func_no; %#ok<SAGROW>
            W_Name{end+1,1}=prob.name; %#ok<SAGROW>
            W_Metric{end+1,1}=metricNames{mi}; %#ok<SAGROW>
            W_Comparison{end+1,1}=sprintf('SA vs %s',algorithms{ai}); %#ok<SAGROW>
            W_p(end+1,1)=p; %#ok<SAGROW>
            W_Symbol{end+1,1}=sym; %#ok<SAGROW>
            W_SA_Median(end+1,1)=medx; %#ok<SAGROW>
            W_Competitor_Median(end+1,1)=medy; %#ok<SAGROW>
        end
    end
end

Wilcoxon = table(W_Function,W_Name,W_Metric,W_Comparison,W_p,W_Symbol, ...
                 W_SA_Median,W_Competitor_Median);

%% ---------------- Friedman across all three matched algorithms ----------------
F_Function = [];
F_Name = {};
F_Metric = {};
F_p = [];

for fi=1:nF
    func_no=test_functions(fi);
    prob=getProblemDefinition(func_no);

    metricNames = {'HV','IGD','SP'};
    metricArrays = {Metrics.HV,Metrics.IGD,Metrics.SP};

    for mi=1:3
        A=metricArrays{mi};
        Xmat=squeeze(A(fi,:,:))'; % runs x algorithms

        ok=all(isfinite(Xmat),2);
        Xmat=Xmat(ok,:);

        if isempty(Xmat)
            p=NaN;
        elseif all(max(Xmat,[],2)-min(Xmat,[],2) <= eps(max(1,max(abs(Xmat(:))))))
            p=1;
        else
            p=friedman(Xmat,1,'off');
        end

        F_Function(end+1,1)=func_no; %#ok<SAGROW>
        F_Name{end+1,1}=prob.name; %#ok<SAGROW>
        F_Metric{end+1,1}=metricNames{mi}; %#ok<SAGROW>
        F_p(end+1,1)=p; %#ok<SAGROW>
    end
end

FriedmanResults = table(F_Function,F_Name,F_Metric,F_p);

%% ---------------- HV reference-box table ----------------
R_Function = test_functions(:);
R_Name = cell(nF,1);
R_r1 = nan(nF,1); R_r2=nan(nF,1); R_r3=nan(nF,1);
R_l1 = nan(nF,1); R_l2=nan(nF,1); R_l3=nan(nF,1);

for fi=1:nF
    prob=getProblemDefinition(test_functions(fi));
    R_Name{fi}=prob.name;
    R_r1(fi)=HVReference(fi,1); R_r2(fi)=HVReference(fi,2);
    R_l1(fi)=HVLower(fi,1);     R_l2(fi)=HVLower(fi,2);
    if prob.nObj==3
        R_r3(fi)=HVReference(fi,3);
        R_l3(fi)=HVLower(fi,3);
    end
end

HVReferenceTable = table(R_Function,R_Name,R_l1,R_l2,R_l3,R_r1,R_r2,R_r3);

%% ---------------- Seed table ----------------
SeedTable = array2table(SeedTableData,'VariableNames',{'Function','Run','Seed'});

%% ---------------- Notes sheet ----------------
Notes = table( ...
    { ...
    'Focused experiment is separate from the main 11-algorithm benchmark.'; ...
    'Absolute HV values must not be compared with the main benchmark because the pooled reference box is rebuilt from these three algorithms.'; ...
    'Matched design: the same seed is reset before SA-MOPSO-FVML, Levy-MOPSO, and DAMOPSO within each corresponding run.'; ...
    'HV reference: r_m=fmax_m+0.10*(fmax_m-fmin_m), pooled over all three algorithms and 30 runs within each problem.'; ...
    '2-D HV is exact; 3-D HV uses 200000 Monte Carlo samples from one fixed local MT19937 stream with seed 12345 for all compared sets on a problem.'; ...
    'IGD is reported only for F2, F5, F6, and F7. F10 has no analytical reference front in the current study.'; ...
    'Wilcoxon tests are paired signed-rank tests because corresponding runs use matched seeds.'; ...
    'DAMOPSO code is an independent reconstruction from the 2024 publication, not author-supplied source code; reconstruction choices must be disclosed.' ...
    }, ...
    'VariableNames',{'Note'});

%% ---------------- Save results ----------------
save(outMat,'Raw','Metrics','Summary','RunMetrics','Wilcoxon', ...
    'FriedmanResults','HVReferenceTable','SeedTable','Notes', ...
    'test_functions','algorithms','nRuns','nPop','MaxIt','nArchive', ...
    'baseSeed','nHVmc','hvLocalSeed','nRefIGD','-v7.3');

if isfile(outXlsx)
    delete(outXlsx);
end

writetable(Summary,outXlsx,'Sheet','Summary');
writetable(Wilcoxon,outXlsx,'Sheet','Wilcoxon');
writetable(FriedmanResults,outXlsx,'Sheet','Friedman');
writetable(HVReferenceTable,outXlsx,'Sheet','HV_Reference');
writetable(RunMetrics,outXlsx,'Sheet','Run_Metrics');
writetable(SeedTable,outXlsx,'Sheet','Seeds');
writetable(Notes,outXlsx,'Sheet','Notes');

%% ---------------- Console summary ----------------
fprintf('\n\n============================================================\n');
fprintf(' FINAL FOCUSED-COMPARISON SUMMARY\n');
fprintf('============================================================\n');

for fi=1:nF
    func_no=test_functions(fi);
    prob=getProblemDefinition(func_no);
    fprintf('\nF%d - %s\n',func_no,prob.name);

    rows = Summary.S_Function==func_no;
    disp(Summary(rows,{'S_Algorithm','Median_HV','Median_IGD','Median_SP', ...
                       'Mean_Runtime_s','Mean_FE'}));

    fprintf('Paired Wilcoxon (SA perspective):\n');
    wrows = Wilcoxon.W_Function==func_no;
    disp(Wilcoxon(wrows,{'W_Metric','W_Comparison','W_p','W_Symbol'}));

    fprintf('Friedman p-values:\n');
    frows=FriedmanResults.F_Function==func_no;
    disp(FriedmanResults(frows,{'F_Metric','F_p'}));
end

fprintf('\nSaved:\n  %s\n  %s\n',outMat,outXlsx);
fprintf('\nLegend: + = SA significantly better; - = SA significantly worse; ~= no significant difference.\n');


%% ========================================================================
%% Local functions
%% ========================================================================

function prob = getProblemDefinition(func_no)
switch func_no
    case 2
        prob.name='ZDT2';
        prob.nVar=30;
        prob.nObj=2;
        prob.VarMin=zeros(1,30);
        prob.VarMax=ones(1,30);

    case 5
        prob.name='DTLZ2';
        prob.nVar=12;
        prob.nObj=3;
        prob.VarMin=zeros(1,12);
        prob.VarMax=ones(1,12);

    case 6
        prob.name='DTLZ3';
        prob.nVar=12;
        prob.nObj=3;
        prob.VarMin=zeros(1,12);
        prob.VarMax=ones(1,12);

    case 7
        prob.name='DTLZ4';
        prob.nVar=12;
        prob.nObj=3;
        prob.VarMin=zeros(1,12);
        prob.VarMax=ones(1,12);

    case 10
        prob.name='Rastrigin-MO';
        prob.nVar=30;
        prob.nObj=2;
        prob.VarMin=-5.12*ones(1,30);
        prob.VarMax= 5.12*ones(1,30);

    otherwise
        error('This focused experiment is configured only for F2/F5/F6/F7/F10.');
end
end


function out = standardizeRunOutput(out, globalFE, prob)

required={'ArchiveF','Runtime'};
for k=1:numel(required)
    if ~isfield(out,required{k})
        error('Runner output is missing required field "%s".',required{k});
    end
end

out.ArchiveF=cleanObjectiveSet(out.ArchiveF);

if size(out.ArchiveF,2)~=prob.nObj
    error('ArchiveF has %d objectives; F requires %d.', ...
        size(out.ArchiveF,2),prob.nObj);
end

if ~isfield(out,'ArchiveX')
    out.ArchiveX=[];
end

% Prefer global FE_COUNT because it comes directly from CEC_MOFunctions.
if ~isempty(globalFE) && globalFE>0
    out.FE=globalFE;
elseif ~isfield(out,'FE')
    out.FE=NaN;
end
end


function F = cleanObjectiveSet(F)

if isempty(F)
    error('Final archive is empty.');
end

F=double(F);
F=F(all(isfinite(F),2),:);
if isempty(F)
    error('Final archive contains no finite objective vectors.');
end

F=unique(F,'rows','stable');

% Remove dominated points.
N=size(F,1);
keep=true(N,1);
for i=1:N
    if ~keep(i), continue; end
    for j=1:N
        if i~=j && all(F(j,:)<=F(i,:)) && any(F(j,:)<F(i,:))
            keep(i)=false;
            break;
        end
    end
end
F=F(keep,:);
end


function hv = hv2DExact(F,ref)

F=cleanObjectiveSet(F);

% Ignore points outside the reference box.
ok=all(F<=ref,2);
F=F(ok,:);

if isempty(F)
    hv=0;
    return;
end

% Sort increasing f1. For a nondominated minimization set, f2 should
% decrease as f1 increases.
F=sortrows(F,1);

hv=0;
prevY=ref(2);

for i=1:size(F,1)
    x=F(i,1);
    y=F(i,2);

    if y < prevY
        hv = hv + max(0,ref(1)-x)*max(0,prevY-y);
        prevY = y;
    end
end
end


function hv = hv3DMonteCarloFixed(F,samples,boxVolume)

F=cleanObjectiveSet(F);

if isempty(F) || isempty(samples)
    hv=0;
    return;
end

% Only points within the common reference box can contribute.
ref=max(samples,[],1); %#ok<NASGU>

nS=size(samples,1);
dominated=false(nS,1);

% Vectorized over MC samples, loop only over archive members.
for j=1:size(F,1)
    p=F(j,:);
    dominated = dominated | ...
        (samples(:,1)>=p(1) & samples(:,2)>=p(2) & samples(:,3)>=p(3));

    if all(dominated)
        break;
    end
end

hv=boxVolume*mean(dominated);
end


function P = analyticalReferenceFront(func_no,n)

switch func_no

    case 2  % ZDT2
        f1=linspace(0,1,n)';
        f2=1-f1.^2;
        P=[f1 f2];

    case {5,6,7} % DTLZ2/3/4 have the same unit-spherical global PF
        % Uniform random surface-area samples on the positive octant of S^2,
        % generated from a fixed LOCAL stream independent of optimization RNG.
        rs=RandStream('mt19937ar','Seed',24680);
        Z=randn(rs,n,3);
        Z=abs(Z);
        Z=Z./sqrt(sum(Z.^2,2));
        P=Z;

    case 10
        % No analytical PF is used for F10 in the manuscript.
        P=[];

    otherwise
        P=[];
end
end


function igd = computeIGD(F,P)

F=cleanObjectiveSet(F);

nP=size(P,1);
dmin=inf(nP,1);

for j=1:size(F,1)
    d2=sum((P-F(j,:)).^2,2);
    dmin=min(dmin,sqrt(d2));
end

igd=mean(dmin);
end


function sp = computeSpacing(F)

F=cleanObjectiveSet(F);
N=size(F,1);

if N<=1
    sp=0;
    return;
end

d=inf(N,1);

for i=1:N
    for j=1:N
        if i==j, continue; end
        dij=sqrt(sum((F(i,:)-F(j,:)).^2));
        if dij<d(i)
            d(i)=dij;
        end
    end
end

if N==2
    sp=0;
else
    sp=sqrt(sum((d-mean(d)).^2)/(N-1));
end
end


function sym = significanceSymbol(p,medSA,medC,higherBetter)

if ~isfinite(p) || p>=0.05
    sym='~=';
    return;
end

if higherBetter
    if medSA>medC
        sym='+';
    elseif medSA<medC
        sym='-';
    else
        sym='~=';
    end
else
    if medSA<medC
        sym='+';
    elseif medSA>medC
        sym='-';
    else
        sym='~=';
    end
end
end
