function out = SA_MOPSO_FVML_adapter(func_no,prob,nPop,MaxIt,nArchive)
%SA_MOPSO_FVML_ADAPTER
% Connects the focused reviewer experiment to YOUR EXISTING, VALIDATED
% SA-MOPSO-FVML implementation.
%
% EDIT ONLY THE USER-CALL BLOCK BELOW.
%
% Required output:
%   out.ArchiveF : final nondominated objective vectors
%   out.ArchiveX : final decision vectors (optional)
%   out.Runtime  : wall-clock runtime in seconds
%   out.FE       : optional; the main script will prefer global FE_COUNT
%
% Inputs:
%   func_no  : 2,5,6,7,10
%   prob     : struct with .nVar .nObj .VarMin .VarMax .name
%   nPop     : 100
%   MaxIt    : 250
%   nArchive : 100
%
% CEC objective handle:
CostFunction = @(x) CEC_MOFunctions(x,func_no);

global FE_COUNT
if isempty(FE_COUNT), FE_COUNT=0; end

tStart=tic;

%% ======================= USER-CALL BLOCK ================================
% Replace ONLY this block with the single call to your final
% SA-MOPSO-FVML implementation used for the paper.
%
% EXAMPLE ONLY (DO NOT USE UNLESS IT MATCHES YOUR FUNCTION):
%
% raw = SA_MOPSO_FVML(CostFunction,prob.nVar,prob.VarMin,prob.VarMax, ...
%                     nPop,MaxIt,nArchive);
%
% out.ArchiveF = raw.ArchiveF;
% out.ArchiveX = raw.ArchiveX;
%
% If your function returns matrices directly, for example:
% [ArchiveX,ArchiveF] = run_SA_MOPSO_FVML(func_no,nPop,MaxIt,nArchive);
% out.ArchiveX = ArchiveX;
% out.ArchiveF = ArchiveF;
%
error(['SA_MOPSO_FVML_adapter is not connected yet. ' ...
       'Paste the ONE existing SA-MOPSO-FVML function call into the ' ...
       'USER-CALL BLOCK of this file.']);
%% =======================================================================

out.Runtime=toc(tStart);
out.FE=FE_COUNT;
end
