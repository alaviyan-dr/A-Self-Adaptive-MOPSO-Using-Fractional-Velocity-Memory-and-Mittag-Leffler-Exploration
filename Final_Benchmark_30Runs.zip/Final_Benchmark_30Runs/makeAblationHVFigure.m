function makeAblationHVFigure(all_results, test_functions)
%MAKEABLATIONHVFIGURE
% Creates the ablation HV figure for F2, F5, F8, and F9 using existing
% all_results from the current run.
%
% Output files:
%   figures/ablation_hv_f2_f5_f8_f9.pdf
%   figures/ablation_hv_f2_f5_f8_f9.png
%   figures/ablation_hv_f2_f5_f8_f9.fig

    selectedFuncs = [2, 5, 8, 9];

    selectedAlgos = { ...
        'SA-MOPSO-FVML', ...
        'Classical-MOPSO', ...
        'MOPSO-CD', ...
        'MOPSO-FM', ...
        'MOPSO-ML', ...
        'MOPSO-Grid'};

    algoLabels = { ...
        'SA-MOPSO-FVML', ...
        'Classical', ...
        'MOPSO-CD', ...
        'MOPSO-FM', ...
        'MOPSO-ML', ...
        'MOPSO-Grid'};

    algoFields = cellfun(@matlab.lang.makeValidName, selectedAlgos, ...
        'UniformOutput', false);

   % Create output folder in the current MATLAB working directory
outDir = fullfile(pwd, 'figures');

if exist(outDir, 'file') && ~exist(outDir, 'dir')
    error('A file named "figures" exists in the current folder. Rename or remove it first.');
end

if ~exist(outDir, 'dir')
    [status, msg] = mkdir(outDir);
    if ~status
        error('Could not create output directory: %s\nReason: %s', outDir, msg);
    end
end

    fig = figure('Color', 'w', 'Position', [100, 100, 1350, 760]);

    tiledlayout(2, 2, ...
        'TileSpacing', 'compact', ...
        'Padding', 'compact');

    for f = 1:numel(selectedFuncs)

        func_no = selectedFuncs(f);

        idx = [];

        if isfield(all_results, 'func_no')
            idx = find([all_results.func_no] == func_no, 1, 'first');
        end

        if isempty(idx)
            idx = find(test_functions == func_no, 1, 'first');
        end

        if isempty(idx)
            warning('Function #%d was not found. Skipping this panel.', func_no);
            continue;
        end

        hvVals = nan(1, numel(algoFields));

        for a = 1:numel(algoFields)

            field = algoFields{a};

            if isfield(all_results(idx), field) && ...
               isfield(all_results(idx).(field), 'HV')

                hvData = all_results(idx).(field).HV;
                hvVals(a) = median(hvData, 'omitnan');
            else
                warning('Missing HV data for %s on F%d.', selectedAlgos{a}, func_no);
            end
        end

        nexttile;

        bar(hvVals, 'LineWidth', 0.8);

        set(gca, ...
            'XTick', 1:numel(algoLabels), ...
            'XTickLabel', algoLabels, ...
            'TickLabelInterpreter', 'none', ...
            'FontSize', 10);

        xtickangle(35);
        ylabel('Median HV');
        title(sprintf('F%d', func_no), 'FontWeight', 'bold');
        grid on;
        box on;

        validVals = hvVals(isfinite(hvVals));

        if ~isempty(validVals)
            yMax = max(validVals);
            yMin = min(validVals);

            if yMax > 0
                ylim([0, 1.18 * yMax]);
                text(find(hvVals == yMax, 1, 'first'), ...
                     1.06 * yMax, ...
                     'Best', ...
                     'HorizontalAlignment', 'center', ...
                     'FontWeight', 'bold', ...
                     'FontSize', 9);
            else
                ylim([0, 1]);
            end

            % Add a small note if the function has a large dynamic range.
            if yMax > 1000 || yMin > 1000
                ax = gca;
                ax.YAxis.Exponent = 0;
                ytickformat('%.2g');
            end
        end
    end

    sgtitle('Ablation-based median HV comparison on F2, F5, F8, and F9', ...
        'FontWeight', 'bold', ...
        'FontSize', 14);

    pdfPath = fullfile(outDir, 'ablation_hv_f2_f5_f8_f9.pdf');
    pngPath = fullfile(outDir, 'ablation_hv_f2_f5_f8_f9.png');
    figPath = fullfile(outDir, 'ablation_hv_f2_f5_f8_f9.fig');

    try
    exportgraphics(fig, pdfPath, 'ContentType', 'vector');
catch
    print(fig, pdfPath, '-dpdf', '-bestfit');
end

try
    exportgraphics(fig, pngPath, 'Resolution', 600);
catch
    print(fig, pngPath, '-dpng', '-r600');
end

    savefig(fig, figPath);

    fprintf('\nAblation HV figure saved:\n');
    fprintf('  %s\n', pdfPath);
    fprintf('  %s\n', pngPath);
    fprintf('  %s\n\n', figPath);
end