%% plot_component_ablation_FINAL.m
% Component-level ablation summary from the frozen final 30-run benchmark
%
% Algorithms:
%   SA-MOPSO-FVML
%   MOPSO-FM
%   MOPSO-ML
%   MOPSO-Grid
%
% Problems:
%   F2  = ZDT2
%   F5  = DTLZ2
%   F7  = corrected DTLZ4
%   F8
%   F9
%
% Output:
%   ablation_hv_f2_f5_f7_f8_f9_FINAL.pdf
%   ablation_hv_f2_f5_f7_f8_f9_FINAL.png

clear;
clc;
close all;

%% ------------------------------------------------------------
% Labels
% -------------------------------------------------------------
algorithms = { ...
    'SA-MOPSO-FVML', ...
    'MOPSO-FM', ...
    'MOPSO-ML', ...
    'MOPSO-Grid'};

problems = { ...
    'F2 (ZDT2)', ...
    'F5 (DTLZ2)', ...
    'F7 (DTLZ4)', ...
    'F8', ...
    'F9'};

%% ------------------------------------------------------------
% Frozen median HV values from final 30-run benchmark
%
% Rows    = F2, F5, F7, F8, F9
% Columns = SA, FM, ML, Grid
% -------------------------------------------------------------
HV = [ ...
    4.428350,         3.986117,         4.428099,         4.427699; ...
    13.701434,        13.663288,        13.692229,        13.616725; ...
    9.431936,         9.386644,         9.403339,         9.344666; ...
    3318.840267,      3218.489015,      3278.163298,      3178.055687; ...
    163725120.721727, 160528453.671641, 161941538.906958, 159921946.964252 ...
    ];

%% ------------------------------------------------------------
% Verification
% -------------------------------------------------------------
assert(size(HV,1) == numel(problems), ...
    'Problem count does not match HV rows.');

assert(size(HV,2) == numel(algorithms), ...
    'Algorithm count does not match HV columns.');

assert(all(isfinite(HV(:))), ...
    'HV contains NaN or Inf.');

%% ------------------------------------------------------------
% Normalize within each benchmark
% -------------------------------------------------------------
rowBest = max(HV,[],2);

HVrel = 100 .* HV ./ rowBest;

%% ------------------------------------------------------------
% Command-window verification
% -------------------------------------------------------------
fprintf('\n====================================================\n');
fprintf(' COMPONENT-LEVEL ABLATION CHECK\n');
fprintf('====================================================\n');

for i = 1:size(HV,1)

    [bestVal,bestIdx] = max(HV(i,:));

    fprintf('%-12s  Best HV = %.12g  -->  %s\n', ...
        problems{i}, bestVal, algorithms{bestIdx});
end

fprintf('====================================================\n\n');

%% ------------------------------------------------------------
% Create figure
% -------------------------------------------------------------
fig = figure( ...
    'Color','w', ...
    'Units','centimeters', ...
    'Position',[2 2 19 11]);

ax = axes(fig);

imagesc(ax, HVrel);

clim(ax,[85 100]);

colormap(ax,parula(256));

cb = colorbar(ax);
cb.Label.String = 'Median HV relative to best component configuration (%)';
cb.Label.FontSize = 9;

%% Axes
set(ax, ...
    'XTick',1:numel(algorithms), ...
    'XTickLabel',algorithms, ...
    'YTick',1:numel(problems), ...
    'YTickLabel',problems, ...
    'YDir','reverse', ...
    'FontName','Times New Roman', ...
    'FontSize',9, ...
    'TickLength',[0 0], ...
    'Box','on');

xtickangle(ax,25);

xlabel(ax,'Component configuration', ...
    'FontName','Times New Roman', ...
    'FontSize',10);

ylabel(ax,'Benchmark problem', ...
    'FontName','Times New Roman', ...
    'FontSize',10);

title(ax, ...
    'Component-Level Ablation: Relative Median Hypervolume', ...
    'FontName','Times New Roman', ...
    'FontWeight','normal', ...
    'FontSize',11);

%% ------------------------------------------------------------
% Cell labels
% -------------------------------------------------------------
for r = 1:size(HVrel,1)

    for c = 1:size(HVrel,2)

        value = HVrel(r,c);

        if value < 91
            txtColor = 'w';
        else
            txtColor = 'k';
        end

        text(ax,c,r,sprintf('%.2f',value), ...
            'HorizontalAlignment','center', ...
            'VerticalAlignment','middle', ...
            'FontName','Times New Roman', ...
            'FontSize',8, ...
            'Color',txtColor);
    end
end

%% ------------------------------------------------------------
% Mark best component-level configuration
% -------------------------------------------------------------
hold(ax,'on');

for r = 1:size(HV,1)

    best = max(HV(r,:));

    tol = max(1e-10,1e-10*abs(best));

    idx = find(abs(HV(r,:) - best) <= tol);

    for c = idx
        rectangle(ax, ...
            'Position',[c-0.5 r-0.5 1 1], ...
            'EdgeColor','k', ...
            'LineWidth',1.8);
    end
end

hold(ax,'off');

xlim(ax,[0.5 size(HV,2)+0.5]);
ylim(ax,[0.5 size(HV,1)+0.5]);

%% ------------------------------------------------------------
% Export
% -------------------------------------------------------------
exportgraphics(fig, ...
    'ablation_hv_f2_f5_f7_f8_f9_FINAL.pdf', ...
    'ContentType','vector');

exportgraphics(fig, ...
    'ablation_hv_f2_f5_f7_f8_f9_FINAL.png', ...
    'Resolution',600);

fprintf('Saved files:\n');
fprintf('  ablation_hv_f2_f5_f7_f8_f9_FINAL.pdf\n');
fprintf('  ablation_hv_f2_f5_f7_f8_f9_FINAL.png\n');