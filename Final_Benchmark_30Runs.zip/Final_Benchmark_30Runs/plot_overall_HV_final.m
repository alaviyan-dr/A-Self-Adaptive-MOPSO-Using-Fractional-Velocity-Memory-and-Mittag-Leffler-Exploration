%% plot_overall_HV_final.m
% Final publication-quality summary of median HV results
% 10 benchmark functions x 11 algorithms
%
% IMPORTANT:
% - This script DOES NOT rerun any optimizer.
% - Values are the frozen median HV results from the final 30-run benchmark.
% - Normalization is performed separately for each benchmark only for
%   visualization. Raw HV values remain those reported in the manuscript.
%
% Output:
%   overall_hv_comparison.pdf
%   overall_hv_comparison.png

clear;
clc;
close all;

%% ------------------------------------------------------------
%  Algorithm labels
% -------------------------------------------------------------
algorithms = { ...
    'SA-MOPSO-FVML', ...
    'Classical MOPSO', ...
    'MOPSO-CD', ...
    'MOPSO-FM', ...
    'MOPSO-ML', ...
    'MOPSO-Grid', ...
    'Levy-MOPSO', ...
    'NSGA-II', ...
    'MOEA/D', ...
    'MOFA', ...
    'MOABC'};

functions = { ...
    'F1 (ZDT1)', ...
    'F2 (ZDT2)', ...
    'F3 (ZDT3)', ...
    'F4 (DTLZ1)', ...
    'F5 (DTLZ2)', ...
    'F6 (DTLZ3)', ...
    'F7 (DTLZ4)', ...
    'F8', ...
    'F9', ...
    'F10'};

%% ------------------------------------------------------------
%  Frozen final median HV values
%  Rows: benchmark functions F1-F10
%  Columns: algorithms in the order defined above
% -------------------------------------------------------------
HV = [ ...

% SA            Classical        CD              FM              ML              Grid            Levy            NSGA-II         MOEA/D           MOFA            MOABC

6.552609,        6.553065,        6.552992,       6.552926,       6.552942,       6.552535,       6.552972,       6.551673,       6.552711,       4.260668,       6.293976;        % F1

4.428350,        4.001184,        4.001184,       3.986117,       4.428099,       4.427699,       3.659804,       4.427257,       4.428120,       1.670920,       4.166021;        % F2

5.904661,        5.904807,        5.904670,       5.904927,       5.904835,       5.904614,       5.904865,       5.903426,       5.901072,       3.366040,       5.864003;        % F3

14355095.289522, 14360158.029952, 14358075.484243,14355741.596811,14355274.819325,14357536.894836,14358003.672322,14362384.199503,14362384.199503,13981062.899006,14362384.199503; % F4

13.701434,       13.563178,       13.634670,      13.663288,      13.692229,      13.616725,      13.556122,      13.675610,      13.702222,      13.002129,      13.686534;      % F5

2945925434.971303,2950978264.907737,2948895080.635698,2950335580.398278,2949064985.735900,2949212729.301293,2949537765.145157,2954871307.855837,2954871307.855837,2945666883.731866,2954871307.855837; % F6

9.431936,        9.060863,        9.163322,       9.386644,       9.403339,       9.344666,       9.041305,       9.407959,       9.418956,       6.258482,       9.043539;        % F7

3318.840267,     1809.640229,     3038.364606,    3218.489015,    3278.163298,    3178.055687,    1849.809324,    3329.538351,    3258.875555,    2944.549230,    2970.044136;     % F8

163725120.721727,127976927.397664,157519981.554775,160528453.671641,161941538.906958,159921946.964252,128077714.770508,164361111.070716,118132001.713606,98881603.075392,148132698.789081; % F9

82424.425671,    20695.381805,    84948.680959,   75010.097250,   81491.383875,   80669.675881,   16318.532439,   114029.635296,  114234.138909,  65552.452239,   86792.321215       % F10
];

%% ------------------------------------------------------------
%  Basic integrity checks
% -------------------------------------------------------------
assert(size(HV,1) == numel(functions), ...
    'Number of HV rows does not match number of benchmark functions.');

assert(size(HV,2) == numel(algorithms), ...
    'Number of HV columns does not match number of algorithms.');

assert(all(isfinite(HV(:))), ...
    'HV matrix contains NaN or Inf.');

assert(all(HV(:) >= 0), ...
    'Unexpected negative HV value detected.');

%% ------------------------------------------------------------
%  Normalize separately within each benchmark
%  Best median HV on each benchmark = 100%
% -------------------------------------------------------------
bestHV = max(HV, [], 2);

HVrelative = 100 .* HV ./ bestHV;

%% ------------------------------------------------------------
%  Print a verification summary in Command Window
% -------------------------------------------------------------
fprintf('\n============================================================\n');
fprintf(' FINAL MEDIAN-HV CHECK\n');
fprintf('============================================================\n');

for f = 1:numel(functions)

    bestValue = bestHV(f);

    % Detect exact/numerical ties
    tol = max(1e-10, 1e-10 * abs(bestValue));
    bestIdx = find(abs(HV(f,:) - bestValue) <= tol);

    fprintf('%-12s  Best HV = %.12g   ', functions{f}, bestValue);

    fprintf('Best algorithm(s): ');
    for k = 1:numel(bestIdx)
        fprintf('%s', algorithms{bestIdx(k)});
        if k < numel(bestIdx)
            fprintf(', ');
        end
    end
    fprintf('\n');
end

fprintf('============================================================\n\n');

%% ------------------------------------------------------------
%  Publication-quality figure
% -------------------------------------------------------------
fig = figure( ...
    'Color','w', ...
    'Units','centimeters', ...
    'Position',[2 2 25 14]);

ax = axes(fig);

imagesc(ax, HVrelative);

% Fixed 0-100 scale has a direct interpretation as percentage of
% the best median HV for each benchmark.
clim(ax, [0 100]);

colormap(ax, parula(256));

cb = colorbar(ax);
cb.Label.String = 'Median HV relative to best on each problem (%)';
cb.Label.FontSize = 10;

%% Axis labels
set(ax, ...
    'XTick',1:numel(algorithms), ...
    'XTickLabel',algorithms, ...
    'YTick',1:numel(functions), ...
    'YTickLabel',functions, ...
    'YDir','reverse', ...
    'FontName','Times New Roman', ...
    'FontSize',9, ...
    'TickLength',[0 0], ...
    'Box','on');

xtickangle(ax, 42);

xlabel(ax, 'Algorithm', ...
    'FontName','Times New Roman', ...
    'FontSize',10);

ylabel(ax, 'Benchmark problem', ...
    'FontName','Times New Roman', ...
    'FontSize',10);

title(ax, ...
    'Relative Median Hypervolume Performance', ...
    'FontName','Times New Roman', ...
    'FontSize',11, ...
    'FontWeight','normal');

%% ------------------------------------------------------------
%  Write normalized values inside cells
% -------------------------------------------------------------
for r = 1:size(HVrelative,1)

    for c = 1:size(HVrelative,2)

        value = HVrelative(r,c);

        % White text on darker cells; black text otherwise
        if value < 55
            txtColor = 'w';
        else
            txtColor = 'k';
        end

        text(ax, c, r, sprintf('%.1f',value), ...
            'HorizontalAlignment','center', ...
            'VerticalAlignment','middle', ...
            'FontName','Times New Roman', ...
            'FontSize',6.8, ...
            'Color',txtColor);
    end
end

%% ------------------------------------------------------------
%  Outline the best median-HV cell(s) for each problem
% -------------------------------------------------------------
hold(ax,'on');

for r = 1:size(HV,1)

    rowBest = max(HV(r,:));

    tol = max(1e-10, 1e-10 * abs(rowBest));

    bestCols = find(abs(HV(r,:) - rowBest) <= tol);

    for c = bestCols
        rectangle(ax, ...
            'Position',[c-0.5, r-0.5, 1, 1], ...
            'EdgeColor','k', ...
            'LineWidth',1.6);
    end
end

hold(ax,'off');

%% Keep complete matrix tightly framed
xlim(ax,[0.5 size(HV,2)+0.5]);
ylim(ax,[0.5 size(HV,1)+0.5]);

%% ------------------------------------------------------------
%  Export
% -------------------------------------------------------------
exportgraphics(fig, ...
    'overall_hv_comparison.pdf', ...
    'ContentType','vector');

exportgraphics(fig, ...
    'overall_hv_comparison.png', ...
    'Resolution',600);

fprintf('Saved:\n');
fprintf('  overall_hv_comparison.pdf\n');
fprintf('  overall_hv_comparison.png\n');