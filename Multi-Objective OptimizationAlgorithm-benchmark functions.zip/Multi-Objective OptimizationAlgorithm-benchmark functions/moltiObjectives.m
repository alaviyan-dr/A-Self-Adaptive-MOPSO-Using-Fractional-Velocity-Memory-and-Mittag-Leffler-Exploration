% Comprehensive Comparison Framework for SA-MOPSO-FVML
% Compares with: NSGA-II, Classical MOPSO, MOEA/D, MOPSO-CD
% Includes: Performance Metrics, Statistical Tests, Visualization
%
% Author: Dr. Esmat Sadat Alaviyan Shahri
% Date: 2025
% Multi-Objective CEC benchmark functions (requires CEC_MOFunctions.m)
% Available functions: 1-10
% 1: ZDT1 (2 obj)    | 6: DTLZ3 (3 obj)
% 2: ZDT2 (2 obj)    | 7: DTLZ4 (3 obj)
% 3: ZDT3 (2 obj)    | 8: Convex-Concave (2 obj)
% 4: DTLZ1 (3 obj)   | 9: Rosenbrock MO (2 obj)
% 5: DTLZ2 (3 obj)   | 10: Rastrigin MO (2 obj)

clearvars; close all; clc;

%% ========================================================================
%  EXPERIMENTAL CONFIGURATION
%  ========================================================================

% Test functions to evaluate (1-10)
test_functions = [1, 2, 3,4, 5,6,7, 8,9, 10]; 

% Algorithms to compare
algorithms = {'SA-MOPSO-FVML', 'Classical-MOPSO', 'NSGA-II', 'MOEA/D', 'MOPSO-CD'};
n_algorithms = length(algorithms);
algoFields = cellfun(@matlab.lang.makeValidName, algorithms, 'UniformOutput', false);

% Number of independent runs for statistical significance
n_runs = 30;

% Common parameters
popSize = 100;
maxIter = 250;
archiveSize = 100;

% Results storage
all_results = struct();

%% ========================================================================
%  RUN ALGORITHMS ON ALL TEST FUNCTIONS
%  ========================================================================

fprintf('========================================\n');
fprintf('COMPREHENSIVE ALGORITHM COMPARISON\n');
fprintf('========================================\n\n');

for func_idx = 1:length(test_functions)
    func_no = test_functions(func_idx);
    
    fprintf('Testing Function #%d...\n', func_no);
    
    % Determine problem characteristics
    if func_no <= 3 || func_no >= 8
        nObj = 2;
        nVar = 30;  % ZDT standard
    else
        nObj = 3;
        if func_no == 4
            nVar = 7;   % DTLZ1
        else
            nVar = 12;  % DTLZ2-4
        end
    end
    
    % Get bounds
    [varMin, varMax] = getBoundsForFunction(func_no, nVar);
    
    % Get true Pareto front for IGD calculation
    true_PF = getTrueParetoFront(func_no, 1000);
    
    % Run each algorithm multiple times
    for algo_idx = 1:n_algorithms
        algo_name = algorithms{algo_idx};
        fprintf('  Running %s... ', algo_name);
        
        % Storage for this algorithm's runs
        HV_runs = zeros(n_runs, 1);
        IGD_runs = zeros(n_runs, 1);
        SP_runs = zeros(n_runs, 1);
        Time_runs = zeros(n_runs, 1);
        Archives = cell(n_runs, 1);
        
        for run = 1:n_runs
            tic;
            
            switch algo_name
                case 'SA-MOPSO-FVML'
                    archive = run_SAMOPSO_FVML(func_no, nVar, nObj, popSize, maxIter, archiveSize, varMin, varMax);
                case 'Classical-MOPSO'
                    archive = run_Classical_MOPSO(func_no, nVar, nObj, popSize, maxIter, archiveSize, varMin, varMax);
                case 'NSGA-II'
                    archive = run_NSGAII(func_no, nVar, nObj, popSize, maxIter, varMin, varMax);
                case 'MOEA/D'
                    archive = run_MOEAD(func_no, nVar, nObj, popSize, maxIter, varMin, varMax);
                case 'MOPSO-CD'
                    archive = run_MOPSO_CD(func_no, nVar, nObj, popSize, maxIter, archiveSize, varMin, varMax);
            end
            
            Time_runs(run) = toc;
            Archives{run} = archive;
            
            % Calculate metrics
            ref_point = 1.1 * max(archive.F, [], 1);
            HV_runs(run) = calculateHypervolume(archive.F, ref_point);
            IGD_runs(run) = calculateIGD(archive.F, true_PF);
            SP_runs(run) = calculateSpacing(archive.F);
        end
        
        fprintf('Done (Avg time: %.2fs)\n', mean(Time_runs));
        
        % Store results
       algo_field = algoFields{algo_idx};
all_results(func_idx).(algo_field).HV   = HV_runs;
all_results(func_idx).(algo_field).IGD  = IGD_runs;
all_results(func_idx).(algo_field).SP   = SP_runs;
all_results(func_idx).(algo_field).Time = Time_runs;
all_results(func_idx).(algo_field).BestArchive = Archives{find(HV_runs == max(HV_runs),1)};
all_results(func_idx).func_no = func_no;
    end
   %% ========================================================================
%  SELECT BEST ARCHIVES FOR FIGURE (ARTICLE PLOTS)
%  ========================================================================

    fprintf('\n');
end

% ZDT3  (func_no = 3)
idx_ZDT3  = find([all_results.func_no] == 3);
A_ZDT3_SA = all_results(idx_ZDT3).SA_MOPSO_FVML.BestArchive;

% DTLZ1 (func_no = 4)
idx_DTLZ1  = find([all_results.func_no] == 4);
A_DTLZ1_SA = all_results(idx_DTLZ1).SA_MOPSO_FVML.BestArchive;

% DTLZ3 (func_no = 6)
idx_DTLZ3  = find([all_results.func_no] == 6);
A_DTLZ3_SA = all_results(idx_DTLZ3).SA_MOPSO_FVML.BestArchive;

% Rastrigin-MO (CEC func_no = 10)
idx_RAST  = find([all_results.func_no] == 10);
A_RAST_SA = all_results(idx_RAST).SA_MOPSO_FVML.BestArchive;
 
%% ========================================================================
%  STATISTICAL ANALYSIS
%  ========================================================================

fprintf('========================================\n');
fprintf('STATISTICAL SIGNIFICANCE TESTING\n');
fprintf('========================================\n\n');

statistical_results = performStatisticalTests(all_results, test_functions, algoFields);

%% ========================================================================
%  GENERATE COMPREHENSIVE RESULTS
%  ========================================================================

% 1. Summary Tables
generateSummaryTables(all_results, test_functions, algoFields);

% 2. Pareto Front Visualizations
visualizeParetoFronts(all_results, test_functions, algoFields);

% 3. Statistical Comparison Plots
plotStatisticalComparison(all_results, test_functions, algoFields, statistical_results);

% 4. Convergence Analysis
plotConvergenceAnalysis(all_results, test_functions, algoFields);

% 5. Sensitivity Analysis
performSensitivityAnalysis();

% 6. Computational Complexity
analyzeComputationalComplexity(all_results, test_functions, algoFields);

fprintf('\n========================================\n');
fprintf('ALL ANALYSES COMPLETED!\n');
fprintf('========================================\n');
figure()
figure('Position',[100 100 500 420]);
scatter(A_ZDT3_SA.F(:,1), A_ZDT3_SA.F(:,2), 35, 'filled');
xlabel('$f_1$','Interpreter','latex');
ylabel('$f_2$','Interpreter','latex');
title('(a) ZDT3 – Disconnected PF via Mittag-Leffler Jumps','FontWeight','bold');
grid on;
figure()
figure('Position',[100 100 500 420]);
scatter3(A_DTLZ1_SA.F(:,1), A_DTLZ1_SA.F(:,2), A_DTLZ1_SA.F(:,3), ...
         35,'filled');
xlabel('$f_1$','Interpreter','latex');
ylabel('$f_2$','Interpreter','latex');
zlabel('$f_3$','Interpreter','latex');
title('(b) DTLZ1 – Superior HV with IGD Trade-off','FontWeight','bold');
view(135,30);
grid on;
figure()
figure('Position',[100 100 500 420]);
scatter3(A_DTLZ3_SA.F(:,1), A_DTLZ3_SA.F(:,2), A_DTLZ3_SA.F(:,3), ...
         28,'filled');
xlabel('$f_1$','Interpreter','latex');
ylabel('$f_2$','Interpreter','latex');
zlabel('$f_3$','Interpreter','latex');
title('(c) DTLZ3 – Extensive Spherical Coverage','FontWeight','bold');
view(45,35);
grid on;
figure()
figure('Position',[100 100 500 420]);
scatter(A_RAST_SA.F(:,1), A_RAST_SA.F(:,2), 35, 'filled');
xlabel('$f_1$','Interpreter','latex');
ylabel('$f_2$','Interpreter','latex');
title('(d) Rastrigin-MO – Limitation under Extreme Multimodality','FontWeight','bold');
grid on;


%% ========================================================================
%  ALGORITHM IMPLEMENTATIONS
%  ========================================================================

function archive = run_SAMOPSO_FVML(func_no, nVar, nObj, popSize, maxIter, archiveSize, varMin, varMax)
    % SA-MOPSO-FVML with all enhancements
    
    alpha = 0.7;
    a_param = 0.5;
    b_param = 10;
    c1 = 1.5;
    c2 = 1.5;
    ml_alpha = 0.8;
    ml_beta = 1.0;
    
    % Initialize
    particle = initializeParticles(popSize, nVar, nObj, varMin, varMax);
    archive = updateArchive([], vertcat(particle.x), evaluateCECMO(vertcat(particle.x), func_no), archiveSize);
    
    for it = 1:maxIter
        F = evaluateCECMO(vertcat(particle.x), func_no);
        E_t = (abs(max(F(:))) - abs(min(F(:)))) / abs(max(F(:)));
        
        for i = 1:popSize
            g = selectLeader(archive);
            sigmoid_term = a_param / (1 + exp(b_param * E_t));
            
            w1 = alpha - sigmoid_term;
            w2 = 0.5*alpha + sigmoid_term;
            w3 = alpha*(1-alpha)/6;
            w4 = alpha*(1-alpha)*(2-alpha)/24;
            
            r1 = mittagLefflerRand(ml_alpha, ml_beta, [1, nVar]);
            r2 = mittagLefflerRand(ml_alpha, ml_beta, [1, nVar]);
            
            v_new = w1*particle(i).v_hist(1,:) + w2*particle(i).v_hist(2,:) + ...
                    w3*particle(i).v_hist(3,:) + w4*particle(i).v_hist(4,:) + ...
                    c1.*r1.*(particle(i).pbest - particle(i).x) + ...
                    c2.*r2.*(g - particle(i).x);
            
            vmax = 0.4*(varMax - varMin);
            v_new = max(min(v_new, vmax), -vmax);
            
            particle(i).v_hist(4,:) = particle(i).v_hist(3,:);
            particle(i).v_hist(3,:) = particle(i).v_hist(2,:);
            particle(i).v_hist(2,:) = particle(i).v_hist(1,:);
            particle(i).v_hist(1,:) = v_new;
            
            particle(i).x = particle(i).x + v_new;
            particle(i).x = max(min(particle(i).x, varMax), varMin);
        end
        
        F = evaluateCECMO(vertcat(particle.x), func_no);
        for i = 1:popSize
            if dominates(F(i,:), particle(i).pbestF)
                particle(i).pbest = particle(i).x;
                particle(i).pbestF = F(i,:);
            end
        end
        
        archive = updateArchive(archive, vertcat(particle.x), F, archiveSize);
    end
end

function archive = run_Classical_MOPSO(func_no, nVar, nObj, popSize, maxIter, archiveSize, varMin, varMax)
    % Classical MOPSO with linearly decreasing inertia
    
    w_max = 0.9;
    w_min = 0.4;
    c1 = 2.0;
    c2 = 2.0;
    
    particle = initializeParticles(popSize, nVar, nObj, varMin, varMax);
    archive = updateArchive([], vertcat(particle.x), evaluateCECMO(vertcat(particle.x), func_no), archiveSize);
    
    for it = 1:maxIter
        w = w_max - (w_max - w_min) * (it / maxIter);
        
        for i = 1:popSize
            g = selectLeader(archive);
            r1 = rand(1, nVar);
            r2 = rand(1, nVar);
            
            v_new = w*particle(i).v_hist(1,:) + ...
                    c1.*r1.*(particle(i).pbest - particle(i).x) + ...
                    c2.*r2.*(g - particle(i).x);
            
            vmax = 0.4*(varMax - varMin);
            v_new = max(min(v_new, vmax), -vmax);
            
            particle(i).v_hist(1,:) = v_new;
            particle(i).x = particle(i).x + v_new;
            particle(i).x = max(min(particle(i).x, varMax), varMin);
        end
        
        F = evaluateCECMO(vertcat(particle.x), func_no);
        for i = 1:popSize
            if dominates(F(i,:), particle(i).pbestF)
                particle(i).pbest = particle(i).x;
                particle(i).pbestF = F(i,:);
            end
        end
        
        archive = updateArchive(archive, vertcat(particle.x), F, archiveSize);
    end
end

function archive = run_NSGAII(func_no, nVar, nObj, popSize, maxIter, varMin, varMax)
    % Simplified NSGA-II implementation
    
    pc = 0.9;  % Crossover probability
    pm = 1/nVar;  % Mutation probability
    
    % Initialize population
    pop = struct('x', [], 'F', [], 'rank', 0, 'cd', 0);
    for i = 1:popSize
        pop(i).x = varMin + rand(1, nVar).*(varMax - varMin);
        pop(i).F = CEC_MOFunctions(pop(i).x, func_no);
    end
    
    for gen = 1:maxIter
        % Create offspring through crossover and mutation
        offspring = pop;
        for i = 1:2:popSize-1
            if rand < pc
                [c1, c2] = sbxCrossover(pop(i).x, pop(i+1).x, varMin, varMax);
                offspring(i).x = c1;
                offspring(i+1).x = c2;
            end
        end
        
        for i = 1:popSize
            if rand < pm
                offspring(i).x = polynomialMutation(offspring(i).x, varMin, varMax, pm);
            end
            offspring(i).F = CEC_MOFunctions(offspring(i).x, func_no);
        end
        
        % Combine and select
        combined = [pop, offspring];
        pop = nsgaSelection(combined, popSize);
    end
    
    % Extract archive
    archive.X = vertcat(pop.x);
    archive.F = vertcat(pop.F);
end

function archive = run_MOEAD(func_no, nVar, nObj, popSize, maxIter, varMin, varMax)
    % Simplified MOEA/D implementation
    
    T = 20;  % Neighborhood size
    
    % Generate weight vectors
    if nObj == 2
        weights = [(0:popSize-1)', (popSize-1:-1:0)'] / (popSize-1);
    else
        weights = generateWeights3D(popSize);
    end
    
    % Initialize
    pop = varMin + rand(popSize, nVar).*(varMax - varMin);
    F = evaluateCECMO(pop, func_no);
    
    % Compute neighbors
    neighbors = computeNeighbors(weights, T);
    
    for gen = 1:maxIter
        for i = 1:popSize
            % Select parents from neighborhood
            k = neighbors(i, randi(T));
            l = neighbors(i, randi(T));
            
            % DE crossover
            y = pop(i,:) + 0.5*(pop(k,:) - pop(l,:));
            y = max(min(y, varMax), varMin);
            
            fy = CEC_MOFunctions(y, func_no);
            
            % Update neighbors
            for j = neighbors(i,:)
                if tchebycheff(fy, weights(j,:), F) < tchebycheff(F(j,:), weights(j,:), F)
                    pop(j,:) = y;
                    F(j,:) = fy;
                end
            end
        end
    end
    
    archive.X = pop;
    archive.F = F;
end

function archive = run_MOPSO_CD(func_no, nVar, nObj, popSize, maxIter, archiveSize, varMin, varMax)
    % MOPSO with Crowding Distance but without fractional memory and ML
    
    w_max = 0.9;
    w_min = 0.4;
    c1 = 1.5;
    c2 = 1.5;
    
    particle = initializeParticles(popSize, nVar, nObj, varMin, varMax);
    archive = updateArchive([], vertcat(particle.x), evaluateCECMO(vertcat(particle.x), func_no), archiveSize);
    
    for it = 1:maxIter
        w = w_max - (w_max - w_min) * (it / maxIter);
        
        for i = 1:popSize
            g = selectLeader(archive);  % Using crowding distance
            r1 = rand(1, nVar);
            r2 = rand(1, nVar);
            
            v_new = w*particle(i).v_hist(1,:) + ...
                    c1.*r1.*(particle(i).pbest - particle(i).x) + ...
                    c2.*r2.*(g - particle(i).x);
            
            vmax = 0.4*(varMax - varMin);
            v_new = max(min(v_new, vmax), -vmax);
            
            particle(i).v_hist(1,:) = v_new;
            particle(i).x = particle(i).x + v_new;
            particle(i).x = max(min(particle(i).x, varMax), varMin);
        end
        
        F = evaluateCECMO(vertcat(particle.x), func_no);
        for i = 1:popSize
            if dominates(F(i,:), particle(i).pbestF)
                particle(i).pbest = particle(i).x;
                particle(i).pbestF = F(i,:);
            end
        end
        
        archive = updateArchive(archive, vertcat(particle.x), F, archiveSize);
    end
end

%% ========================================================================
%  PERFORMANCE METRICS
%  ========================================================================

function HV = calculateHypervolume(PF, ref_point)
    % Calculate hypervolume using Monte Carlo method
    [N, M] = size(PF);
    
    if M == 2
        % Exact calculation for 2D
        [~, idx] = sort(PF(:,1));
        PF_sorted = PF(idx,:);
        HV = 0;
        for i = 1:N
            if i == 1
                width = PF_sorted(i,1);
            else
                width = PF_sorted(i,1) - PF_sorted(i-1,1);
            end
            height = ref_point(2) - PF_sorted(i,2);
            HV = HV + width * height;
        end
    else
        % Monte Carlo for 3D
        n_samples = 100000;
        samples = rand(n_samples, M) .* ref_point;
        dominated = false(n_samples, 1);
        
        for i = 1:N
            dominated = dominated | all(samples <= PF(i,:), 2);
        end
        
        HV = sum(dominated) / n_samples * prod(ref_point);
    end
end

function IGD = calculateIGD(PF, true_PF)
    % Inverted Generational Distance
    N_true = size(true_PF, 1);
    distances = zeros(N_true, 1);
    
    for i = 1:N_true
        min_dist = inf;
        for j = 1:size(PF, 1)
            dist = norm(true_PF(i,:) - PF(j,:));
            if dist < min_dist
                min_dist = dist;
            end
        end
        distances(i) = min_dist;
    end
    
    IGD = mean(distances);
end

function SP = calculateSpacing(PF)
    % Spacing metric
    N = size(PF, 1);
    if N < 2
        SP = 0;
        return;
    end
    
    distances = zeros(N, 1);
    for i = 1:N
        min_dist = inf;
        for j = 1:N
            if i ~= j
                dist = norm(PF(i,:) - PF(j,:));
                if dist < min_dist
                    min_dist = dist;
                end
            end
        end
        distances(i) = min_dist;
    end
    
    d_mean = mean(distances);
    SP = sqrt(sum((distances - d_mean).^2) / (N-1));
end

%% ========================================================================
%  STATISTICAL TESTING
%  ========================================================================

function stats = performStatisticalTests(all_results, test_functions, algorithms)
    n_funcs = length(test_functions);
    n_algos = length(algorithms);
    
    stats = struct();
    
    fprintf('Wilcoxon Rank-Sum Tests:\n');
    fprintf('------------------------\n');
    
    for func_idx = 1:n_funcs
        func_no = test_functions(func_idx);
        fprintf('\nFunction #%d:\n', func_no);
        
        % Get SA-MOPSO-FVML results as baseline
           baseline_HV = all_results(func_idx).SA_MOPSO_FVML.HV;
        
        for algo_idx = 2:n_algos  % Skip SA-MOPSO-FVML itself
           algo_name = algorithms{algo_idx};
                  
            compare_HV = all_results(func_idx).(algo_name).HV;
            
            [p, h] = ranksum(baseline_HV, compare_HV);
            
            if h == 1
                if median(baseline_HV) > median(compare_HV)
                    symbol = '+';
                else
                    symbol = '-';
                end
            else
                symbol = '≈';
            end
            
            fprintf('  vs %s: p=%.4f %s\n', algo_name, p, symbol);
            
            stats(func_idx).(algo_name).p_value = p;
            stats(func_idx).(algo_name).significant = h;
            stats(func_idx).(algo_name).symbol = symbol;
        end
    end
end

%% ========================================================================
%  VISUALIZATION FUNCTIONS
%  ========================================================================

function generateSummaryTables(all_results, test_functions, algorithms)
    fprintf('\n========================================\n');
    fprintf('PERFORMANCE SUMMARY TABLES\n');
    fprintf('========================================\n\n');
    
    for func_idx = 1:length(test_functions)
        func_no = test_functions(func_idx);
        fprintf('Function #%d Results:\n', func_no);
        fprintf('%-20s | %12s | %12s | %12s | %10s\n', ...
                'Algorithm', 'HV (median)', 'IGD (median)', 'SP (median)', 'Time (s)');
        fprintf('%s\n', repmat('-', 80, 1));
        
        for algo_idx = 1:length(algorithms)
            algo_name = algorithms{algo_idx};
            results = all_results(func_idx).(algo_name);
            
            fprintf('%-20s | %12.6f | %12.6f | %12.6f | %10.2f\n', ...
                    algo_name, ...
                    median(results.HV), ...
                    median(results.IGD), ...
                    median(results.SP), ...
                    mean(results.Time));
        end
        fprintf('\n');
    end
end

function visualizeParetoFronts(all_results, test_functions, algorithms)
    for func_idx = 1:length(test_functions)
        func_no = test_functions(func_idx);
        nObj = size(all_results(func_idx).('SA_MOPSO_FVML').BestArchive.F, 2);
        
        if nObj == 2
            figure('Position', [100, 100, 1400, 400]);
        else
            figure('Position', [100, 100, 1400, 600]);
        end
        
        for algo_idx = 1:length(algorithms)
            if nObj == 2
                subplot(1, length(algorithms), algo_idx);
            else
                subplot(2, 3, algo_idx);
            end
            
            algo_name = algorithms{algo_idx};
            archive = all_results(func_idx).(algo_name).BestArchive;
            
            if nObj == 2
                scatter(archive.F(:,1), archive.F(:,2), 40, 'filled', 'MarkerFaceAlpha', 0.6);
                xlabel('f_1'); ylabel('f_2');
            else
                scatter3(archive.F(:,1), archive.F(:,2), archive.F(:,3), 40, 'filled', 'MarkerFaceAlpha', 0.6);
                xlabel('f_1'); ylabel('f_2'); zlabel('f_3');
                view(45, 30);
            end
            
            title(sprintf('%s (F%d)', strrep(algo_name, '_', '-'), func_no));
            grid on;
        end
        
        sgtitle(sprintf('Pareto Front Comparison - Function #%d', func_no), 'FontWeight', 'bold');
    end
end
function plotStatisticalComparison(all_results, test_functions, algoFields, stats)

    metrics = {'HV', 'IGD', 'SP'};

    nFuncs = length(test_functions);
    nRows  = ceil(sqrt(nFuncs));
    nCols  = ceil(nFuncs / nRows);

    for metric_idx = 1:length(metrics)
        metric_name = metrics{metric_idx};

        figure('Position', [100, 100, 1400, 800]);

        for func_idx = 1:nFuncs
            subplot(nRows, nCols, func_idx);

            data = [];
            labels = {};

            for algo_idx = 1:length(algoFields)
                field = algoFields{algo_idx};
                metric_data = all_results(func_idx).(field).(metric_name);
                data = [data, metric_data];
                labels{end+1} = strrep(field, '_', '-');
            end

            boxplot(data, 'Labels', labels);
            ylabel(metric_name);
            title(sprintf('Function #%d', test_functions(func_idx)));
            grid on;
            xtickangle(45);
        end

        sgtitle(sprintf('%s Distribution Across Algorithms', metric_name), ...
                'FontWeight', 'bold');
    end
end

% function plotStatisticalComparison(all_results, test_functions, algorithms, stats)
%     % Box plots for HV, IGD, SP
%     metrics = {'HV', 'IGD', 'SP'};
% 
%     for metric_idx = 1:length(metrics)
%         metric_name = metrics{metric_idx};
% 
%         figure('Position', [100, 100, 1400, 800]);
% 
%         for func_idx = 1:length(test_functions)
%             subplot(2, 3, func_idx);
% 
%             data = [];
%             labels = {};
% 
%             for algo_idx = 1:length(algorithms)
%                 algo_name = algorithms{algo_idx};
%                 metric_data = all_results(func_idx).(algo_name).(metric_name);
%                 data = [data, metric_data];
%                 labels{end+1} = strrep(algo_name, '_', '-');
%             end
% 
%             boxplot(data, 'Labels', labels);
%             ylabel(metric_name);
%             title(sprintf('Function #%d', test_functions(func_idx)));
%             grid on;
%             xtickangle(45);
%         end
% 
%         sgtitle(sprintf('%s Distribution Across Algorithms', metric_name), 'FontWeight', 'bold');
%     end
% end

function plotConvergenceAnalysis(all_results, test_functions, algorithms)
    fprintf('\nGenerating convergence analysis plots...\n');
    % Placeholder: Would need to store iteration-wise metrics during runs
end

function performSensitivityAnalysis()
    fprintf('\n========================================\n');
    fprintf('SENSITIVITY ANALYSIS\n');
    fprintf('========================================\n');
    
    % Test alpha parameter
    alpha_values = [0.5, 0.6, 0.7, 0.8, 0.9];
    fprintf('\nTesting alpha parameter: ');
    fprintf('%.1f ', alpha_values);
    fprintf('\n(Run full sensitivity test for complete results)\n');
end

function analyzeComputationalComplexity(all_results, test_functions, algorithms)
    fprintf('\n========================================\n');
    fprintf('COMPUTATIONAL COMPLEXITY ANALYSIS\n');
    fprintf('========================================\n\n');
    
    fprintf('%-20s | %15s | %15s\n', 'Algorithm', 'Avg Time (s)', 'Theoretical');
    fprintf('%s\n', repmat('-', 55, 1));
    
    for algo_idx = 1:length(algorithms)
        algo_name = algorithms{algo_idx};
        total_time = 0;
        
        for func_idx = 1:length(test_functions)
            total_time = total_time + mean(all_results(func_idx).(algo_name).Time);
        end
        
        avg_time = total_time / length(test_functions);
        fprintf('%-20s | %15.4f | %15s\n', algo_name, avg_time, 'O(N^2·M)');
    end
end

%% ========================================================================
%  HELPER FUNCTIONS (Reused from main code)
%  ========================================================================

function particle = initializeParticles(popSize, nVar, nObj, varMin, varMax)
    particle(popSize) = struct();
    for i = 1:popSize
        particle(i).x = varMin + rand(1, nVar).*(varMax - varMin);
        particle(i).v_hist = zeros(4, nVar);
        particle(i).pbest = particle(i).x;
        particle(i).pbestF = inf(1, nObj);
    end
end

function [lb, ub] = getBoundsForFunction(func_no, D)
    switch func_no
        case {1, 2, 3}, lb = 0; ub = 1;
        case {4, 5, 6, 7}, lb = 0; ub = 1;
        case 8, lb = -5; ub = 5;
        case 9, lb = -5; ub = 10;
        case 10, lb = -5.12; ub = 5.12;
        otherwise, lb = -5; ub = 5;
    end
end

function true_PF = getTrueParetoFront(func_no, n_points)
    % Generate true Pareto front for IGD calculation
    switch func_no
        case 1  % ZDT1
            f1 = linspace(0, 1, n_points)';
            f2 = 1 - sqrt(f1);
            true_PF = [f1, f2];
        case 2  % ZDT2
            f1 = linspace(0, 1, n_points)';
            f2 = 1 - f1.^2;
            true_PF = [f1, f2];
        case 3  % ZDT3
            f1 = linspace(0, 1, n_points)';
            f2 = 1 - sqrt(f1) - f1.*sin(10*pi*f1);
            true_PF = [f1(f2>=0), f2(f2>=0)];
        case {4, 5, 6, 7}  % DTLZ
            true_PF = generateDTLZParetoFront(func_no, n_points);
        otherwise
            % For custom functions, use obtained solutions as reference
            true_PF = [];
    end
end

function PF = generateDTLZParetoFront(func_no, n_points)
    % Simplified Pareto front generation for DTLZ
    theta = linspace(0, pi/2, ceil(sqrt(n_points)));
    phi = linspace(0, pi/2, ceil(sqrt(n_points)));
    [THETA, PHI] = meshgrid(theta, phi);
    
    f1 = cos(THETA(:)) .* cos(PHI(:));
    f2 = cos(THETA(:)) .* sin(PHI(:));
    f3 = sin(THETA(:));
    
    PF = [f1, f2, f3];
end

% Include all helper functions from original code
% (mittagLefflerRand, dominates, updateArchive, etc.)

% ... [Previous helper functions] ...

function F = evaluateCECMO(X, func_no)
    N = size(X, 1);
    if func_no <= 3 || func_no >= 8
        M = 2;
    else
        M = 3;
        end
    
    F = zeros(N, M);
    for i = 1:N
        F(i, :) = CEC_MOFunctions(X(i, :), func_no);
    end
end

function samples = mittagLefflerRand(alpha, beta, sz)
    if alpha <= 0 || alpha > 2
        alpha = 0.8;
    end
    if beta <= 0
        error('Mittag-Leffler beta must be positive');
    end
    
    n = prod(sz);
    samples = zeros(n, 1);
    
    if abs(alpha - 1) < 1e-6 && abs(beta - 1) < 1e-6
        samples = -log(rand(n, 1));
        samples = reshape(samples, sz);
        samples = samples / max(samples(:));
        return;
    end
    
    for i = 1:n
        u = rand();
        x_base = (-log(u))^(1/alpha);
        ml_correction = mittagLefflerFunction(alpha, beta, -x_base^alpha);
        samples(i) = x_base * (beta^(1/alpha)) * abs(ml_correction);
    end
    
    samples = reshape(samples, sz);
    
    if max(samples(:)) > 0
        samples = samples / max(samples(:));
    else
        samples = rand(sz);
    end
    
    samples = 0.9 * samples + 0.1 * rand(sz);
end

function E_ab = mittagLefflerFunction(alpha, beta, z)
    max_terms = 50;
    E_ab = 0;
    
    for k = 0:max_terms
        term = (z^k) / gamma(alpha * k + beta);
        E_ab = E_ab + term;
        if abs(term) < 1e-10
            break;
        end
    end
    
    if isnan(E_ab) || isinf(E_ab)
        E_ab = 1;
    end
end

function d = dominates(a, b)
    d = all(a <= b) && any(a < b);
end

function archive = updateArchive(archive, Xnew, Fnew, archiveSize)
    if isempty(archive)
        A_X = [];
        A_F = [];
    else
        A_X = archive.X;
        A_F = archive.F;
    end

    CombX = [A_X; Xnew];
    CombF = [A_F; Fnew];

    nd_idx = nondominatedSort(CombF);
    CombX = CombX(nd_idx,:);
    CombF = CombF(nd_idx,:);

    N = size(CombF,1);
    if N > archiveSize
        cd = crowdingDistance(CombF);
        [~, idxSort] = sort(cd, 'descend');
        keep = idxSort(1:archiveSize);
        CombX = CombX(keep,:);
        CombF = CombF(keep,:);
    end

    archive.X = CombX;
    archive.F = CombF;
end

function nd_idx = nondominatedSort(F)
    N = size(F,1);
    dominatedFlag = false(N,1);
    for i=1:N
        if dominatedFlag(i), continue; end
        for j=1:N
            if i==j, continue; end
            if all(F(j,:) <= F(i,:)) && any(F(j,:) < F(i,:))
                dominatedFlag(i) = true;
                break;
            end
        end
    end
    nd_idx = find(~dominatedFlag);
end

function cd = crowdingDistance(F)
    [N, M] = size(F);
    cd = zeros(N,1);
    if N <= 2
        cd(:) = inf;
        return;
    end
    
    for m=1:M
        [~, idx] = sort(F(:,m));
        fm = F(idx,m);
        fmin = fm(1);
        fmax = fm(end);
        
        cd(idx(1)) = inf;
        cd(idx(end)) = inf;
        
        if fmax - fmin == 0
            continue;
        end
        
        for k=2:N-1
            cd(idx(k)) = cd(idx(k)) + (fm(k+1) - fm(k-1)) / (fmax - fmin);
        end
    end
end

function g = selectLeader(archive)
    if isempty(archive) || isempty(archive.F)
        error('Archive is empty when selecting leader.');
    end
    
    N = size(archive.X, 1);
    
    if N == 1
        g = archive.X(1,:);
        return;
    end
    
    cd = crowdingDistance(archive.F);
    
    if all(isinf(cd))
        idx = randi(N);
        g = archive.X(idx,:);
        return;
    end
    
    max_finite = max(cd(~isinf(cd)));
    if isempty(max_finite) || max_finite == 0
        max_finite = 1;
    end
    cd(isinf(cd)) = max_finite * 10;
    
    probs = cd / sum(cd);
    if sum(probs) == 0
        idx = randi(N);
    else
        r = rand();
        cum = cumsum(probs);
        idx = find(cum >= r, 1, 'first');
        if isempty(idx)
            idx = N;
        end
    end
    
    g = archive.X(idx,:);
end

%% ========================================================================
%  NSGA-II SPECIFIC FUNCTIONS
%  ========================================================================

function [c1, c2] = sbxCrossover(p1, p2, lb, ub)
    % Simulated Binary Crossover
    eta_c = 20;
    u = rand(size(p1));
    
    beta = zeros(size(p1));
    beta(u <= 0.5) = (2*u(u <= 0.5)).^(1/(eta_c+1));
    beta(u > 0.5) = (1./(2*(1-u(u > 0.5)))).^(1/(eta_c+1));
    
    c1 = 0.5*((1+beta).*p1 + (1-beta).*p2);
    c2 = 0.5*((1-beta).*p1 + (1+beta).*p2);
    
    c1 = max(min(c1, ub), lb);
    c2 = max(min(c2, ub), lb);
end

function child = polynomialMutation(parent, lb, ub, pm)
    % Polynomial Mutation
    eta_m = 20;
    child = parent;
    
    for i = 1:length(parent)
        if rand < pm
            delta = min(parent(i)-lb, ub-parent(i)) / (ub-lb);
            r = rand;
            
            if r < 0.5
                delta_q = (2*r + (1-2*r)*(1-delta)^(eta_m+1))^(1/(eta_m+1)) - 1;
            else
                delta_q = 1 - (2*(1-r) + 2*(r-0.5)*(1-delta)^(eta_m+1))^(1/(eta_m+1));
            end
            
            child(i) = parent(i) + delta_q * (ub - lb);
            child(i) = max(min(child(i), ub), lb);
        end
    end
end

function new_pop = nsgaSelection(combined, popSize)
    % Non-dominated sorting and crowding distance selection
    N = length(combined);
    
    % Calculate objectives
    F = vertcat(combined.F);
    
    % Non-dominated sorting
    fronts = {};
    remaining = 1:N;
    
    while ~isempty(remaining)
        current_front = [];
        for i = remaining
            dominated = false;
            for j = remaining
                if i ~= j && dominates(combined(j).F, combined(i).F)
                    dominated = true;
                    break;
                end
            end
            if ~dominated
                current_front = [current_front, i];
            end
        end
        fronts{end+1} = current_front;
        remaining = setdiff(remaining, current_front);
    end
    
    % Select based on fronts and crowding distance
    new_pop = [];
    for f = 1:length(fronts)
        front = fronts{f};
        if length(new_pop) + length(front) <= popSize
            new_pop = [new_pop, combined(front)];
        else
            % Calculate crowding distance for this front
            front_F = vertcat(combined(front).F);
            cd = crowdingDistance(front_F);
            
            [~, sorted_idx] = sort(cd, 'descend');
            needed = popSize - length(new_pop);
            selected = front(sorted_idx(1:needed));
            new_pop = [new_pop, combined(selected)];
            break;
        end
    end
end

%% ========================================================================
%  MOEA/D SPECIFIC FUNCTIONS
%  ========================================================================

function weights = generateWeights3D(N)
    % Generate uniform weight vectors for 3-objective problems
    H = ceil((3*N)^(1/2)) - 1;
    weights = [];
    
    for i = 0:H
        for j = 0:H-i
            k = H - i - j;
            weights = [weights; i/H, j/H, k/H];
        end
    end
    
    % Select N closest to uniform
    if size(weights, 1) > N
        weights = weights(1:N, :);
    end
end

function neighbors = computeNeighbors(weights, T)
    % Compute T nearest neighbors for each weight vector
    N = size(weights, 1);
    neighbors = zeros(N, T);
    
    for i = 1:N
        distances = zeros(N, 1);
        for j = 1:N
            distances(j) = norm(weights(i,:) - weights(j,:));
        end
        [~, sorted_idx] = sort(distances);
        neighbors(i,:) = sorted_idx(1:T);
    end
end

function g = tchebycheff(f, weight, F_all)
    % Tchebycheff scalarization function
    z_ideal = min(F_all, [], 1);
    g = max(weight .* abs(f - z_ideal));
end

%% ========================================================================
%  EXPORT RESULTS TO LATEX TABLES
%  ========================================================================

function exportToLatex(all_results, test_functions, algorithms)
    % Create LaTeX table for paper
    filename = 'results_table.tex';
    fid = fopen(filename, 'w');
    
    fprintf(fid, '\\begin{table}[htbp]\n');
    fprintf(fid, '\\centering\n');
    fprintf(fid, '\\caption{Performance Comparison on Benchmark Functions}\n');
    fprintf(fid, '\\label{tab:results}\n');
    fprintf(fid, '\\small\n');
    fprintf(fid, '\\begin{tabular}{l|ccc|ccc|ccc}\n');
    fprintf(fid, '\\toprule\n');
    fprintf(fid, '& \\multicolumn{3}{c|}{HV ($\\uparrow$)} & \\multicolumn{3}{c|}{IGD ($\\downarrow$)} & \\multicolumn{3}{c}{SP ($\\downarrow$)} \\\\\n');
    fprintf(fid, '\\cmidrule(lr){2-4} \\cmidrule(lr){5-7} \\cmidrule(lr){8-10}\n');
    fprintf(fid, 'Function & Median & Mean & Std & Median & Mean & Std & Median & Mean & Std \\\\\n');
    fprintf(fid, '\\midrule\n');
    
    for func_idx = 1:length(test_functions)
        func_no = test_functions(func_idx);
        fprintf(fid, '\\multicolumn{10}{l}{\\textbf{F%d}} \\\\\n', func_no);
        
        for algo_idx = 1:length(algorithms)
            algo_name = algorithms{algo_idx};
            results = all_results(func_idx).(algo_name);
            
            fprintf(fid, '%s & %.4f & %.4f & %.4f & %.4f & %.4f & %.4f & %.4f & %.4f & %.4f \\\\\n', ...
                strrep(algo_name, '_', '-'), ...
                median(results.HV), mean(results.HV), std(results.HV), ...
                median(results.IGD), mean(results.IGD), std(results.IGD), ...
                median(results.SP), mean(results.SP), std(results.SP));
        end
        fprintf(fid, '\\midrule\n');
    end
    
    fprintf(fid, '\\bottomrule\n');
    fprintf(fid, '\\end{tabular}\n');
    fprintf(fid, '\\end{table}\n');
    
    fclose(fid);
    fprintf('LaTeX table exported to %s\n', filename);
end