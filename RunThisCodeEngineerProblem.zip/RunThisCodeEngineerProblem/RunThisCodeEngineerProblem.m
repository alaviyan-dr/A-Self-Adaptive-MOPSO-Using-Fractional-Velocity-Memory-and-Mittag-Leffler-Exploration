%% Main SA-MOPSO-FVML Optimization Program
% Author: Based on Dr Esmat Sadat Alaviyan Shahri's framework
% Date: 2024

clear all; close all; clc;
%% Output folder
outDir = fullfile(pwd, 'results');

if ~exist(outDir, 'dir')
    mkdir(outDir);
end
%% Problem Parameters (User Defined)
initialStates = [0; 1; 0];           % [x0; y0; psi0]
GoolPoints = [50; -12; 56];               % [x_target; y_target; psi_target]
TimeSimulation = 400;                  % Simulation time (seconds)
   
% Variable bounds
% VarMin = [300, 1000, 0.3e6, -20000, -90000, -2e7, -400, -480, -2000, -5,0, 0];
VarMin = [300, 1000, 0.3e6, -20000, -90000, -2e7, -400, -480, -2000, -5,0, 0];

VarMax = [1200, 6000, 2.1e6, -8000, -30000, -2.e6, -200, -200, -600, 10, 20, 500];

% Number of design variables
nVar = numel(VarMax);

% Number of Pareto points to find
nParetoPoints = 20;

%% Algorithm Parameters - Adaptive SA-MOPSO-FVML
SAMOPSO_Params.MaxIt = 14;          % Maximum iterations for engineering case
 SAMOPSO_Params.nPop = 50;           % Population size

% Fractional velocity memory
SAMOPSO_Params.alpha = 0.7;
SAMOPSO_Params.a_param = 0.5;
SAMOPSO_Params.b_param = 10;

% Acceleration coefficients
SAMOPSO_Params.c1 = 1.5;
SAMOPSO_Params.c2 = 1.5;

% Classical inertia fallback
SAMOPSO_Params.w_max = 0.9;
SAMOPSO_Params.w_min = 0.4;

% Bounded Mittag-Leffler-uniform tempered mixture
SAMOPSO_Params.ml_alpha = 0.8;      % 0 < alpha <= 1
SAMOPSO_Params.ml_scale = 1.0;
SAMOPSO_Params.ml_rmax_min = 1.2;
SAMOPSO_Params.ml_rmax_max = 2.2;
SAMOPSO_Params.pML_min = 0.20;
SAMOPSO_Params.pML_max = 0.75;

% Adaptive memory activation
SAMOPSO_Params.pMem_min = 0.20;
SAMOPSO_Params.pMem_max = 0.85;
SAMOPSO_Params.memoryDiversityTarget = 0.30;

% Hybrid grid/crowding leader selection
SAMOPSO_Params.pGrid_min = 0.30;
SAMOPSO_Params.pGrid_max = 0.75;
SAMOPSO_Params.gridDiversityTarget = 0.35;
SAMOPSO_Params.nGrid = 10;
SAMOPSO_Params.leaderBeta = 1.5;

% Velocity control
SAMOPSO_Params.chi_v = 0.88;
SAMOPSO_Params.vmaxRatio = 0.40;

% Stagnation-triggered Mittag-Leffler mutation
SAMOPSO_Params.stallLimit = 10;
SAMOPSO_Params.mutationRate = 0.08;
SAMOPSO_Params.sigmaMax = 0.06;
SAMOPSO_Params.sigmaMin = 0.01;

% Optional initial guesses.
% Keep this explicit for GitHub reproducibility.
baseGuess = [800, 3000, 400000, -18000, -72000, -12400000, ...
             -300, -300, -900, 2.5, 7.7, 250];

VarExample = [1140.5735, 6000, 1820118.4256, ...
             -8000.0000, -32971.9637, -10052162.7446, ...
             -288.7435, -233.6433, -1311.8957, ...
              4, 9.8841, 282.7717];

SAMOPSO_Params.InitialGuesses = [
    baseGuess;
    0.9 * baseGuess;
    0.8 * baseGuess;
    VarExample
];

% Use true only if CostFunctionDPShip depends on base-workspace states.
SAMOPSO_Params.ResetSimulationState = false;

%% Run SA-MOPSO-FVML
fprintf('Running SA-MOPSO-FVML Algorithm...\n');
tic;
[Pareto_SAMOPSO, ParetoPositions_SAMOPSO, RunLog] = SAMOPSO_FVML_Optimization(...
    initialStates, GoolPoints, TimeSimulation, ...
    nVar, VarMin, VarMax, SAMOPSO_Params, nParetoPoints);
time_SAMOPSO = toc;
fprintf('SA-MOPSO-FVML completed in %.2f seconds\n', time_SAMOPSO);

%% Display Parameter Ranges
fprintf('====== PARAMETER RANGES ======\n');
param_names = {'Kp_surge', 'Kp_sway', 'Kp_yaw', ...
               'Kd_surge', 'Kd_sway', 'Kd_yaw', ...
               'Kd1_surge', 'Kd1_sway', 'Kd1_yaw', ...
               'Ki_surge', 'Ki_sway', 'Ki_yaw'};

fprintf('\nResults Summary\n');
% SA-MOPSO-FVML Best
[~, best_samopso_idx] = min(sqrt(sum(Pareto_SAMOPSO.Cost.^2, 2)));
fprintf('SA-MOPSO-FVML Best Solution (Index %d):\n', best_samopso_idx);
fprintf('  Costs: [%.4f, %.4f, %.4f]\n', Pareto_SAMOPSO.Cost(best_samopso_idx, :));
fprintf('  Parameters:\n');
for i = 1:nVar
    fprintf('    %10s = %10.4f\n', param_names{i}, Pareto_SAMOPSO.Position(best_samopso_idx, i));
end
%% Selected solution table for manuscript
selectedPosition = Pareto_SAMOPSO.Position(best_samopso_idx, :);

Flag = true;
[zSelected, ~, SaveSelected] = CostFunctionDPShip( ...
    initialStates, GoolPoints, TimeSimulation, selectedPosition, Flag);

Ts = 0.1;   % Sampling time used in the simulation plots

DP_Selected_Table = makeDPSelectedSolutionTable( ...
    selectedPosition, zSelected, SaveSelected, Ts);

fprintf('\n====== SELECTED DP CONTROLLER TABLE ======\n');
disp(DP_Selected_Table);

% Optional: save table for manuscript preparation
if exist('outDir', 'var')
    writetable(DP_Selected_Table, fullfile(outDir, 'dp_selected_solution_table.csv'));
else
    writetable(DP_Selected_Table, 'dp_selected_solution_table.csv');
end
Flag=false;
%% Plot Results
PlotResults_SAMOPSO(Pareto_SAMOPSO, ParetoPositions_SAMOPSO);

Flag=true;
VarExample = [ ...
    1140.5735,      6000,      1820118.4256,  ...
   -8000.0000, -32971.9637, -10052162.7446, ...
     -288.7435,  -233.6433,  -1311.8957, ...
        4,      9.8841,    282.7717 ];
% %% Get reference trajectory
% initialStatesS1 = [10;3; 5];           % [x0; y0; psi0]
% GoolPointsS1 = [17; 6; 26];               % [x_target; y_target; psi_target]
% [~, Refrences, SaveExampleS1] = CostFunctionDPShip(initialStatesS1, GoolPointsS1, ...
%     TimeSimulation, VarExample,Flag);
%  RmsS1=rms(SaveExampleS1.Observer')
%  MaxS1=max(SaveExampleS1.Observer')
% Flag=true;
% initialStatesS2 = [0; 1;0];           % [x0; y0; psi0]
% GoolPointsS2 = [50; -12; 56];               % [x_target; y_target; psi_target]
%  [~, Refrences, SaveExampleS2] = CostFunctionDPShip(initialStatesS2, GoolPointsS2, ...
%     TimeSimulation, VarExample,Flag);
%   RmsS2=rms(SaveExampleS2.Observer')
%    MaxS2=max(SaveExampleS2.Observer')
%    time = linspace(0, size(SaveExampleS2.Observer,2)*0.1, size(SaveExampleS2.Observer,2));
%    figure('Position', [100 100 900 400]);
% subplot(3,1,1)
% hold on; grid on;
% 
% plot(time, SaveExampleS1.Refrences(1,:), 'k--', 'LineWidth', 2);
% plot(time, SaveExampleS1.Observer(1,:), 'b--', 'LineWidth', 2);
% xlabel('Time (s)');
% ylabel('Surge (m)');
% title('Surge Response for Scenario 1');
%% Get reference trajectory
initialStatesS1 = [10;3; 5];           % [x0; y0; psi0]
GoolPointsS1 = [17; 6; 26];               % [x_target; y_target; psi_target]
[~, Refrences, SaveExampleS1] = CostFunctionDPShip(initialStatesS1, GoolPointsS1, ...
    TimeSimulation, selectedPosition,Flag);
 RmsS1=rms(SaveExampleS1.Observer')
 MaxS1=max(SaveExampleS1.Observer')
Flag=true;
initialStatesS2 = [0; 1;0];           % [x0; y0; psi0]
GoolPointsS2 = [50; -12; 56];               % [x_target; y_target; psi_target]
 [~, Refrences, SaveExampleS2] = CostFunctionDPShip(initialStatesS2, GoolPointsS2, ...
    TimeSimulation, selectedPosition,Flag);
  RmsS2=rms(SaveExampleS2.Observer')
   MaxS2=max(SaveExampleS2.Observer')
   %% Reviewer-requested DP diagnostic indicators
% These indicators are computed after optimization/simulation.
% They are not additional optimization objectives.

DP_Scenario_Diagnostics = makeDPScenarioDiagnosticsTable( ...
    SaveExampleS1, SaveExampleS2, ...
    initialStatesS1, GoolPointsS1, ...
    initialStatesS2, GoolPointsS2, ...
    Ts);

fprintf('\n====== DP SCENARIO DIAGNOSTIC INDICATORS ======\n');
disp(DP_Scenario_Diagnostics);

writetable(DP_Scenario_Diagnostics, ...
    fullfile(outDir, 'dp_scenario_diagnostic_indicators.csv'));
   time = linspace(0, size(SaveExampleS2.Observer,2)*0.1, size(SaveExampleS2.Observer,2));
   figure('Position', [100 100 900 400]);
subplot(3,1,1)
hold on; grid on;

plot(time, SaveExampleS1.Refrences(1,:), 'k--', 'LineWidth', 2);
plot(time, SaveExampleS1.Observer(1,:), 'b--', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Surge (m)');
title('Surge Response for Scenario 1');
%  SWAY RESPONSE - ALL PARETO
% =======================
subplot(3,1,2)
hold on
plot(time, SaveExampleS1.Refrences(2,:), 'k--', 'LineWidth', 2);
plot(time, SaveExampleS1.Observer(2,:), 'b--', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Sway (m)');
title('Sway Response for Scenario 1');
%% =======================
%  YAW RESPONSE - ALL PARETO
% =======================
subplot(3,1,3)
hold on
plot(time, SaveExampleS1.Refrences(3,:), 'k--', 'LineWidth', 2);
plot(time, SaveExampleS1.Observer(3,:), 'b--', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Yaw (degree)');
title('Yaw Response for Scenario 1');

figure('Position', [100 100 900 400]);
subplot(3,1,1)
hold on; grid on;

plot(time, SaveExampleS2.Refrences(1,:), 'k--', 'LineWidth', 2);
plot(time, SaveExampleS2.Observer(1,:), 'b--', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Surge (m)');
title('Surge Response for Scenario 2');

%  SWAY RESPONSE - ALL PARETO
% =======================
subplot(3,1,2)
hold on
plot(time, SaveExampleS2.Refrences(2,:), 'k--', 'LineWidth', 2);
plot(time, SaveExampleS2.Observer(2,:), 'b--', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Sway (m)');
title('Sway Response for Scenario 2');
%% =======================
%  YAW RESPONSE - ALL PARETO
% =======================
subplot(3,1,3)
hold on
plot(time, SaveExampleS2.Refrences(3,:), 'k--', 'LineWidth', 2);
plot(time, SaveExampleS2.Observer(3,:), 'b--', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Yaw (degree)');
title('Yaw Response for Scenario 2');


%% Save Results
save(fullfile(outDir, 'SAMOPSO_FVML_Results.mat'), ...
    'Pareto_SAMOPSO', ...
    'ParetoPositions_SAMOPSO', ...
    'SAMOPSO_Params', ...
    'RunLog', ...
    'time_SAMOPSO', ...
    'initialStates', ...
    'GoolPoints', ...
    'TimeSimulation', ...
    'VarMin', ...
    'VarMax', ...
    'Refrences', ...
    'param_names');

fprintf('\n====== RESULTS SAVED ======\n');
fprintf('File: %s\n', fullfile(outDir, 'SAMOPSO_FVML_Results.mat'));
%% ========================================================================

%% ========================================================================
%  SA-MOPSO-FVML OPTIMIZATION FUNCTION
%  ========================================================================
function [ParetoFront, ParetoPositions, RunLog] = SAMOPSO_FVML_Optimization(...
    initialStates, GoolPoints, TimeSimulation, ...
    nVar, VarMin, VarMax, Params, nParetoPoints)
%SAMOPSO_FVML_OPTIMIZATION
% Adaptive SA-MOPSO-FVML for marine DP controller tuning.
%
% This engineering version follows the final benchmark algorithm:
%   1) Adaptive fractional velocity memory
%   2) Bounded Mittag-Leffler-uniform tempered mixture
%   3) Hybrid grid/crowding archive leader selection
%   4) Constriction on the complete velocity vector
%   5) Stagnation-triggered Mittag-Leffler mutation

    %% -----------------------------
    % Parameters
    % -----------------------------
    MaxIt = getParam(Params, 'MaxIt', 20);
    nPop  = getParam(Params, 'nPop', 50);

    alpha   = getParam(Params, 'alpha', 0.7);
    a_param = getParam(Params, 'a_param', 0.5);
    b_param = getParam(Params, 'b_param', 10);

    c1 = getParam(Params, 'c1', 1.5);
    c2 = getParam(Params, 'c2', 1.5);

    w_max = getParam(Params, 'w_max', 0.9);
    w_min = getParam(Params, 'w_min', 0.4);

    ml_alpha    = getParam(Params, 'ml_alpha', 0.8);
    ml_scale    = getParam(Params, 'ml_scale', 1.0);
    ml_rmax_min = getParam(Params, 'ml_rmax_min', 1.2);
    ml_rmax_max = getParam(Params, 'ml_rmax_max', 2.2);

    pML_min = getParam(Params, 'pML_min', 0.20);
    pML_max = getParam(Params, 'pML_max', 0.75);

    pMem_min = getParam(Params, 'pMem_min', 0.20);
    pMem_max = getParam(Params, 'pMem_max', 0.85);
    memoryDiversityTarget = getParam(Params, 'memoryDiversityTarget', 0.30);

    pGrid_min = getParam(Params, 'pGrid_min', 0.30);
    pGrid_max = getParam(Params, 'pGrid_max', 0.75);
    gridDiversityTarget = getParam(Params, 'gridDiversityTarget', 0.35);

    nGrid     = getParam(Params, 'nGrid', 10);
    leaderBeta = getParam(Params, 'leaderBeta', 1.5);

    chi_v     = getParam(Params, 'chi_v', 0.88);
    vmaxRatio = getParam(Params, 'vmaxRatio', 0.40);

    stallLimit  = getParam(Params, 'stallLimit', 10);
    mutationRate = getParam(Params, 'mutationRate', 0.08);
    sigmaMax = getParam(Params, 'sigmaMax', 0.06);
    sigmaMin = getParam(Params, 'sigmaMin', 0.01);

    resetSimulationState = getParam(Params, 'ResetSimulationState', false);

    VarMin = VarMin(:)';
    VarMax = VarMax(:)';
    rangeVar = VarMax - VarMin;

    archiveSize = nParetoPoints;

    %% -----------------------------
    % Particle structure
    % -----------------------------
    emptyParticle.Position = [];
    emptyParticle.Velocity_hist = [];
    emptyParticle.Cost = [];
    emptyParticle.Best.Position = [];
    emptyParticle.Best.Cost = [];
    emptyParticle.IsDominated = false;

    pop = repmat(emptyParticle, nPop, 1);

    %% -----------------------------
    % Initialization
    % -----------------------------
    for i = 1:nPop
        pop(i).Position = VarMin + rangeVar .* rand(1, nVar);
        pop(i).Velocity_hist = zeros(4, nVar);
    end

    % Optional explicit initial guesses for reproducibility
    if isfield(Params, 'InitialGuesses') && ~isempty(Params.InitialGuesses)
        G = Params.InitialGuesses;
        nSeed = min(size(G, 1), nPop);

        for k = 1:nSeed
            pop(k).Position = max(min(G(k, :), VarMax), VarMin);
        end
    end

    % Evaluate initial population
    for i = 1:nPop
        pop(i).Cost = evaluateDPCost(initialStates, GoolPoints, ...
            TimeSimulation, pop(i).Position, true);

        pop(i).Best.Position = pop(i).Position;
        pop(i).Best.Cost = pop(i).Cost;
    end

    rep = updateRepository([], pop, archiveSize);

    stagnationCounter = 0;
    previousArchiveCost = getArchiveCostMatrix(rep);

    %% -----------------------------
    % Logging
    % -----------------------------
    RunLog.E = zeros(MaxIt, 1);
    RunLog.pMem = zeros(MaxIt, 1);
    RunLog.pML = zeros(MaxIt, 1);
    RunLog.pGrid = zeros(MaxIt, 1);
    RunLog.rMaxML = zeros(MaxIt, 1);
    RunLog.ArchiveSize = zeros(MaxIt, 1);

    %% -----------------------------
    % Main loop
    % -----------------------------
    for it = 1:MaxIt

        allCosts = vertcat(pop.Cost);

        % Multi-objective diversity in normalized objective space
        E_t = computeObjectiveDiversity(allCosts);

        iterFactor = 1 - it / MaxIt;

        lowDiversityForMemory = max(0, ...
            (memoryDiversityTarget - E_t) / (memoryDiversityTarget + eps));

        lowDiversityForGrid = max(0, ...
            (gridDiversityTarget - E_t) / (gridDiversityTarget + eps));

        stagnationFactor = min(1, stagnationCounter / max(1, stallLimit));

        % Adaptive memory activation
        pMem = pMem_min + (pMem_max - pMem_min) * ...
            max([0.5 * iterFactor, lowDiversityForMemory, stagnationFactor]);
        pMem = min(max(pMem, pMem_min), pMem_max);

        % Adaptive ML contribution
        pML = pML_min + (pML_max - pML_min) * ...
            max([iterFactor, 1 - E_t, stagnationFactor]);
        pML = min(max(pML, pML_min), pML_max);

        % Adaptive ML upper bound
        ml_rmax_t = ml_rmax_min + (ml_rmax_max - ml_rmax_min) * ...
            max([iterFactor, 1 - E_t, stagnationFactor]);
        ml_rmax_t = min(max(ml_rmax_t, ml_rmax_min), ml_rmax_max);

        % Adaptive grid leader probability
        pGrid = pGrid_min + (pGrid_max - pGrid_min) * ...
            max(lowDiversityForGrid, stagnationFactor);
        pGrid = min(max(pGrid, pGrid_min), pGrid_max);

        % Fractional memory coefficients
        [w1, w2, w3, w4] = computeRawMemoryWeights(alpha, a_param, b_param, E_t);

        % Classical fallback inertia
        w_classic = w_max - (w_max - w_min) * (it / MaxIt);

        for i = 1:nPop

            % Hybrid leader selection
            if rand < pGrid
                leader = selectLeaderGrid(rep, nGrid, leaderBeta);
            else
                leader = selectLeaderCrowding(rep);
            end

            % Bounded Mittag-Leffler-uniform tempered mixture
            u1 = rand(1, nVar);
            u2 = rand(1, nVar);

            ml1 = mittagLefflerRand(ml_alpha, ml_scale, [1, nVar], ...
                'QuantileLevel', 0.95, ...
                'RMax', ml_rmax_t, ...
                'UnitInterval', false);

            ml2 = mittagLefflerRand(ml_alpha, ml_scale, [1, nVar], ...
                'QuantileLevel', 0.95, ...
                'RMax', ml_rmax_t, ...
                'UnitInterval', false);

            r1 = (1 - pML) .* u1 + pML .* ml1;
            r2 = (1 - pML) .* u2 + pML .* ml2;

            % Adaptive memory term
            if rand < pMem
                memoryTerm = ...
                    w1 * pop(i).Velocity_hist(1, :) + ...
                    w2 * pop(i).Velocity_hist(2, :) + ...
                    w3 * pop(i).Velocity_hist(3, :) + ...
                    w4 * pop(i).Velocity_hist(4, :);
            else
                memoryTerm = w_classic * pop(i).Velocity_hist(1, :);
            end

            % Velocity update
            v_new = ...
                memoryTerm + ...
                c1 .* r1 .* (pop(i).Best.Position - pop(i).Position) + ...
                c2 .* r2 .* (leader.Position - pop(i).Position);

            % Constriction on complete velocity vector
            v_new = chi_v * v_new;

            % Velocity clamping
            vmax = vmaxRatio * rangeVar;
            v_new = max(min(v_new, vmax), -vmax);

            % Update velocity history
            pop(i).Velocity_hist(4, :) = pop(i).Velocity_hist(3, :);
            pop(i).Velocity_hist(3, :) = pop(i).Velocity_hist(2, :);
            pop(i).Velocity_hist(2, :) = pop(i).Velocity_hist(1, :);
            pop(i).Velocity_hist(1, :) = v_new;

            % Position update and bound handling
            pop(i).Position = pop(i).Position + v_new;
            pop(i).Position = max(min(pop(i).Position, VarMax), VarMin);

            % Evaluate
            pop(i).Cost = evaluateDPCost(initialStates, GoolPoints, ...
                TimeSimulation, pop(i).Position, true);

            % Update personal best
            [pop(i).Best.Position, pop(i).Best.Cost] = updatePersonalBestMOO( ...
                pop(i).Position, pop(i).Cost, ...
                pop(i).Best.Position, pop(i).Best.Cost, ...
                getArchiveCostMatrix(rep));
        end

        % Update archive
        rep = updateRepository(rep, pop, archiveSize);

        currentArchiveCost = getArchiveCostMatrix(rep);

        if hasArchiveChanged(previousArchiveCost, currentArchiveCost)
            stagnationCounter = 0;
            previousArchiveCost = currentArchiveCost;
        else
            stagnationCounter = stagnationCounter + 1;
        end

        % Stagnation-triggered ML mutation
        if stagnationCounter >= stallLimit

            pop = applyMittagLefflerMutationDP( ...
                pop, rep, ...
                initialStates, GoolPoints, TimeSimulation, ...
                VarMin, VarMax, ...
                ml_alpha, ml_scale, ml_rmax_t, ...
                mutationRate, sigmaMax, sigmaMin, it, MaxIt);

            rep = updateRepository(rep, pop, archiveSize);
            previousArchiveCost = getArchiveCostMatrix(rep);
            stagnationCounter = 0;
        end

        if resetSimulationState
            clearDPShipSimulationState();
        end

        RunLog.E(it) = E_t;
        RunLog.pMem(it) = pMem;
        RunLog.pML(it) = pML;
        RunLog.pGrid(it) = pGrid;
        RunLog.rMaxML(it) = ml_rmax_t;
        RunLog.ArchiveSize(it) = numel(rep);

        fprintf(['SA-MOPSO-FVML Iteration %d/%d | Archive: %d | ', ...
                 'E=%.4f | pMem=%.2f | pML=%.2f | pGrid=%.2f\n'], ...
            it, MaxIt, numel(rep), E_t, pMem, pML, pGrid);
    end

    %% -----------------------------
    % Output
    % -----------------------------
    ParetoFront.Cost = getArchiveCostMatrix(rep);
    ParetoFront.Position = reshape([rep.Position], nVar, [])';

    ParetoPositions = cell(numel(rep), 1);

    for i = 1:numel(rep)
        [~, ~, SavePos] = CostFunctionDPShip(initialStates, GoolPoints, ...
            TimeSimulation, rep(i).Position, true);
        ParetoPositions{i} = SavePos;
    end
end
%% ========================================================================
%% ========================================================================
%  HELPER FUNCTIONS
%  ========================================================================

function val = getParam(S, name, defaultVal)
    if isfield(S, name) && ~isempty(S.(name))
        val = S.(name);
    else
        val = defaultVal;
    end
end

function cost = evaluateDPCost(initialStates, GoolPoints, TimeSimulation, position, flag)
%EVALUATEDPCOST
% Evaluates the marine DP objective vector.
% Objectives are mean absolute tracking errors in surge, sway, and yaw.

    try
        [z, ~, ~] = CostFunctionDPShip(initialStates, GoolPoints, ...
            TimeSimulation, position, flag);

        cost = [mean(abs(z(1, :))), mean(abs(z(2, :))), mean(abs(z(3, :)))];

        if any(~isfinite(cost))
            cost = [inf, inf, inf];
        end

    catch ME
        warning('CostFunctionDPShip failed: %s', ME.message);
        cost = [inf, inf, inf];
    end
end

function dom = Dominates(x, y)
    dom = all(x <= y) && any(x < y);
end

function E_t = computeObjectiveDiversity(F)
%COMPUTEOBJECTIVEDIVERSITY
% Normalized objective-space diversity based on distance from centroid.

    if isempty(F) || size(F, 1) < 2
        E_t = 0;
        return;
    end

    fMin = min(F, [], 1);
    fMax = max(F, [], 1);

    Fnorm = (F - fMin) ./ (fMax - fMin + eps);

    center = mean(Fnorm, 1);
    distances = sqrt(sum((Fnorm - center).^2, 2));

    E_t = mean(distances);
    E_t = max(0, min(1, E_t));
end

function [w1, w2, w3, w4] = computeRawMemoryWeights(alpha, a_param, b_param, E_t)
%COMPUTERAWMEMORYWEIGHTS
% Raw fractional-inspired memory coefficients.

    sigmoid_term = a_param / (1 + exp(b_param * E_t));

    w1 = alpha - sigmoid_term;
    w2 = 0.5 * alpha;
    w3 = alpha * (1 - alpha) / 6;
    w4 = alpha * (1 - alpha) * (2 - alpha) / 24;
end

function [pbest, pbestCost] = updatePersonalBestMOO(xNew, fNew, pbestOld, fOld, archiveF)
%UPDATEPERSONALBESTMOO
% Pareto dominance update with normalized scalar secondary criterion.

    if Dominates(fNew, fOld)
        pbest = xNew;
        pbestCost = fNew;
        return;
    end

    if Dominates(fOld, fNew)
        pbest = pbestOld;
        pbestCost = fOld;
        return;
    end

    if nargin < 5 || isempty(archiveF)
        refF = [fNew; fOld];
    else
        refF = [archiveF; fNew; fOld];
    end

    fMin = min(refF, [], 1);
    fMax = max(refF, [], 1);

    fNewN = (fNew - fMin) ./ (fMax - fMin + eps);
    fOldN = (fOld - fMin) ./ (fMax - fMin + eps);

    scoreNew = sum(fNewN);
    scoreOld = sum(fOldN);

    if scoreNew < scoreOld || rand < 0.10
        pbest = xNew;
        pbestCost = fNew;
    else
        pbest = pbestOld;
        pbestCost = fOld;
    end
end

function rep = updateRepository(rep, pop, archiveSize)
%UPDATEREPOSITORY
% Updates external archive using nondominated filtering and crowding pruning.

    if isempty(rep)
        combined = pop;
    else
        combined = [rep; pop];
    end

    combined = determineDomination(combined);
    rep = combined([combined.IsDominated] == false);

    if numel(rep) > archiveSize
        rep = selectBestNPareto(rep, archiveSize);
    end
end

function pop = determineDomination(pop)
    nPop = numel(pop);

    for i = 1:nPop
        pop(i).IsDominated = false;
    end

    for i = 1:nPop
        for j = 1:nPop
            if i ~= j && Dominates(pop(j).Cost, pop(i).Cost)
                pop(i).IsDominated = true;
                break;
            end
        end
    end
end

function F = getArchiveCostMatrix(rep)
    if isempty(rep)
        F = [];
    else
        nObj = numel(rep(1).Cost);
        F = reshape([rep.Cost], nObj, [])';
    end
end

function cd = crowdingDistanceFromCosts(F)
    [N, M] = size(F);
    cd = zeros(N, 1);

    if N <= 2
        cd(:) = inf;
        return;
    end

    for m = 1:M
        [sortedF, idx] = sort(F(:, m));

        cd(idx(1)) = inf;
        cd(idx(end)) = inf;

        denom = sortedF(end) - sortedF(1);

        if abs(denom) < eps
            continue;
        end

        for k = 2:N-1
            cd(idx(k)) = cd(idx(k)) + ...
                (sortedF(k+1) - sortedF(k-1)) / denom;
        end
    end
end

function leader = selectLeaderCrowding(rep)
%SELECTLEADERCROWDING
% Archive leader selection based on crowding-distance roulette.

    if isempty(rep)
        error('Repository is empty in selectLeaderCrowding.');
    end

    if numel(rep) == 1
        leader = rep(1);
        return;
    end

    F = getArchiveCostMatrix(rep);
    cd = crowdingDistanceFromCosts(F);

    if all(isinf(cd))
        leader = rep(randi(numel(rep)));
        return;
    end

    finiteCD = cd(isfinite(cd));

    if isempty(finiteCD)
        leader = rep(randi(numel(rep)));
        return;
    end

    cd(isinf(cd)) = 10 * max(finiteCD);

    if sum(cd) <= 0 || any(~isfinite(cd))
        idx = randi(numel(rep));
    else
        prob = cd ./ sum(cd);
        idx = rouletteWheelSelection(prob);
    end

    leader = rep(idx);
end

function leader = selectLeaderGrid(rep, nGrid, beta)
%SELECTLEADERGRID
% Selects leader from sparse grid cells in normalized objective space.

    if isempty(rep)
        error('Repository is empty in selectLeaderGrid.');
    end

    if numel(rep) == 1
        leader = rep(1);
        return;
    end

    F = getArchiveCostMatrix(rep);
    N = size(F, 1);
    M = size(F, 2);

    fMin = min(F, [], 1);
    fMax = max(F, [], 1);

    Fnorm = (F - fMin) ./ (fMax - fMin + eps);

    gridIndex = floor(Fnorm * nGrid) + 1;
    gridIndex = max(min(gridIndex, nGrid), 1);

    multipliers = nGrid .^ (0:M-1);
    cellID = 1 + sum((gridIndex - 1) .* multipliers, 2);

    uniqueCells = unique(cellID);
    nCells = numel(uniqueCells);
    cellCounts = zeros(nCells, 1);

    for c = 1:nCells
        cellCounts(c) = sum(cellID == uniqueCells(c));
    end

    probCells = 1 ./ (cellCounts .^ beta);
    probCells = probCells ./ sum(probCells);

    selectedCell = uniqueCells(rouletteWheelSelection(probCells));
    members = find(cellID == selectedCell);

    idx = members(randi(numel(members)));
    leader = rep(idx);
end

function idx = rouletteWheelSelection(prob)
    prob = prob(:);

    if isempty(prob) || sum(prob) <= 0 || any(~isfinite(prob))
        idx = randi(numel(prob));
        return;
    end

    prob = prob ./ sum(prob);
    r = rand;
    cp = cumsum(prob);

    idx = find(cp >= r, 1, 'first');

    if isempty(idx)
        idx = numel(prob);
    end
end

function selected = selectBestNPareto(rep, n)
%SELECTBESTNPARETO
% Prunes repository by preserving highest crowding-distance solutions.

    F = getArchiveCostMatrix(rep);
    cd = crowdingDistanceFromCosts(F);

    [~, order] = sort(cd, 'descend');
    selected = rep(order(1:min(n, numel(rep))));
end

function changed = hasArchiveChanged(Fold, Fnew)
    if isempty(Fold) && isempty(Fnew)
        changed = false;
        return;
    end

    if isempty(Fold) || isempty(Fnew)
        changed = true;
        return;
    end

    if size(Fold, 1) ~= size(Fnew, 1) || size(Fold, 2) ~= size(Fnew, 2)
        changed = true;
        return;
    end

    Fold = sortrows(Fold);
    Fnew = sortrows(Fnew);

    changed = max(abs(Fold(:) - Fnew(:))) > 1e-10;
end

function pop = applyMittagLefflerMutationDP(pop, rep, ...
    initialStates, GoolPoints, TimeSimulation, ...
    VarMin, VarMax, ml_alpha, ml_scale, ml_rmax, ...
    mutationRate, sigmaMax, sigmaMin, it, MaxIt)
%APPLYMITTAGLEFFLERMUTATIONDP
% Stagnation-triggered bounded ML position mutation.

    nPop = numel(pop);
    nVar = numel(pop(1).Position);

    nMut = max(1, ceil(mutationRate * nPop));
    selected = randperm(nPop, nMut);

    rangeVar = VarMax - VarMin;
    sigma = sigmaMin + (sigmaMax - sigmaMin) * (1 - it / MaxIt);

    archiveF = getArchiveCostMatrix(rep);

    for k = 1:nMut
        idx = selected(k);

        direction = 2 * rand(1, nVar) - 1;

        mlStep = mittagLefflerRand(ml_alpha, ml_scale, [1, nVar], ...
            'QuantileLevel', 0.95, ...
            'RMax', ml_rmax, ...
            'UnitInterval', false);

        xCandidate = pop(idx).Position + sigma .* rangeVar .* mlStep .* direction;
        xCandidate = max(min(xCandidate, VarMax), VarMin);

        fCandidate = evaluateDPCost(initialStates, GoolPoints, ...
            TimeSimulation, xCandidate, true);

        if Dominates(fCandidate, pop(idx).Best.Cost) || ...
           (~Dominates(pop(idx).Best.Cost, fCandidate) && rand < 0.20)

            pop(idx).Position = xCandidate;
            pop(idx).Cost = fCandidate;

            % Reset velocity history after mutation
            pop(idx).Velocity_hist(:, :) = 0;

            [pop(idx).Best.Position, pop(idx).Best.Cost] = updatePersonalBestMOO( ...
                pop(idx).Position, pop(idx).Cost, ...
                pop(idx).Best.Position, pop(idx).Best.Cost, ...
                archiveF);
        end
    end
end

function rStar = mittagLefflerRand(alpha, scale, sz, varargin)
%MITTAGLEFFLERRAND
% Bounded positive Mittag-Leffler random coefficients.
%
% This sampler avoids Statistics Toolbox dependency and is suitable for
% GitHub release.

    p = inputParser;
    addParameter(p, 'QuantileLevel', 0.95, @(x) isnumeric(x) && isscalar(x) && x > 0 && x < 1);
    addParameter(p, 'RMax', 2.0, @(x) isnumeric(x) && isscalar(x) && x > 0);
    addParameter(p, 'UnitInterval', false, @(x) islogical(x) || isnumeric(x));
    parse(p, varargin{:});

    qLevel = p.Results.QuantileLevel;
    rMax = p.Results.RMax;
    unitInterval = logical(p.Results.UnitInterval);

    if alpha <= 0 || alpha > 1
        error('Mittag-Leffler alpha must satisfy 0 < alpha <= 1.');
    end

    if scale <= 0
        error('Mittag-Leffler scale must be positive.');
    end

    n = prod(sz);

    U = max(rand(n, 1), realmin);
    V = min(max(rand(n, 1), eps), 1 - eps);

    if abs(alpha - 1) < 1e-12
        X = -log(U);
    else
        theta = pi * alpha;
        A = sin(theta) ./ tan(theta * V) - cos(theta);
        A = max(A, realmin);
        X = -log(U) .* (A .^ (1 / alpha));
    end

    qVal = localQuantile(X, qLevel);

    if qVal <= 0 || ~isfinite(qVal)
        qVal = max(median(X), realmin);
    end

    rStar = scale .* (X ./ qVal);
    rStar = min(rStar, rMax);

    if unitInterval
        rStar = rStar ./ rMax;
    end

    rStar = reshape(rStar, sz);
end

function q = localQuantile(x, p)
    x = sort(x(:));
    n = numel(x);

    if n == 1
        q = x;
        return;
    end

    pos = 1 + (n - 1) * p;
    lo = floor(pos);
    hi = ceil(pos);

    if lo == hi
        q = x(lo);
    else
        q = x(lo) + (pos - lo) * (x(hi) - x(lo));
    end
end

function clearDPShipSimulationState()
%CLEARDPSHIPSIMULATIONSTATE
% Optional compatibility helper for legacy CostFunctionDPShip implementations.
% Prefer avoiding base-workspace state dependencies in GitHub releases.

    evalin('base', ...
        'clear L Data cont state_int_Obs state_int_forc state_int_controller state_int_vessel');
end

%% ========================================================================
%  PLOTTING FUNCTION
%  ========================================================================
function PlotResults_SAMOPSO(Pareto_SAMOPSO, ParetoPos_SAMOPSO)
    
    % 1. 3D Pareto Front
    figure('Position', [100 100 1200 400]);
    
    subplot(1,3,1)
    scatter3(Pareto_SAMOPSO.Cost(:,1), Pareto_SAMOPSO.Cost(:,2), Pareto_SAMOPSO.Cost(:,3), ...
        50, 'filled', 'MarkerFaceColor', 'g')
    xlabel('Cost 1 (Surge Error)')
    ylabel('Cost 2 (Sway Error)')
    zlabel('Cost 3 (Yaw Error)')
    title('SA-MOPSO-FVML Pareto Front')
    grid on
    view(45, 30)
    
    % 2. 2D Projections of Pareto Front
    subplot(1,3,2)
    plot(Pareto_SAMOPSO.Cost(:,1), Pareto_SAMOPSO.Cost(:,2), 'go', 'MarkerFaceColor', 'g')
    xlabel('Cost 1 (Surge Error)')
    ylabel('Cost 2 (Sway Error)')
    title('Pareto Front: Cost 1 vs Cost 2')
    grid on
    
    subplot(1,3,3)
    plot(Pareto_SAMOPSO.Cost(:,1), Pareto_SAMOPSO.Cost(:,3), 'go', 'MarkerFaceColor', 'g')
    xlabel('Cost 1 (Surge Error)')
    ylabel('Cost 3 (Yaw Error)')
    title('Pareto Front: Cost 1 vs Cost 3')
    grid on
    
    % % 3. Sample trajectories from Pareto solutions
    % figure('Position', [100 100 1200 800]);
    % 
    % % Select 3 representative solutions from SA-MOPSO-FVML
    % nSamples = min(3, length(ParetoPos_SAMOPSO));
    % indices = round(linspace(1, length(ParetoPos_SAMOPSO), nSamples));
    % 
    % for i = 1:nSamples
    %     subplot(2, nSamples, i)
    %     SavePos = ParetoPos_SAMOPSO{indices(i)};
    %     plot(SavePos.Observer(1,:), SavePos.Observer(2,:), 'b-', 'LineWidth', 1.5)
    %     hold on
    %     plot(SavePos.Refrences(1,:), SavePos.Refrences(2,:), 'r--', 'LineWidth', 1.5)
    %     xlabel('X Position (m)')
    %     ylabel('Y Position (m)')
    %     title(sprintf('SA-MOPSO-FVML Solution %d Path', i))
    %     legend('Observed', 'Reference')
    %     grid on
    %     axis equal
    % end
    %% =======================
%  ALL PARETO TRAJECTORIES (X-Y)
% =======================
figure('Position', [100 100 900 700]);
hold on; grid on; axis equal;

nPareto = length(ParetoPos_SAMOPSO);
colors = lines(nPareto);

for i = 1:nPareto
    SavePos = ParetoPos_SAMOPSO{i};
    plot(SavePos.Observer(1,:), SavePos.Observer(2,:), ...
        'Color', colors(i,:), 'LineWidth', 1.2);
end

% Plot reference only once
plot(SavePos.Refrences(1,:), SavePos.Refrences(2,:), ...
    'k--', 'LineWidth', 2);

xlabel('X Position (m)');
ylabel('Y Position (m)');
title('All Pareto Solutions: Vessel Trajectories');
legend(['Pareto Solutions', 'Reference']);

    % % Time histories
    % for i = 1:nSamples
    %     SavePos = ParetoPos_SAMOPSO{indices(i)};
    % 
    %     % Surge
    %     subplot(2, nSamples, nSamples + i)
    %     time = linspace(0, size(SavePos.Observer,2)*0.1, size(SavePos.Observer,2));
    %     plot(time, SavePos.Observer(1,:), 'b-', 'LineWidth', 1.5)
    %     hold on
    %     plot(time, SavePos.Refrences(1,:), 'r--', 'LineWidth', 1.5)
    %     xlabel('Time (s)')
    %     ylabel('Surge (m)')
    %     title(sprintf('Solution %d - Surge', i))
    %     legend('Observed', 'Reference')
    %     grid on
    % end
    % 
    % sgtitle('SA-MOPSO-FVML: Sample Trajectories from Pareto Solutions')
    % 
    % % 4. Yaw trajectories
    % figure('Position', [100 100 1200 400]);
    % for i = 1:nSamples
    %     SavePos = ParetoPos_SAMOPSO{indices(i)};
    %     time = linspace(0, size(SavePos.Observer,2)*0.1, size(SavePos.Observer,2));
    % 
    %     subplot(1, nSamples, i)
    %     plot(time, SavePos.Observer(3,:), 'b-', 'LineWidth', 1.5)
    %     hold on
    %     plot(time, SavePos.Refrences(3,:), 'r--', 'LineWidth', 1.5)
    %     xlabel('Time (s)')
    %     ylabel('Yaw (rad)')
    %     title(sprintf('Solution %d - Yaw', i))
    %     legend('Observed', 'Reference')
    %     grid on
    % end
    % sgtitle('SA-MOPSO-FVML: Yaw Trajectories')
    %% =======================
    %% =======================
%  SURGE RESPONSE - ALL PARETO
% =======================
figure('Position', [100 100 900 400]);
hold on; grid on;

for i = 1:nPareto
    SavePos = ParetoPos_SAMOPSO{i};
    time = linspace(0, size(SavePos.Observer,2)*0.1, size(SavePos.Observer,2));
    plot(time, SavePos.Observer(1,:), 'Color', colors(i,:), 'LineWidth', 1);
end

plot(time, SavePos.Refrences(1,:), 'k--', 'LineWidth', 2);

xlabel('Time (s)');
ylabel('Surge (m)');
title('Surge Response for All Pareto Solutions');

%  SWAY RESPONSE - ALL PARETO
% =======================
figure('Position', [100 100 900 400]);
hold on; grid on;

for i = 1:nPareto
    SavePos = ParetoPos_SAMOPSO{i};
    time = linspace(0, size(SavePos.Observer,2)*0.1, size(SavePos.Observer,2));
    plot(time, SavePos.Observer(2,:), 'Color', colors(i,:), 'LineWidth', 1);
end

plot(time, SavePos.Refrences(2,:), 'k--', 'LineWidth', 2);

xlabel('Time (s)');
ylabel('Sway (m)');
title('Sway Response for All Pareto Solutions');
%% =======================
%  YAW RESPONSE - ALL PARETO
% =======================
figure('Position', [100 100 900 400]);
hold on; grid on;

for i = 1:nPareto
    SavePos = ParetoPos_SAMOPSO{i};
    time = linspace(0, size(SavePos.Observer,2)*0.1, size(SavePos.Observer,2));
    plot(time, SavePos.Observer(3,:), 'Color', colors(i,:), 'LineWidth', 1);
end

plot(time, SavePos.Refrences(3,:), 'k--', 'LineWidth', 2);

xlabel('Time (s)');
ylabel('Yaw (degree)');
title('Yaw Response for All Pareto Solutions');

end
function T = makeDPSelectedSolutionTable(position, z, SavePos, Ts)
%MAKEDPSELECTEDSOLUTIONTABLE
% Creates a MATLAB table corresponding to the manuscript table:
% Kp, Ki, Kd, Ka, IAE, maximum error, and control effort.
%
% Variable layout:
%   position(1:3)   = Kp for surge, sway, yaw
%   position(4:6)   = Kd for surge, sway, yaw
%   position(7:9)   = Ka for surge, sway, yaw
%   position(10:12) = Ki for surge, sway, yaw

    if nargin < 4 || isempty(Ts)
        Ts = 0.1;
    end

    % Controller gains
    Kp = position(1:3);
    Kd = position(4:6);
    Ka = position(7:9);
    Ki = position(10:12);

    % Tracking error extraction
    if isstruct(SavePos) && isfield(SavePos, 'Observer') && isfield(SavePos, 'Refrences')
        e = SavePos.Refrences(1:3, :) - SavePos.Observer(1:3, :);
    else
        % Fallback: use z returned by CostFunctionDPShip
        e = z(1:3, :);
    end

    nSamples = size(e, 2);
    time = (0:nSamples-1) * Ts;

    % Performance indices
    IAE = trapz(time, abs(e), 2).';
    MaxError = max(abs(e), [], 2).';

    % Control effort extraction
    U = extractControlSignalFromSavePos(SavePos);

    if isempty(U)
        ControlEffort = [NaN, NaN, NaN];
        warning(['Control input was not found in SavePos. ', ...
                 'Control effort is reported as NaN. ', ...
                 'Add the applied control/force signal to SavePos if needed.']);
    else
        if size(U, 1) ~= 3 && size(U, 2) == 3
            U = U.';
        end

        if size(U, 1) ~= 3
            ControlEffort = [NaN, NaN, NaN];
            warning('Detected control signal does not have 3 channels. Control effort is reported as NaN.');
        else
            nU = size(U, 2);
            timeU = (0:nU-1) * Ts;
            ControlEffort = trapz(timeU, U.^2, 2).';
        end
    end

    Quantity = { ...
        'Kp'; ...
        'Ki'; ...
        'Kd'; ...
        'Ka'; ...
        'IAE'; ...
        'Maximum error'; ...
        'Control effort'};

    Surge = [Kp(1); Ki(1); Kd(1); Ka(1); IAE(1); MaxError(1); ControlEffort(1)];
    Sway  = [Kp(2); Ki(2); Kd(2); Ka(2); IAE(2); MaxError(2); ControlEffort(2)];
    Yaw   = [Kp(3); Ki(3); Kd(3); Ka(3); IAE(3); MaxError(3); ControlEffort(3)];

    T = table(Quantity, Surge, Sway, Yaw);
end
function U = extractControlSignalFromSavePos(SavePos)
%EXTRACTCONTROLSIGNALFROMSAVEPOS
% Tries to find a 3-channel control/force input signal inside SavePos.
% If your CostFunctionDPShip stores the control signal under another field
% name, add that field name to candidateFields.

    U = [];

    if ~isstruct(SavePos)
        return;
    end

    candidateFields = { ...
        'Control', ...
        'control', ...
        'ControlInput', ...
        'controlInput', ...
        'U', ...
        'u', ...
        'Tau', ...
        'tau', ...
        'Force', ...
        'force', ...
        'Forces', ...
        'forces', ...
        'Input', ...
        'input'};

    for k = 1:numel(candidateFields)
        fieldName = candidateFields{k};

        if isfield(SavePos, fieldName)
            candidate = SavePos.(fieldName);

            if isnumeric(candidate) && ismatrix(candidate)
                if size(candidate, 1) == 3 || size(candidate, 2) == 3
                    U = candidate;
                    return;
                end
            end
        end
    end
end

function T = makeDPScenarioDiagnosticsTable( ...
    SaveS1, SaveS2, initialS1, goalS1, initialS2, goalS2, Ts)

    T1 = computeOneScenarioDiagnostics( ...
        SaveS1, initialS1, goalS1, Ts, 'Scenario 1');

    T2 = computeOneScenarioDiagnostics( ...
        SaveS2, initialS2, goalS2, Ts, 'Scenario 2');

    T = [T1; T2];
end


function T = computeOneScenarioDiagnostics(SavePos, initialState, goalPoint, Ts, scenarioName)

    if nargin < 4 || isempty(Ts)
        Ts = 0.1;
    end

    if ~isfield(SavePos, 'Observer') || ~isfield(SavePos, 'Refrences')
        error('SavePos must contain Observer and Refrences fields.');
    end

    y = SavePos.Observer(1:3, :);
    r = SavePos.Refrences(1:3, :);

    nSamples = size(y, 2);
    time = (0:nSamples-1) * Ts;

    e = r - y;

    channels = {'Surge'; 'Sway'; 'Yaw'};

    PeakTrackingError = zeros(3,1);
    RMSTrackingError = zeros(3,1);
    Overshoot = zeros(3,1);
    OvershootPercent = zeros(3,1);
    SettlingTime_s = zeros(3,1);
    ControlEnergyIndex = zeros(3,1);
    ActuatorVariationIndex = zeros(3,1);

    U = extractControlSignalFromSavePos(SavePos);

    if isempty(U)
        U = NaN(3, nSamples);
        warning(['Control input was not found in SavePos for ', ...
                 char(scenarioName), ...
                 '. Control-energy and actuator-variation indices will be NaN.']);
    else
        if size(U,1) ~= 3 && size(U,2) == 3
            U = U.';
        end

        if size(U,1) ~= 3
            U = NaN(3, nSamples);
            warning(['Detected control signal does not have 3 channels for ', ...
                     char(scenarioName), ...
                     '. Control-energy and actuator-variation indices will be NaN.']);
        end
    end

    for m = 1:3

        em = e(m, :);
        ym = y(m, :);

        PeakTrackingError(m) = max(abs(em));

        RMSTrackingError(m) = sqrt( ...
            trapz(time, em.^2) / max(eps, time(end)-time(1)));

        delta = goalPoint(m) - initialState(m);

        if abs(delta) < eps
            tol = 0.02 * max(1, abs(goalPoint(m)));
        else
            tol = 0.02 * abs(delta);
        end

        inside = abs(em) <= tol;

        idxSettle = NaN;
        for k = 1:nSamples
            if all(inside(k:end))
                idxSettle = k;
                break;
            end
        end

        if isnan(idxSettle)
            SettlingTime_s(m) = NaN;
        else
            SettlingTime_s(m) = time(idxSettle);
        end

        if abs(delta) < eps
            Overshoot(m) = 0;
            OvershootPercent(m) = 0;
        else
            sgn = sign(delta);
            directionalDeviation = sgn * (ym - goalPoint(m));
            Overshoot(m) = max(0, max(directionalDeviation));
            OvershootPercent(m) = 100 * Overshoot(m) / abs(delta);
        end

        if all(isfinite(U(m, :)))
            ControlEnergyIndex(m) = trapz(time, U(m, :).^2);
            ActuatorVariationIndex(m) = sum(abs(diff(U(m, :))));
        else
            ControlEnergyIndex(m) = NaN;
            ActuatorVariationIndex(m) = NaN;
        end
    end

    Scenario = repmat(string(scenarioName), 3, 1);
    Channel = string(channels);

    T = table( ...
        Scenario, ...
        Channel, ...
        PeakTrackingError, ...
        RMSTrackingError, ...
        Overshoot, ...
        OvershootPercent, ...
        SettlingTime_s, ...
        ControlEnergyIndex, ...
        ActuatorVariationIndex);
end