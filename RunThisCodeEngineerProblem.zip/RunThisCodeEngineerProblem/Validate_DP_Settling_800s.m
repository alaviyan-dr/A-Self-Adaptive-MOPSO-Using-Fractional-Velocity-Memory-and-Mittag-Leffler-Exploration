%% Validate_DP_Settling_800s.m
% Independent reviewer-response validation of marine DP settling time.
% No optimizer is rerun; the selected 12 PIDA gains are held fixed.
% Requires CostFunctionDPShip.m and all functions it calls on MATLAB path.
% Tests 2%, 5%, and 10% of the commanded reference change, for both
% the original 400-s window and an extended 800-s simulation.
% A settling-time estimate is called "verified" only if at least 60 s
% of subsequent in-band response is observed up to the end of the run.
%
% IMPORTANT: The implementation uses noisy/stochastic wave/sensor signals.
% Results of a new 400-s run need not exactly match the published values.
% Even with the same RNG seed, funcwave(TimeSimulation,...) may generate
% different early trajectories when TimeSimulation is changed.
%
% Save this file in the folder containing CostFunctionDPShip.m and run:
%   Validate_DP_Settling_800s

clearvars; close all; clc;

%% User settings
Ts = 0.1;                     % Original CostFunctionDPShip integration step
shortHorizon = 400;           % Original reporting window (seconds)
longHorizon = 800;            % Extended verification window (seconds)
postEntryRequirement = 60;    % Minimum observed post-entry margin (seconds)
tolerancePercents = [2 5 10]; % Percent of scenario reference transition
nSeeds = 1;                   % Start with 1; increase to 10 for repeatability
baseSeed = 20261022;

outDir = fullfile(pwd, 'results', 'DP_Settling_Validation');
if ~exist(outDir, 'dir'), mkdir(outDir); end

if exist('CostFunctionDPShip', 'file') ~= 2
    error(['CostFunctionDPShip.m is not on the MATLAB path. ', ...
           'Place this script alongside CostFunctionDPShip.m and its dependencies.']);
end

%% Exactly the same controller must be used in both horizons
% These figures are the manuscript's rounded values and are ONLY a fallback.
% Correct order: [Kp(1:3), Kd(1:3), Ka(1:3), Ki(1:3)].
paperRoundedGains = [ ...
    1200.0000,    6000.0000,   1.444234e6, ...
    -9589.1016, -30000.0000, -1.226424e7, ...
    -281.5114,   -284.3843,  -1882.1453, ...
        5.9638,     16.2989,    211.3767 ];

originalMat = fullfile(pwd, 'results', 'SAMOPSO_FVML_Results.mat');
if exist(originalMat, 'file') == 2
    S = load(originalMat, 'Pareto_SAMOPSO');
    if ~isfield(S, 'Pareto_SAMOPSO') || ...
       ~isfield(S.Pareto_SAMOPSO, 'Cost') || ...
       ~isfield(S.Pareto_SAMOPSO, 'Position')
        error('Original MAT file is missing Pareto_SAMOPSO.Cost or Position.');
    end
    % Replicate the selection rule in the shared main MATLAB program.
    [~, selectedIndex] = min(sqrt(sum(S.Pareto_SAMOPSO.Cost.^2, 2)));
    controllerGains = S.Pareto_SAMOPSO.Position(selectedIndex, :);
    controllerGains = controllerGains(:)';
    if numel(controllerGains) ~= 12
        error('Expected 12 PIDA controller gains in the saved archive.');
    end
    relativeDifference = abs(controllerGains-paperRoundedGains) ./ ...
                         max(1, abs(paperRoundedGains));
    if any(relativeDifference > 0.01)
        error(['The stored Pareto solution differs by over 1%% from the ', ...
               'controller reported in the manuscript. Verify the MAT ', ...
               'file corresponds to the PUBLISHED run before proceeding.']);
    end
    fprintf('Using exact archived controller at index %d from:\n%s\n', ...
            selectedIndex, originalMat);
    gainSource = 'Original saved Pareto archive';
else
    controllerGains = paperRoundedGains;
    gainSource = 'Manuscript rounded gains (original MAT unavailable)';
    warning(['Original Pareto MAT file not found. Using rounded gains ', ...
             'from the manuscript; exact numerical replication is ', ...
             'not guaranteed. Preferred: results/SAMOPSO_FVML_Results.mat']);
end

%% Both reference-transition scenarios exactly as in the main script
scenario(1).name = 'Scenario 1';
scenario(1).initial = [10; 3; 5];
scenario(1).goal = [17; 6; 26];
scenario(2).name = 'Scenario 2';
scenario(2).initial = [0; 1; 0];
scenario(2).goal = [50; -12; 56];
channelNames = {'Surge', 'Sway', 'Yaw'};

rows = struct([]);
prefixRows = struct([]);
allRuns = cell(numel(scenario), nSeeds);

for s = 1:numel(scenario)
    for seedIndex = 1:nSeeds
        seed = baseSeed + 1000*s + seedIndex;
        fprintf('\n== %s, seed %d: 400-s original + 800-s extension ==\n', ...
                scenario(s).name, seed);

        % Rerun original horizon: mainly to reproduce the original analysis.
        rng(seed, 'twister');
        [~, ~, shortSave] = CostFunctionDPShip( ...
            scenario(s).initial, scenario(s).goal, ...
            shortHorizon, controllerGains, true);

        % Rerun extended horizon with the same RNG initialization.
        rng(seed, 'twister');
        [~, ~, longSave] = CostFunctionDPShip( ...
            scenario(s).initial, scenario(s).goal, ...
            longHorizon, controllerGains, true);

        [shortErr, shortTime] = extractError(shortSave, Ts);
        [longErr, longTime] = extractError(longSave, Ts);

        if abs(shortTime(end) - (shortHorizon-Ts)) > Ts/2 || ...
           abs(longTime(end) - (longHorizon-Ts)) > Ts/2
            error('Unexpected sample count. Verify dt=0.1 and time alignment.');
        end
        if any(~isfinite(shortErr(:))) || any(~isfinite(longErr(:)))
            error('Non-finite tracking errors. Check simulation before analysis.');
        end

        % Confirm whether the first 400 s are identical when the duration
        % changes. Matching RNG seeds alone do NOT guarantee identical waves.
        nShort = size(shortErr, 2);
        first400Long = longErr(:, 1:nShort);
        prefixError = max(abs(shortErr(:) - first400Long(:)));
        samePrefix = prefixError < 1e-6;
        prefixRows = appendRow(prefixRows, struct( ...
            'Scenario', string(scenario(s).name), 'Seed', seed, ...
            'MaxPrefixErrorDifference', prefixError, ...
            'IdenticalFirst400s', samePrefix));
        if ~samePrefix
            warning(['%s: 400-s and 800-s simulations differ within ', ...
                     'the first 400 s (max error difference %.4g). ', ...
                     'Treat them as separately generated stochastic ', ...
                     'realizations; do not describe 800 s as a literal ', ...
                     'continuation of the earlier run.'], ...
                    scenario(s).name, prefixError);
        end

        saves = {shortSave, longSave};
        errs  = {shortErr, longErr};
        times = {shortTime, longTime};
        horizons = [shortHorizon, longHorizon];
        for h = 1:2
            for m = 1:3
                delta = scenario(s).goal(m) - scenario(s).initial(m);
                for tp = tolerancePercents
                    tol = (tp/100) * abs(delta);
                    if abs(delta) < eps
                        tol = (tp/100) * max(1, abs(scenario(s).goal(m)));
                    end
                    v = inspectSettling(errs{h}(m,:), times{h}, ...
                                       tol, postEntryRequirement);
                    after400 = times{h} > shortHorizon;
                    exitsAfter400 = any(abs(errs{h}(m,after400)) > tol);
                    row = struct( ...
                        'Scenario', string(scenario(s).name), ...
                        'Seed', seed, ...
                        'Horizon_s', horizons(h), ...
                        'Channel', string(channelNames{m}), ...
                        'Band_percent', tp, ...
                        'Band_halfwidth', tol, ...
                        'FiniteHorizonTs_s', v.FiniteHorizonTs, ...
                        'ObservedMargin_s', v.PostEntryTime, ...
                        'Verified60s', v.Verified, ...
                        'VerifiedTs_s', v.VerifiedTs, ...
                        'OutOfBandAfter400s', exitsAfter400, ...
                        'Status', string(v.Status));
                    rows = appendRow(rows, row);
                end
            end
        end

        allRuns{s,seedIndex} = struct( ...
            'Seed', seed, 'Scenario', string(scenario(s).name), ...
            'Original400', shortSave, 'Extended800', longSave, ...
            'PrefixMaxErrorDifference', prefixError);

        % Error magnitude plots are easier to audit than visually
        % inferring settling from the raw vessel-position curves.
        plotErrorBands(longErr, longTime, scenario(s), ...
                       tolerancePercents, shortHorizon, outDir, seed);
    end
end

%% Save auditable numerical results
validationTable = struct2table(rows);
prefixTable = struct2table(prefixRows);
writetable(validationTable, ...
    fullfile(outDir, 'DP_settling_2_5_10_percent_400_vs_800.csv'));
writetable(prefixTable, ...
    fullfile(outDir, 'DP_400_800_prefix_reproducibility.csv'));
save(fullfile(outDir, 'DP_settling_validation_full.mat'), ...
     'validationTable', 'prefixTable', 'allRuns', 'controllerGains', ...
     'gainSource', 'scenario', 'Ts', 'shortHorizon', 'longHorizon', ...
     'postEntryRequirement', 'tolerancePercents', 'baseSeed', 'nSeeds');

fprintf('\n============= SETTLING VALIDATION =============\n');
disp(validationTable(:, {'Scenario','Horizon_s','Channel', ...
    'Band_percent','FiniteHorizonTs_s','ObservedMargin_s', ...
    'Verified60s','VerifiedTs_s','Status'}));
fprintf('\n============= PREFIX COMPARISON =============\n');
disp(prefixTable);
fprintf('\nGains source: %s\nOutput folder: %s\n', gainSource, outDir);
fprintf(['NOTE: "Verified60s" confirms a >=60-s observed post-entry ', ...
         'margin WITHIN the simulation window only; it does not ', ...
         'constitute a mathematical infinite-horizon stability proof.\n']);

%% ------------------------- LOCAL FUNCTIONS -------------------------
function [e, t] = extractError(SavePos, dt)
    if ~isfield(SavePos,'Observer') || ~isfield(SavePos,'Refrences')
        error('SavePosition must include Observer and Refrences.');
    end
    obs = SavePos.Observer(1:3, :);
    ref = SavePos.Refrences(1:3, :);
    if ~isequal(size(obs), size(ref))
        error('Observer and Refrences dimensions do not match.');
    end
    e = ref - obs;
    % Use the same sample-time convention as the ORIGINAL diagnostics:
    % time = (0:nSamples-1)*dt. The simulator loop records observer and
    % reference during each integration step; the exact physical phase
    % of these samples depends on the observer/guidance implementation.
    % Do NOT silently shift timestamps without checking those functions.
    t = (0:size(e,2)-1) * dt;
end

function v = inspectSettling(err, t, halfBand, minPostEntry)
    v = struct('FiniteHorizonTs', NaN, 'PostEntryTime', NaN, ...
               'Verified', false, 'VerifiedTs', NaN, ...
               'Status', 'Not settled within observed horizon');
    isIn = abs(err) <= halfBand;
    lastOutside = find(~isIn, 1, 'last');
    if isempty(lastOutside)
        k = 1;
    elseif lastOutside >= numel(isIn)
        return;
    else
        k = lastOutside + 1;
    end
    v.FiniteHorizonTs = t(k);
    v.PostEntryTime = t(end) - t(k);
    if v.PostEntryTime + 1e-8 >= minPostEntry
        v.Verified = true;
        v.VerifiedTs = v.FiniteHorizonTs;
        v.Status = 'Verified within observed horizon';
    else
        v.Status = 'Insufficient post-entry observation margin';
    end
end

function A = appendRow(A, row)
    if isempty(A)
        A = row;
    else
        A(end+1,1) = row;
    end
end

function plotErrorBands(e, t, sc, bandPercents, tOriginal, folder, seed)
    label = {'Surge (m)', 'Sway (m)', 'Yaw (deg)'};
    percentColors = [0.45 0.45 0.45; 0.8 0.25 0.25; 0.1 0.5 0.25];
    tag = strrep(sc.name, ' ', '_');
    for viewIdx = 1:2
        fig = figure('Color','w', 'Position', [100 100 1100 850], ...
                     'Visible','off');
        for m = 1:3
            ax = subplot(3,1,m); %#ok<LAXES>
            hold(ax, 'on'); grid(ax, 'on');
            h = plot(ax, t, abs(e(m,:)), 'b-', 'LineWidth', 0.75);
            allH = h;
            legendLabels = {'Absolute tracking error'};
            delta = abs(sc.goal(m) - sc.initial(m));
            if delta < eps, delta = max(1, abs(sc.goal(m))); end
            for bi = 1:numel(bandPercents)
                band = delta * bandPercents(bi) / 100;
                hb = plot(ax, [t(1) t(end)], [band band], '--', ...
                          'Color', percentColors(bi,:), 'LineWidth', 1.0);
                allH(end+1) = hb; %#ok<AGROW>
                legendLabels{end+1} = sprintf('%g%% band', bandPercents(bi)); %#ok<AGROW>
            end
            yl = ylim(ax);
            plot(ax, [tOriginal tOriginal], yl, 'k:', 'LineWidth', 1.0);
            ylim(ax, yl);
            if viewIdx == 2
                xlim(ax, [max(0,tOriginal-50) t(end)]);
            else
                xlim(ax, [0 t(end)]);
            end
            ylabel(ax, label{m});
            title(ax, sprintf('%s: %s error', sc.name, label{m}));
            if m == 1
                legend(ax, allH, legendLabels, 'Location', 'northeast');
            end
        end
        xlabel(ax, 'Time (s)');
        if viewIdx == 1, kind = 'full'; else, kind = 'zoom_after350'; end
        filename = fullfile(folder, sprintf('%s_seed%d_%s.png', tag, seed, kind));
        print(fig, filename, '-dpng', '-r200');
        close(fig);
    end
end
