function Validate_DP_Settling_Robust_800s
% VALIDATE_DP_SETTLING_ROBUST_800S
% Reviewer-8 supplementary validation of a FIXED PIDA controller.
% No optimizer or controller retuning is performed.
%
% IMPORTANT:
%   * A SINGLE 800-s trajectory is simulated per seed/scenario.
%   * The first 400 s of THAT trajectory are analyzed separately.
%     This avoids comparing different random realizations produced by
%     CostFunctionDPShip(400,...) and CostFunctionDPShip(800,...).
%   * These new 400-s prefixes are NOT a claim to reproduce the
%     original, previously published 400-s simulation.
%   * The calculation uses SavePosition.Observer and Refrences, exactly
%     like the supplied diagnostic function (estimated-state tracking).
%   * 60 s of post-entry data is an operational verification margin,
%     NOT a mathematical guarantee of asymptotic stability.
%
% REQUIREMENTS:
%   CostFunctionDPShip.m and its dependent MATLAB files on path.
% TO RUN:
%   Validate_DP_Settling_Robust_800s

%% User settings (no optimization)
dt = 0.1;
T400 = 400;
T800 = 800;
minObservedMargin_s = 60;
bands_percent = [2 5 10];
nSeeds = 10;               % Independent stochastic replicates
baseSeed = 20261022;
repeatabilityCheck = true;  % Repeat first 800-s run in each scenario
makePlots = true;           % One 3-panel error plot per scenario

scriptDir = fileparts(mfilename('fullpath'));
outputDir = fullfile(scriptDir, 'results', 'DP_Settling_Robust_800s');
if ~exist(outputDir,'dir'), mkdir(outputDir); end
if exist('CostFunctionDPShip','file') ~= 2
    error('CostFunctionDPShip.m and dependencies must be on the MATLAB path.');
end

%% Controller: prefer EXACT gains from the original saved optimization.
% The manuscript-rounded gains are provided only as an explicitly
% labelled fallback; using them is NOT an exact paper replication.
paperRounded = [1200, 6000, 1.444234e6, ...
    -9589.1016, -30000, -1.226424e7, ...
    -281.5114, -284.3843, -1882.1453, ...
    5.9638, 16.2989, 211.3767];

matCandidates = {
    fullfile(scriptDir,'results','SAMOPSO_FVML_Results.mat'), ...
    fullfile(pwd,'results','SAMOPSO_FVML_Results.mat'), ...
    fullfile(scriptDir,'SAMOPSO_FVML_Results.mat')};
matFound = '';
for ii = 1:numel(matCandidates)
    if exist(matCandidates{ii},'file') == 2
        matFound = matCandidates{ii};
        break;
    end
end

if ~isempty(matFound)
    S = load(matFound, 'Pareto_SAMOPSO');
    if ~isfield(S,'Pareto_SAMOPSO') || ...
       ~isfield(S.Pareto_SAMOPSO,'Cost') || ...
       ~isfield(S.Pareto_SAMOPSO,'Position')
        error('The MAT file does not include Pareto_SAMOPSO.Cost and .Position.');
    end
    [~,chosen] = min(sqrt(sum(S.Pareto_SAMOPSO.Cost.^2,2)));
    fixedGains = S.Pareto_SAMOPSO.Position(chosen,:);
    gainsSource = sprintf('Saved original archive, selected row %d',chosen);
elseif evalin('base','exist(''selectedPosition'',''var'')') == 1
    fixedGains = evalin('base','selectedPosition');
    gainsSource = 'Exact selectedPosition still available in base workspace';
else
    fixedGains = paperRounded;
    gainsSource = 'ROUNDED MANUSCRIPT GAINS (provisional; original MAT absent)';
    warning(['Exact controller was not located. Using manuscript-rounded ', ...
             'coefficients. Do NOT report the results as an exact ', ...
             'reproduction of the published run.']);
end
fixedGains = double(fixedGains(:)');
if numel(fixedGains) ~= 12 || any(~isfinite(fixedGains))
    error('The selected controller must contain 12 finite PIDA gains.');
end
maxRelativeGainDiff = max(abs(fixedGains-paperRounded)./max(1,abs(paperRounded)));
if maxRelativeGainDiff > 0.01
    error(['Selected gains differ from the manuscript by over 1%%. ', ...
           'Make sure this is the identical controller before proceeding.']);
end
fprintf('Controller: %s\n',gainsSource);
fprintf('Max relative discrepancy from rounded table: %.7g\n',maxRelativeGainDiff);

%% Scenarios exactly as specified in the manuscript
sc(1) = struct('name','Scenario 1','x0',[10;3;5],'goal',[17;6;26]);
sc(2) = struct('name','Scenario 2','x0',[0;1;0],'goal',[50;-12;56]);
ch = {'Surge','Sway','Yaw'};

rows = struct([]);
repeatRows = struct([]);
rawRuns = cell(2,nSeeds);

for s=1:2
    for iSeed=1:nSeeds
        seed = baseSeed + 1000*s + iSeed;
        fprintf('%s: seed %d (%d/%d) -- simulating once to 800 s\n', ...
            sc(s).name,seed,iSeed,nSeeds);
        rng(seed,'twister');
        [~,~,save800] = CostFunctionDPShip( ...
            sc(s).x0,sc(s).goal,T800,fixedGains,true);
        [err800,t800] = extractErr(save800,dt);
        if size(err800,2) < T800/dt
            error('Expected 800/dt samples in the extended simulation.');
        end
        if any(~isfinite(err800(:)))
            error('Nonfinite error in %s, seed %d.',sc(s).name,seed);
        end
        n400 = round(T400/dt);
        if size(err800,2) < n400
            error('Not enough samples for the 400-s prefix.');
        end

        % Independent repeatability check: SAME 800-s horizon and RNG seed.
        % Unlike the prior 400-vs-800 comparison, this comparison controls
        % the wave-generation horizon itself.
        if repeatabilityCheck && iSeed == 1
            rng(seed,'twister');
            [~,~,repeatSave] = CostFunctionDPShip( ...
                sc(s).x0,sc(s).goal,T800,fixedGains,true);
            [eRep,~] = extractErr(repeatSave,dt);
            maxDiff = NaN;
            if isequal(size(err800),size(eRep))
                maxDiff = max(abs(err800(:)-eRep(:)));
            end
            reproducible = isfinite(maxDiff) && maxDiff < 1e-8;
            repeatRows = appendStruct(repeatRows,struct( ...
                'Scenario',string(sc(s).name), 'Seed',seed, ...
                'MaxErrorDifference',maxDiff,'IdenticalRepeated800s',reproducible));
            if ~reproducible
                warning(['Repeated 800-s runs with the same seed did not ', ...
                    'match for %s. Inspect persistent/global simulation ', ...
                    'states and stochastic model initialization.'],sc(s).name);
            end
        end

        rawRuns{s,iSeed} = struct('Scenario',sc(s).name, ...
            'Seed',seed,'Time_s',t800,'Error',err800);

        for h=1:2
            if h==1
                idx=1:n400;
                horizonName='400-s prefix of same 800-s simulation';
            else
                idx=1:size(err800,2);
                horizonName='Full 800-s simulation';
            end
            time=t800(idx);
            err=err800(:,idx);
            for m=1:3
                delta=sc(s).goal(m)-sc(s).x0(m);
                for bp=bands_percent
                    halfWidth=(bp/100)*abs(delta);
                    if abs(delta)<eps
                        halfWidth=(bp/100)*max(1,abs(sc(s).goal(m)));
                    end
                    v=finiteWindowSettling(err(m,:),time,halfWidth,minObservedMargin_s);
                    tailStart=max(1,numel(time)-round(200/dt)+1);
                    errTail=err(m,tailStart:end);
                    insideTail=abs(errTail)<=halfWidth;
                    rows=appendStruct(rows,struct( ...
                        'Scenario',string(sc(s).name), ...
                        'Seed',seed, ...
                        'Window_s',400*(h==1)+800*(h==2), ...
                        'WindowDescription',string(horizonName), ...
                        'Channel',string(ch{m}), ...
                        'Band_percent',bp, ...
                        'Band_halfwidth',halfWidth, ...
                        'FiniteWindowTs_s',v.Ts, ...
                        'ObservedMargin_s',v.Margin, ...
                        'Verified60s',v.Verified, ...
                        'VerifiedTs_s',v.VerifiedTs, ...
                        'Last200s_InBand_percent',100*mean(insideTail), ...
                        'Last200s_MAE',mean(abs(errTail)), ...
                        'Last200s_RMSE',sqrt(mean(errTail.^2)), ...
                        'Last200s_P95AbsError',quantileLocal(abs(errTail),0.95), ...
                        'Status',string(v.Status)));
                end
            end
        end

        if makePlots && iSeed==1
            plotBands(err800,t800,sc(s),ch,bands_percent,T400,outputDir,seed);
        end
    end
end

%% Export all runs and a compact reproducible summary
allResults=struct2table(rows);
summary=struct([]);
for s=1:2
    for horizon=[400 800]
        for m=1:3
            for bp=bands_percent
                subset=allResults( ...
                    allResults.Scenario==string(sc(s).name) & ...
                    allResults.Window_s==horizon & ...
                    allResults.Channel==string(ch{m}) & ...
                    allResults.Band_percent==bp,:);
                verifiedTs=subset.VerifiedTs_s(subset.Verified60s);
                medTs=NaN;
                if ~isempty(verifiedTs)
                    medTs=median(verifiedTs);
                end
                summary=appendStruct(summary,struct( ...
                    'Scenario',string(sc(s).name), ...
                    'Window_s',horizon, ...
                    'Channel',string(ch{m}), ...
                    'Band_percent',bp, ...
                    'N_runs',height(subset), ...
                    'N_verified60s',sum(subset.Verified60s), ...
                    'VerifiedRate_percent',100*mean(subset.Verified60s), ...
                    'MedianVerifiedTs_s',medTs, ...
                    'MedianLast200s_InBand_percent',median(subset.Last200s_InBand_percent), ...
                    'MedianLast200s_MAE',median(subset.Last200s_MAE), ...
                    'MedianLast200s_RMSE',median(subset.Last200s_RMSE), ...
                    'MedianLast200s_P95AbsError',median(subset.Last200s_P95AbsError)));
            end
        end
    end
end
summaryTable=struct2table(summary);
writetable(allResults,fullfile(outputDir,'DP_per_seed_400prefix_800_bands.csv'));
writetable(summaryTable,fullfile(outputDir,'DP_summary_400prefix_800_bands.csv'));
if ~isempty(repeatRows)
    repeatabilityTable=struct2table(repeatRows);
    writetable(repeatabilityTable,fullfile(outputDir,'DP_repeatability_800s.csv'));
else
    repeatabilityTable=table();
end
save(fullfile(outputDir,'DP_full_validation_800s.mat'), ...
    'allResults','summaryTable','repeatabilityTable','rawRuns','fixedGains', ...
    'gainsSource','dt','T400','T800','minObservedMargin_s', ...
    'bands_percent','nSeeds','baseSeed');

fprintf('\n======== AGGREGATE VALIDATION (10 seeds by default) ========\n');
disp(summaryTable(:,{'Scenario','Window_s','Channel','Band_percent', ...
    'N_runs','N_verified60s','VerifiedRate_percent','MedianVerifiedTs_s', ...
    'MedianLast200s_InBand_percent'}));
fprintf('\nSaved in: %s\n',outputDir);
fprintf('Gains source: %s\n',gainsSource);
fprintf(['IMPORTANT: A 400-s prefix extracted from an 800-s run is ', ...
    'NOT claimed to reproduce the original published 400-s run.\n']);
fprintf(['IMPORTANT: This analysis uses OBSERVER-ESTIMATED states and ', ...
    'does not prove true-plant or infinite-horizon stability.\n']);
end

function [err,t]=extractErr(saved,dt)
    if ~isfield(saved,'Observer') || ~isfield(saved,'Refrences')
        error('CostFunctionDPShip must return Observer and Refrences.');
    end
    obs=saved.Observer(1:3,:);
    ref=saved.Refrences(1:3,:);
    if ~isequal(size(obs),size(ref))
        error('Observer and Refrences sample counts differ.');
    end
    err=ref-obs;
    % This matches the ORIGINAL diagnostic timestamp convention.
    % Confirm sensor/reference update phase before shifting timestamps.
    t=(0:size(err,2)-1)*dt;
end

function out=finiteWindowSettling(err,t,halfWidth,minMargin)
    out=struct('Ts',NaN,'Margin',NaN,'Verified',false, ...
        'VerifiedTs',NaN,'Status','No observed final in-band segment');
    lastOutside=find(abs(err)>halfWidth,1,'last');
    if isempty(lastOutside)
        k=1;
    elseif lastOutside==numel(err)
        return;
    else
        k=lastOutside+1;
    end
    out.Ts=t(k);
    out.Margin=t(end)-t(k);
    if out.Margin+1e-9>=minMargin
        out.Verified=true;
        out.VerifiedTs=out.Ts;
        out.Status='At least 60 s of observed final in-band response';
    else
        out.Status='Insufficient observed post-entry margin';
    end
end

function x=quantileLocal(a,p)
    a=sort(a(:));
    n=numel(a);
    if n==1, x=a; return; end
    pos=1+(n-1)*p;
    j=floor(pos); k=ceil(pos);
    if j==k, x=a(j); else, x=a(j)+(pos-j)*(a(k)-a(j)); end
end

function a=appendStruct(a,r)
    if isempty(a), a=r; else, a(end+1,1)=r; end
end

function plotBands(e,t,sc,ch,bands,cut,folder,seed)
    fig=figure('Visible','off','Color','w','Position',[100 100 1150 920]);
    for m=1:3
        subplot(3,1,m); hold on; grid on;
        plot(t,abs(e(m,:)),'k','LineWidth',0.8);
        delta=abs(sc.goal(m)-sc.x0(m));
        styles={'--','-.',':'};
        for i=1:numel(bands)
            b=bands(i)/100*delta;
            if delta<eps, b=bands(i)/100*max(1,abs(sc.goal(m))); end
            yline(b,styles{i},sprintf('%g%%',bands(i)),'LineWidth',1.3);
        end
        xline(cut,'-','400 s','LineWidth',1.0);
        ylabel(['|Error|, ',ch{m}]);
        if m==1
            title(sprintf('%s | Seed %d | Observer tracking error',sc.name,seed));
        end
        if m==3, xlabel('Time (s)'); end
        xlim([0,max(t)]);
    end
    saveas(fig,fullfile(folder,sprintf('DP_%s_seed_%d_error_bands.png', ...
        strrep(sc.name,' ',''),seed)));
    close(fig);
end
