
function tau = fcn_wind(nu_abs, Psi, Vw, Beta)

% Wind forces and yaw moment acting on the vessel
%
% Inputs:
% nu_abs : Vessel velocity vector [u; v; r]
% Psi    : Vessel heading angle [deg]
% Vw     : Wind speed [m/s]
% Beta   : Wind direction [deg]
%
% Output:
% tau    : Wind forces and moment [Xwind; Ywind; Nwind]

%% 1. Vessel velocities
u = nu_abs(1);
v = nu_abs(2);

%% 2. Angle conversion (degrees to radians)
Psi  = deg2rad(Psi);
Beta = deg2rad(Beta);

%% 3. Wind velocity in vessel body frame
uw = Vw * cos(Beta - Psi);
vw = Vw * sin(Beta - Psi);

%% 4. Relative wind velocity
urw = u - uw;
vrw = v - vw;

Vrw = sqrt(urw^2 + vrw^2);

%% 5. Relative wind angle (in radians)
gamma = -atan2(vrw, urw);

%% 6. Vessel geometric parameters
AFw = 82;
ALw = 185;
Loa = 32;
sL  = 3;

%% 7. Air density
rho_a = 1.224;

%% 8. Wind coefficient parameters
BDATA = [0.90 0.45 0.50 0.80];

CDt          = BDATA(1);
CDl_AF_bow   = BDATA(2);
CDl_AF_stern = BDATA(3);
delta        = BDATA(4);

%% 9. Longitudinal drag coefficient
if abs(gamma) <= pi/2
    CDlAF = CDl_AF_bow;
else
    CDlAF = CDl_AF_stern;
end

%% 10. Wind force and moment coefficients
CDl = CDlAF * AFw / ALw;

den = 1 - 0.5 * delta * (1 - CDl/CDt) ...
          * sin(2*gamma)^2;

CX = -CDlAF * cos(gamma) / den;
CY =  CDt * sin(gamma) / den;
CN = (sL/Loa - 0.18*(gamma - pi/2)) * CY;

%% 11. Wind forces and yaw moment
Xwind = 0.5 * rho_a * Vrw^2 * AFw * CX;

Ywind = 0.5 * rho_a * Vrw^2 * ALw * CY;

Nwind = 0.5 * rho_a * Vrw^2 * ALw * Loa * CN;

%% 12. Output
tau = [Xwind; Ywind; Nwind];

end
