%% Make DP selected controller table from existing workspace variables
% This script DOES NOT rerun the optimization.
% It uses Pareto_SAMOPSO and ParetoPositions_SAMOPSO already available
% in the MATLAB workspace.

clc;

%% Check required workspace variables
if ~exist('Pareto_SAMOPSO', 'var')
    error('Pareto_SAMOPSO is not available in the workspace.');
end

if ~exist('ParetoPositions_SAMOPSO', 'var')
    error('ParetoPositions_SAMOPSO is not available in the workspace.');
end

%% Select solution index
if ~exist('best_samopso_idx', 'var') || isempty(best_samopso_idx)
    % Select the compromise solution with minimum Euclidean norm of objectives
    [~, best_samopso_idx] = min(sqrt(sum(Pareto_SAMOPSO.Cost.^2, 2)));
end

fprintf('Selected Pareto solution index: %d\n', best_samopso_idx);

%% Extract selected controller and saved simulation data
selectedPosition = Pareto_SAMOPSO.Position(best_samopso_idx, :);
SaveSelected = ParetoPositions_SAMOPSO{best_samopso_idx};

%% Sampling time
Ts = 0.1;   % Change this if your simulation sample time is different

%% Create table
DP_Selected_Table = makeDPTableFromSavedWorkspaceData(selectedPosition, SaveSelected, Ts);

fprintf('\n====== SELECTED DP CONTROLLER TABLE ======\n');
disp(DP_Selected_Table);

%% Save as CSV if desired
if exist('outDir', 'var')
    if ~exist(outDir, 'dir')
        mkdir(outDir);
    end
    writetable(DP_Selected_Table, fullfile(outDir, 'dp_selected_solution_table.csv'));
    fprintf('\nCSV file saved to:\n%s\n', fullfile(outDir, 'dp_selected_solution_table.csv'));
else
    writetable(DP_Selected_Table, 'dp_selected_solution_table.csv');
    fprintf('\nCSV file saved to:\ndp_selected_solution_table.csv\n');
end

%% Optional: create a figure like a table
figure('Name', 'Selected DP Controller Table', ...
       'Color', 'w', ...
       'Position', [200 200 720 280]);

uitable('Data', table2cell(DP_Selected_Table), ...
        'ColumnName', DP_Selected_Table.Properties.VariableNames, ...
        'RowName', [], ...
        'Units', 'normalized', ...
        'Position', [0 0 1 1]);

%% Optional: print LaTeX-ready rows in Command Window
fprintf('\n====== LATEX TABLE ROWS ======\n');
printDPTableRowsForLatex(DP_Selected_Table);

%% ========================================================================
% Local helper functions
% ========================================================================

function T = makeDPTableFromSavedWorkspaceData(position, SavePos, Ts)
% Creates MATLAB table for:
% Kp, Ki, Kd, Ka, IAE, Maximum error, and Control effort.
%
% Variable layout:
%   position(1:3)   = Kp for surge, sway, yaw
%   position(4:6)   = Kd for surge, sway, yaw
%   position(7:9)   = Ka for surge, sway, yaw
%   position(10:12) = Ki for surge, sway, yaw

    if nargin < 3 || isempty(Ts)
        Ts = 0.1;
    end

    Kp = position(1:3);
    Kd = position(4:6);
    Ka = position(7:9);
    Ki = position(10:12);

    if ~isfield(SavePos, 'Observer') || ~isfield(SavePos, 'Refrences')
        error('SaveSelected must contain Observer and Refrences fields.');
    end

    Observer = SavePos.Observer(1:3, :);
    Reference = SavePos.Refrences(1:3, :);

    e = Reference - Observer;

    nSamples = size(e, 2);
    time = (0:nSamples-1) * Ts;

    IAE = trapz(time, abs(e), 2).';
    MaxError = max(abs(e), [], 2).';

    U = extractControlSignalFromSavePos(SavePos);

    if isempty(U)
        ControlEffort = [NaN, NaN, NaN];
        warning(['Control signal was not found in SaveSelected. ', ...
                 'Control effort is reported as NaN.']);
    else
        if size(U, 1) ~= 3 && size(U, 2) == 3
            U = U.';
        end

        if size(U, 1) ~= 3
            ControlEffort = [NaN, NaN, NaN];
            warning('Detected control signal is not 3-channel. Control effort is reported as NaN.');
        else
            nU = size(U, 2);
            timeU = (0:nU-1) * Ts;
            ControlEffort = trapz(timeU, U.^2, 2).';
        end
    end

    Quantity = { ...
        'Kp'; ...
        'Ki'; ...
        'Kd'; ...
        'Ka'; ...
        'IAE'; ...
        'Maximum error'; ...
        'Control effort'};

    Surge = [Kp(1); Ki(1); Kd(1); Ka(1); IAE(1); MaxError(1); ControlEffort(1)];
    Sway  = [Kp(2); Ki(2); Kd(2); Ka(2); IAE(2); MaxError(2); ControlEffort(2)];
    Yaw   = [Kp(3); Ki(3); Kd(3); Ka(3); IAE(3); MaxError(3); ControlEffort(3)];

    T = table(Quantity, Surge, Sway, Yaw);
end

function U = extractControlSignalFromSavePos(SavePos)
% Tries to find a 3-channel control/force signal inside SavePos.

    U = [];

    if ~isstruct(SavePos)
        return;
    end

    candidateFields = { ...
        'Control', ...
        'control', ...
        'ControlInput', ...
        'controlInput', ...
        'U', ...
        'u', ...
        'Tau', ...
        'tau', ...
        'Force', ...
        'force', ...
        'Forces', ...
        'forces', ...
        'Input', ...
        'input'};

    for k = 1:numel(candidateFields)
        fieldName = candidateFields{k};

        if isfield(SavePos, fieldName)
            candidate = SavePos.(fieldName);

            if isnumeric(candidate) && ismatrix(candidate)
                if size(candidate, 1) == 3 || size(candidate, 2) == 3
                    U = candidate;
                    return;
                end
            end
        end
    end
end

function printDPTableRowsForLatex(T)

    for i = 1:height(T)
        q = T.Quantity{i};

        surge = T.Surge(i);
        sway  = T.Sway(i);
        yaw   = T.Yaw(i);

        fprintf('%s & %.6g & %.6g & %.6g \\\\\n', q, surge, sway, yaw);
    end
end