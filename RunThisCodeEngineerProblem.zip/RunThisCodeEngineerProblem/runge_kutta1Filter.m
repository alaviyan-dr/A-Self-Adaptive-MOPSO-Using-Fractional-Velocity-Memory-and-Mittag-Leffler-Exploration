%% runge-kutta code
%<xx> & <x0> & <y> & <xxy> double vector with size 15x1
%dt &h double 
function  y= runge_kutta1Filter(x0,dt,h,xxy)
N=ceil(dt/h);
persistent x;
%if isempty(xx)
x=zeros(3,N);
x(:,1)   =   x0;
%end


t=0:h:dt;
%

for i=1:N 
%     
%     k1= LowPass_forceFuc( t(i)     ,  x(:,i)         , xxy );
%     k2= LowPass_forceFuc( t(i)+h/2 , (x(:,i)+k1*h/2) , xxy );
%     k3= LowPass_forceFuc( t(i)+h/2 ,  x(:,i)+k2*h/2  , xxy );
%     k4= LowPass_forceFuc( t(i)+h   ,  x(:,i)+k3*h    , xxy );
%     

    k1= LowPass_forceFuc(   x(:,i)         , xxy );
    k2= LowPass_forceFuc( (x(:,i)+k1*h/2) , xxy );
    k3= LowPass_forceFuc(  x(:,i)+k2*h/2  , xxy );
    k4= LowPass_forceFuc(  x(:,i)+k3*h    , xxy );
    
      x(:,i+1)= x(:,i) + (h/6) * (k1+2*k2+2*k3+k4);
     
end
    y=x(:,end);
    
%yy=y+zeros(size(y));
end
